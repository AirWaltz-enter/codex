import argparse
import re
import shutil
import sys
import tempfile
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk

import requests
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from PIL import Image, ImageTk


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
STANDARD_FILE = ROOT_DIR / "cleaned" / "Fastmoss_待搜款清洗表.xlsx"
CROP_DIR = ROOT_DIR / "images" / "crop_subject"
ORIGINAL_IMAGE_DIR = ROOT_DIR / "images" / "fastmoss_original"
OUTPUT_DIR = ROOT_DIR / "output"
BACKUP_DIR = ROOT_DIR / "backup"
TASK_QUEUE_FILE = OUTPUT_DIR / "1688_待搜款任务队列.xlsx"
SEARCH_RESULTS_FILE = OUTPUT_DIR / "1688_搜款结果表.xlsx"
MANUAL_SUMMARY_FILE = OUTPUT_DIR / "1688_人工搜款汇总表.xlsx"
CROP_HEADER = "主体裁剪图路径"
NOTE_CROPPED = "用户手动裁剪完成"
NOTE_IMAGE_DOWNLOADED = "商品图片已下载"

HEADERS = {
    "product_id": "商品ID",
    "spu": "SPU",
    "title": "商品标题",
    "product_link": "商品链接",
    "image_url": "商品图片链接",
    "local_image": "本地图片路径",
    "sales_7d": "近7天销量",
    "product_price": "商品价格",
    "should_search": "是否进入搜款",
    "search_status": "搜款状态",
    "note": "备注",
    "crop_path": CROP_HEADER,
}

TASK_QUEUE_HEADERS = [
    "任务ID",
    "源表行号",
    "商品ID",
    "SPU",
    "商品标题",
    "主体裁剪图路径",
    "商品链接",
    "近7天销量",
    "商品价格",
    "搜款状态",
    "任务状态",
    "备注",
]

SEARCH_RESULT_HEADERS = [
    "任务ID",
    "源表行号",
    "商品ID",
    "SPU",
    "Fastmoss商品标题",
    "Fastmoss商品链接",
    "主体裁剪图路径",
    "1688搜索状态",
    "1688结果排名",
    "1688商品标题",
    "1688商品链接",
    "1688主图路径",
    "1688主图链接",
    "1688价格",
    "起批量",
    "供应商名称",
    "相似度",
    "人工判断",
    "采集状态",
    "备注",
]

QUEUE_REQUIRED_HEADERS = [
    HEADERS["should_search"],
    HEADERS["search_status"],
    HEADERS["crop_path"],
]


def text_value(value):
    return "" if value is None else str(value).strip()


def normalize_header(value):
    return text_value(value).replace("\n", "").replace("\r", "")


def safe_filename_part(value, fallback):
    text = text_value(value) or fallback
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        text = text.replace(char, "_")
    text = "_".join(text.split()).strip("._ ")
    return text or fallback


def ensure_crop_dir():
    CROP_DIR.mkdir(parents=True, exist_ok=True)
    return CROP_DIR


def ensure_original_image_dir():
    ORIGINAL_IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    return ORIGINAL_IMAGE_DIR


def ensure_output_dir():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    return OUTPUT_DIR


def load_standard_workbook(path=STANDARD_FILE):
    if not Path(path).exists():
        raise FileNotFoundError(f"找不到标准表：{path}")
    workbook = load_workbook(path)
    worksheet = workbook.active
    header_map = get_header_map(worksheet)
    if CROP_HEADER not in header_map:
        next_col = worksheet.max_column + 1
        worksheet.cell(1, next_col).value = CROP_HEADER
        header_map[CROP_HEADER] = next_col
    return workbook, worksheet, header_map


def get_header_map(worksheet):
    header_map = {}
    for col in range(1, worksheet.max_column + 1):
        header = normalize_header(worksheet.cell(1, col).value)
        if header and header not in header_map:
            header_map[header] = col
    return header_map


def get_cell_value(worksheet, row_number, header_map, header):
    col = header_map.get(header)
    if not col:
        return ""
    return worksheet.cell(row_number, col).value


def set_cell_value(worksheet, row_number, header_map, header, value):
    col = header_map.get(header)
    if not col:
        col = worksheet.max_column + 1
        worksheet.cell(1, col).value = header
        header_map[header] = col
    worksheet.cell(row_number, col).value = value


def read_product_rows(worksheet, header_map):
    rows = []
    for row_number in range(2, worksheet.max_row + 1):
        title = text_value(get_cell_value(worksheet, row_number, header_map, HEADERS["title"]))
        local_image = text_value(get_cell_value(worksheet, row_number, header_map, HEADERS["local_image"]))
        should_search = text_value(get_cell_value(worksheet, row_number, header_map, HEADERS["should_search"]))
        status = text_value(get_cell_value(worksheet, row_number, header_map, HEADERS["search_status"]))
        if not any([title, local_image, should_search, status]):
            continue
        rows.append(
            {
                "row_number": row_number,
                "title": title,
                "local_image": local_image,
                "should_search": should_search,
                "status": status,
            }
        )
    return rows


def resolve_image_path(raw_path):
    raw_text = text_value(raw_path)
    if not raw_text:
        return None
    path = Path(raw_text)
    candidates = [path]
    if not path.is_absolute():
        candidates.append(ROOT_DIR / path)
        candidates.append(SCRIPT_DIR / path)
    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate.resolve()
    return None


def validate_queue_headers(header_map):
    missing = [header for header in QUEUE_REQUIRED_HEADERS if header not in header_map]
    if missing:
        raise ValueError(f"标准表缺少必要列：{', '.join(missing)}")


def collect_search_task_candidates(worksheet, header_map):
    validate_queue_headers(header_map)
    candidates = []
    for row_number in range(2, worksheet.max_row + 1):
        should_search = text_value(
            get_cell_value(worksheet, row_number, header_map, HEADERS["should_search"])
        )
        search_status = text_value(
            get_cell_value(worksheet, row_number, header_map, HEADERS["search_status"])
        )
        raw_crop_path = get_cell_value(worksheet, row_number, header_map, HEADERS["crop_path"])
        crop_path = resolve_image_path(raw_crop_path)
        if should_search != "是" or search_status not in {"已裁剪", "未搜"} or crop_path is None:
            continue
        candidates.append(
            {
                "源表行号": row_number,
                "商品ID": get_cell_value(
                    worksheet, row_number, header_map, HEADERS["product_id"]
                ),
                "SPU": get_cell_value(worksheet, row_number, header_map, HEADERS["spu"]),
                "商品标题": get_cell_value(
                    worksheet, row_number, header_map, HEADERS["title"]
                ),
                "主体裁剪图路径": str(crop_path),
                "商品链接": get_cell_value(
                    worksheet, row_number, header_map, HEADERS["product_link"]
                ),
                "近7天销量": get_cell_value(
                    worksheet, row_number, header_map, HEADERS["sales_7d"]
                ),
                "商品价格": get_cell_value(
                    worksheet, row_number, header_map, HEADERS["product_price"]
                ),
                "搜款状态": search_status,
                "备注": get_cell_value(worksheet, row_number, header_map, HEADERS["note"]),
            }
        )
    return candidates


def collect_search_tasks(worksheet, header_map):
    tasks = []
    for index, candidate in enumerate(
        collect_search_task_candidates(worksheet, header_map),
        start=1,
    ):
        task = dict(candidate)
        task["任务ID"] = f"SEARCH_{index:06d}"
        task["任务状态"] = "待搜款"
        tasks.append([task.get(header, "") for header in TASK_QUEUE_HEADERS])
    return tasks


def normalized_crop_path(raw_path):
    raw_text = text_value(raw_path)
    if not raw_text:
        return ""
    path = Path(raw_text)
    if not path.is_absolute():
        path = ROOT_DIR / path
    try:
        path = path.resolve()
    except OSError:
        path = path.absolute()
    return str(path).replace("/", "\\").casefold()


def task_unique_key(task):
    crop_path = normalized_crop_path(task.get("主体裁剪图路径"))
    if not crop_path:
        return None
    for header in ["商品ID", "SPU", "商品链接"]:
        value = text_value(task.get(header))
        if value:
            return header, value.casefold(), crop_path
    return "主体裁剪图路径", crop_path


def next_backup_path(source_path, backup_dir, timestamp):
    base_name = f"{source_path.stem}_{timestamp}"
    destination = backup_dir / f"{base_name}{source_path.suffix}"
    index = 1
    while destination.exists():
        destination = backup_dir / f"{base_name}_{index}{source_path.suffix}"
        index += 1
    return destination


def backup_search_output_files(
    task_queue_path,
    search_results_path,
    manual_summary_path,
    backup_dir=BACKUP_DIR,
):
    backup_dir = Path(backup_dir)
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_paths = []
    for source in [task_queue_path, search_results_path, manual_summary_path]:
        source = Path(source)
        if not source.exists():
            continue
        destination = next_backup_path(source, backup_dir, timestamp)
        shutil.copy2(source, destination)
        if not destination.exists() or destination.stat().st_size != source.stat().st_size:
            raise OSError(f"备份校验失败：{source}")
        backup_paths.append(destination)
    return backup_paths


def ensure_task_queue_headers(worksheet):
    header_map = get_header_map(worksheet)
    for header in TASK_QUEUE_HEADERS:
        if header in header_map:
            continue
        column = max(header_map.values(), default=0) + 1
        cell = worksheet.cell(1, column)
        cell.value = header
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="D9EAF7")
        cell.alignment = Alignment(horizontal="center", vertical="center")
        worksheet.column_dimensions[get_column_letter(column)].width = max(
            12, min(42, len(header) * 2 + 4)
        )
        header_map[header] = column
    return header_map


def load_or_create_task_queue(path):
    path = Path(path)
    if path.exists():
        workbook = load_workbook(path)
        worksheet = workbook.active
    else:
        workbook = Workbook()
        worksheet = workbook.active
        worksheet.title = "待搜款任务队列"
    header_map = ensure_task_queue_headers(worksheet)
    worksheet.freeze_panes = "A2"
    return workbook, worksheet, header_map


def read_existing_queue_tasks(worksheet, header_map):
    tasks = []
    for row_number in range(2, worksheet.max_row + 1):
        task = {
            header: get_cell_value(worksheet, row_number, header_map, header)
            for header in TASK_QUEUE_HEADERS
        }
        if not any(text_value(value) for value in task.values()):
            continue
        task["_excel_row"] = row_number
        tasks.append(task)
    return tasks


def max_search_task_number(tasks):
    maximum = 0
    for task in tasks:
        match = re.fullmatch(r"SEARCH_(\d+)", text_value(task.get("任务ID")))
        if match:
            maximum = max(maximum, int(match.group(1)))
    return maximum


def save_task_queue_incrementally(path, candidates):
    path = Path(path)
    workbook, worksheet, header_map = load_or_create_task_queue(path)
    existing_tasks = read_existing_queue_tasks(worksheet, header_map)
    existing_count = len(existing_tasks)
    existing_by_key = {}
    for task in existing_tasks:
        key = task_unique_key(task)
        if key is not None and key not in existing_by_key:
            existing_by_key[key] = task

    next_number = max_search_task_number(existing_tasks)
    new_count = 0
    updatable_headers = [
        "源表行号",
        "商品ID",
        "SPU",
        "商品标题",
        "主体裁剪图路径",
        "商品链接",
        "近7天销量",
        "商品价格",
        "搜款状态",
        "备注",
    ]
    for candidate in candidates:
        key = task_unique_key(candidate)
        existing_task = existing_by_key.get(key)
        if existing_task is not None:
            row_number = existing_task["_excel_row"]
            for header in updatable_headers:
                set_cell_value(
                    worksheet,
                    row_number,
                    header_map,
                    header,
                    candidate.get(header, ""),
                )
            continue

        next_number += 1
        new_count += 1
        task = dict(candidate)
        task["任务ID"] = f"SEARCH_{next_number:06d}"
        task["任务状态"] = "待搜款"
        row_number = worksheet.max_row + 1
        for header in TASK_QUEUE_HEADERS:
            set_cell_value(
                worksheet,
                row_number,
                header_map,
                header,
                task.get(header, ""),
            )
        task["_excel_row"] = row_number
        if key is not None:
            existing_by_key[key] = task

    worksheet.auto_filter.ref = (
        f"A1:{get_column_letter(worksheet.max_column)}{max(worksheet.max_row, 1)}"
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(f".{path.stem}_incremental_tmp.xlsx")
    try:
        workbook.save(temp_path)
        workbook.close()
        temp_path.replace(path)
    except Exception:
        workbook.close()
        if temp_path.exists():
            temp_path.unlink()
        raise
    return new_count, existing_count, existing_count + new_count


def save_output_workbook(path, sheet_title, headers, rows=None):
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = sheet_title
    worksheet.append(headers)
    for row in rows or []:
        worksheet.append(row)

    header_fill = PatternFill("solid", fgColor="D9EAF7")
    for cell in worksheet[1]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center")
    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{max(worksheet.max_row, 1)}"
    for col_index, header in enumerate(headers, 1):
        width = max(12, min(42, len(str(header)) * 2 + 4))
        worksheet.column_dimensions[get_column_letter(col_index)].width = width

    path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(path)
    workbook.close()
    return path


def export_search_task_files(
    worksheet,
    header_map,
    task_queue_path=TASK_QUEUE_FILE,
    search_results_path=SEARCH_RESULTS_FILE,
    manual_summary_path=MANUAL_SUMMARY_FILE,
    backup_dir=BACKUP_DIR,
):
    candidates = collect_search_task_candidates(worksheet, header_map)
    ensure_output_dir()
    backup_paths = backup_search_output_files(
        Path(task_queue_path),
        Path(search_results_path),
        Path(manual_summary_path),
        backup_dir,
    )
    new_count, existing_count, total_count = save_task_queue_incrementally(
        task_queue_path,
        candidates,
    )
    result_existed = Path(search_results_path).exists()
    if not result_existed:
        save_output_workbook(
            search_results_path,
            "1688搜款结果",
            SEARCH_RESULT_HEADERS,
        )
    return {
        "new_count": new_count,
        "existing_count": existing_count,
        "total_count": total_count,
        "task_path": Path(task_queue_path),
        "result_path": Path(search_results_path),
        "result_preserved": result_existed,
        "backup_paths": backup_paths,
        "backup_dir": Path(backup_dir),
    }


def crop_filename_for_row(worksheet, row_number, header_map):
    product_id = get_cell_value(worksheet, row_number, header_map, HEADERS["product_id"])
    spu = get_cell_value(worksheet, row_number, header_map, HEADERS["spu"])
    if text_value(product_id):
        base = safe_filename_part(product_id, f"row_{row_number}")
    elif text_value(spu):
        base = safe_filename_part(spu, f"row_{row_number}")
    else:
        base = f"row_{row_number}"
    return f"{base}_crop.jpg"


def original_image_filename_for_row(worksheet, row_number, header_map):
    product_id = get_cell_value(worksheet, row_number, header_map, HEADERS["product_id"])
    spu = get_cell_value(worksheet, row_number, header_map, HEADERS["spu"])
    if text_value(product_id):
        base = safe_filename_part(product_id, f"row_{row_number}")
    elif text_value(spu):
        base = safe_filename_part(spu, f"row_{row_number}")
    else:
        base = f"row_{row_number}"
    return f"{base}.jpg"


def original_image_path_for_row(worksheet, row_number, header_map):
    return ensure_original_image_dir() / original_image_filename_for_row(worksheet, row_number, header_map)


def unique_crop_path(file_name):
    crop_dir = ensure_crop_dir()
    target = crop_dir / file_name
    if not target.exists():
        return target
    stem = target.stem
    suffix = target.suffix
    index = 1
    while True:
        candidate = crop_dir / f"{stem}_{index}{suffix}"
        if not candidate.exists():
            return candidate
        index += 1


def save_crop_for_row(worksheet, row_number, header_map, image_path, crop_box):
    left, top, right, bottom = crop_box
    if right <= left or bottom <= top:
        raise ValueError("框选区域无效，请重新框选。")

    with Image.open(image_path) as image:
        crop_box = (
            max(0, min(left, image.width)),
            max(0, min(top, image.height)),
            max(0, min(right, image.width)),
            max(0, min(bottom, image.height)),
        )
        cropped = image.crop(crop_box).convert("RGB")
        output_path = unique_crop_path(crop_filename_for_row(worksheet, row_number, header_map))
        cropped.save(output_path, "JPEG", quality=95)

    set_cell_value(worksheet, row_number, header_map, HEADERS["crop_path"], str(output_path))
    set_cell_value(worksheet, row_number, header_map, HEADERS["should_search"], "是")
    set_cell_value(worksheet, row_number, header_map, HEADERS["search_status"], "已裁剪")
    set_cell_value(worksheet, row_number, header_map, HEADERS["note"], NOTE_CROPPED)
    return output_path


def download_image_as_jpg(url, output_path):
    if not text_value(url):
        raise ValueError("商品图片链接为空。")
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36"
        )
    }
    response = requests.get(url, headers=headers, timeout=20)
    response.raise_for_status()
    with tempfile.NamedTemporaryFile(delete=False) as temp_file:
        temp_path = Path(temp_file.name)
        temp_file.write(response.content)
    try:
        with Image.open(temp_path) as image:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            image.convert("RGB").save(output_path, "JPEG", quality=95)
    finally:
        try:
            temp_path.unlink()
        except OSError:
            pass
    if not output_path.exists() or output_path.stat().st_size <= 0:
        raise ValueError("图片保存失败，文件不存在或为空。")
    return output_path


def write_image_download_failure(worksheet, row_number, header_map, exc):
    set_cell_value(worksheet, row_number, header_map, HEADERS["note"], f"图片下载失败：{exc}")


def download_image_for_row(worksheet, row_number, header_map):
    image_url = get_cell_value(worksheet, row_number, header_map, HEADERS["image_url"])
    if not text_value(image_url):
        raise ValueError("商品图片链接为空。")
    output_path = original_image_path_for_row(worksheet, row_number, header_map)
    try:
        download_image_as_jpg(image_url, output_path)
    except Exception as exc:
        write_image_download_failure(worksheet, row_number, header_map, exc)
        raise
    set_cell_value(worksheet, row_number, header_map, HEADERS["local_image"], str(output_path))
    set_cell_value(worksheet, row_number, header_map, HEADERS["note"], NOTE_IMAGE_DOWNLOADED)
    return output_path


def local_image_missing(worksheet, row_number, header_map):
    local_path = get_cell_value(worksheet, row_number, header_map, HEADERS["local_image"])
    return resolve_image_path(local_path) is None


def batch_download_missing_images(worksheet, header_map):
    success_count = 0
    failure_count = 0
    for row_number in range(2, worksheet.max_row + 1):
        image_url = get_cell_value(worksheet, row_number, header_map, HEADERS["image_url"])
        if not text_value(image_url) or not local_image_missing(worksheet, row_number, header_map):
            continue
        try:
            download_image_for_row(worksheet, row_number, header_map)
            success_count += 1
        except Exception:
            failure_count += 1
    return success_count, failure_count


def mark_join_search(worksheet, row_number, header_map):
    set_cell_value(worksheet, row_number, header_map, HEADERS["should_search"], "是")
    set_cell_value(worksheet, row_number, header_map, HEADERS["search_status"], "未搜")


def mark_skip(worksheet, row_number, header_map):
    set_cell_value(worksheet, row_number, header_map, HEADERS["should_search"], "否")
    set_cell_value(worksheet, row_number, header_map, HEADERS["search_status"], "跳过")


class SearchPrepApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Fastmoss 搜款前准备")
        self.root.geometry("1180x760")

        self.workbook = None
        self.worksheet = None
        self.header_map = {}
        self.rows = []
        self.current_row_number = None
        self.current_image_path = None
        self.original_image = None
        self.tk_image = None
        self.image_origin = (0, 0)
        self.image_scale = 1
        self.selection_start = None
        self.selection_rect = None
        self.selection_box = None

        self.build_ui()
        self.load_table()

    def build_ui(self):
        main = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = ttk.Frame(main, width=420)
        right_frame = ttk.Frame(main)
        main.add(left_frame, weight=1)
        main.add(right_frame, weight=3)

        self.tree = ttk.Treeview(
            left_frame,
            columns=("row", "title", "should", "status"),
            show="headings",
            height=24,
        )
        self.tree.heading("row", text="行号")
        self.tree.heading("title", text="商品标题")
        self.tree.heading("should", text="是否进入搜款")
        self.tree.heading("status", text="搜款状态")
        self.tree.column("row", width=58, anchor=tk.CENTER)
        self.tree.column("title", width=230, anchor=tk.W)
        self.tree.column("should", width=90, anchor=tk.CENTER)
        self.tree.column("status", width=90, anchor=tk.CENTER)
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)

        button_bar = ttk.Frame(left_frame)
        button_bar.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(button_bar, text="加入搜款", command=self.join_search).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(button_bar, text="跳过", command=self.skip_product).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(button_bar, text="保存表格", command=self.save_table).pack(side=tk.RIGHT)

        download_bar = ttk.Frame(left_frame)
        download_bar.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(download_bar, text="下载当前商品图片", command=self.download_current_image).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(download_bar, text="批量下载缺失图片", command=self.download_missing_images).pack(side=tk.LEFT)

        export_bar = ttk.Frame(left_frame)
        export_bar.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(export_bar, text="导出搜款任务队列", command=self.export_search_queue).pack(fill=tk.X)

        info_frame = ttk.Frame(right_frame)
        info_frame.pack(fill=tk.X)
        ttk.Button(info_frame, text="保存裁剪图", command=self.save_crop).pack(side=tk.RIGHT, padx=(8, 0))
        self.title_label = ttk.Label(info_frame, text="请选择左侧商品", wraplength=720)
        self.title_label.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.canvas = tk.Canvas(right_frame, bg="#f5f5f5", highlightthickness=1, highlightbackground="#cccccc")
        self.canvas.pack(fill=tk.BOTH, expand=True, pady=(8, 0))
        self.canvas.bind("<ButtonPress-1>", self.on_mouse_down)
        self.canvas.bind("<B1-Motion>", self.on_mouse_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
        self.canvas.bind("<Configure>", self.redraw_image)

        self.status_var = tk.StringVar(value="")
        ttk.Label(right_frame, textvariable=self.status_var).pack(fill=tk.X, pady=(6, 0))

    def load_table(self):
        try:
            self.workbook, self.worksheet, self.header_map = load_standard_workbook(STANDARD_FILE)
            self.rows = read_product_rows(self.worksheet, self.header_map)
        except Exception as exc:
            messagebox.showerror("打开失败", str(exc))
            self.root.destroy()
            return
        self.refresh_tree()
        self.status_var.set(f"已读取标准表：{STANDARD_FILE}")

    def refresh_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for row in self.rows:
            self.tree.insert(
                "",
                tk.END,
                iid=str(row["row_number"]),
                values=(row["row_number"], row["title"], row["should_search"], row["status"]),
            )

    def refresh_one_row(self, row_number):
        self.rows = read_product_rows(self.worksheet, self.header_map)
        values_by_row = {row["row_number"]: row for row in self.rows}
        row = values_by_row.get(row_number)
        if row and self.tree.exists(str(row_number)):
            self.tree.item(
                str(row_number),
                values=(row["row_number"], row["title"], row["should_search"], row["status"]),
            )

    def on_tree_select(self, _event=None):
        selected = self.tree.selection()
        if not selected:
            return
        self.current_row_number = int(selected[0])
        title = text_value(get_cell_value(self.worksheet, self.current_row_number, self.header_map, HEADERS["title"]))
        raw_image_path = get_cell_value(self.worksheet, self.current_row_number, self.header_map, HEADERS["local_image"])
        self.title_label.config(text=f"第 {self.current_row_number} 行：{title}")
        self.load_image(raw_image_path)

    def load_image(self, raw_image_path):
        self.current_image_path = resolve_image_path(raw_image_path)
        self.original_image = None
        self.tk_image = None
        self.selection_start = None
        self.selection_box = None
        self.canvas.delete("all")
        if self.current_image_path is None:
            self.canvas.create_text(30, 30, anchor=tk.NW, text="图片不存在", fill="#444444", font=("Microsoft YaHei UI", 16))
            self.status_var.set("图片不存在：本地图片路径为空或文件不存在。")
            return
        try:
            self.original_image = Image.open(self.current_image_path).convert("RGB")
        except Exception as exc:
            self.canvas.create_text(30, 30, anchor=tk.NW, text=f"图片打开失败：{exc}", fill="#444444")
            self.status_var.set("图片打开失败。")
            return
        self.status_var.set(f"已显示图片：{self.current_image_path}")
        self.redraw_image()

    def redraw_image(self, _event=None):
        if self.original_image is None:
            return
        self.canvas.delete("all")
        canvas_width = max(self.canvas.winfo_width(), 1)
        canvas_height = max(self.canvas.winfo_height(), 1)
        scale = min(canvas_width / self.original_image.width, canvas_height / self.original_image.height, 1)
        display_width = max(1, int(self.original_image.width * scale))
        display_height = max(1, int(self.original_image.height * scale))
        display_image = self.original_image.resize((display_width, display_height), Image.LANCZOS)
        self.tk_image = ImageTk.PhotoImage(display_image)
        origin_x = (canvas_width - display_width) // 2
        origin_y = (canvas_height - display_height) // 2
        self.image_origin = (origin_x, origin_y)
        self.image_scale = scale
        self.canvas.create_image(origin_x, origin_y, anchor=tk.NW, image=self.tk_image)
        if self.selection_box:
            x1, y1, x2, y2 = self.original_to_canvas_box(self.selection_box)
            self.selection_rect = self.canvas.create_rectangle(x1, y1, x2, y2, outline="#ff3b30", width=2)

    def canvas_to_original_point(self, x, y):
        origin_x, origin_y = self.image_origin
        image_x = int((x - origin_x) / self.image_scale)
        image_y = int((y - origin_y) / self.image_scale)
        image_x = max(0, min(image_x, self.original_image.width))
        image_y = max(0, min(image_y, self.original_image.height))
        return image_x, image_y

    def original_to_canvas_box(self, box):
        origin_x, origin_y = self.image_origin
        left, top, right, bottom = box
        return (
            origin_x + left * self.image_scale,
            origin_y + top * self.image_scale,
            origin_x + right * self.image_scale,
            origin_y + bottom * self.image_scale,
        )

    def on_mouse_down(self, event):
        if self.original_image is None:
            return
        self.selection_start = self.canvas_to_original_point(event.x, event.y)
        self.selection_box = None
        if self.selection_rect:
            self.canvas.delete(self.selection_rect)
            self.selection_rect = None

    def on_mouse_drag(self, event):
        if self.original_image is None or self.selection_start is None:
            return
        current = self.canvas_to_original_point(event.x, event.y)
        left = min(self.selection_start[0], current[0])
        top = min(self.selection_start[1], current[1])
        right = max(self.selection_start[0], current[0])
        bottom = max(self.selection_start[1], current[1])
        self.selection_box = (left, top, right, bottom)
        if self.selection_rect:
            self.canvas.delete(self.selection_rect)
        x1, y1, x2, y2 = self.original_to_canvas_box(self.selection_box)
        self.selection_rect = self.canvas.create_rectangle(x1, y1, x2, y2, outline="#ff3b30", width=2)

    def on_mouse_up(self, event):
        self.on_mouse_drag(event)

    def save_crop(self):
        if self.current_row_number is None:
            messagebox.showwarning("未选择商品", "请先选择一个商品。")
            return
        if self.current_image_path is None:
            messagebox.showwarning("图片不存在", "当前商品图片不存在，无法裁剪。")
            return
        if not self.selection_box:
            messagebox.showwarning("未框选主体", "请先在图片上拖拽框选主体。")
            return
        try:
            output_path = save_crop_for_row(
                self.worksheet,
                self.current_row_number,
                self.header_map,
                self.current_image_path,
                self.selection_box,
            )
            self.refresh_one_row(self.current_row_number)
            self.status_var.set(f"裁剪图已保存：{output_path}")
            messagebox.showinfo("已保存裁剪图", f"裁剪图已保存：\n{output_path}\n\n请点击“保存表格”写回 Excel。")
        except Exception as exc:
            messagebox.showerror("保存失败", str(exc))

    def join_search(self):
        if self.current_row_number is None:
            messagebox.showwarning("未选择商品", "请先选择一个商品。")
            return
        mark_join_search(self.worksheet, self.current_row_number, self.header_map)
        self.refresh_one_row(self.current_row_number)
        self.status_var.set("已标记为：进入搜款 / 未搜。")

    def skip_product(self):
        if self.current_row_number is None:
            messagebox.showwarning("未选择商品", "请先选择一个商品。")
            return
        mark_skip(self.worksheet, self.current_row_number, self.header_map)
        self.refresh_one_row(self.current_row_number)
        self.status_var.set("已标记为：不进入搜款 / 跳过。")

    def download_current_image(self):
        if self.current_row_number is None:
            messagebox.showwarning("未选择商品", "请先选择一个商品。")
            return
        image_url = get_cell_value(self.worksheet, self.current_row_number, self.header_map, HEADERS["image_url"])
        if not text_value(image_url):
            messagebox.showwarning("商品图片链接为空", "商品图片链接为空。")
            return
        try:
            output_path = download_image_for_row(self.worksheet, self.current_row_number, self.header_map)
            self.refresh_one_row(self.current_row_number)
            self.load_image(str(output_path))
            self.status_var.set(f"商品图片已下载：{output_path}")
            messagebox.showinfo("下载成功", f"商品图片已下载：\n{output_path}\n\n请点击“保存表格”写回 Excel。")
        except Exception as exc:
            self.refresh_one_row(self.current_row_number)
            self.status_var.set(f"图片下载失败：{exc}")
            messagebox.showerror("下载失败", f"图片下载失败：{exc}")

    def download_missing_images(self):
        if not messagebox.askyesno("批量下载缺失图片", "开始批量下载缺失的商品图片？"):
            return
        try:
            success_count, failure_count = batch_download_missing_images(self.worksheet, self.header_map)
            self.rows = read_product_rows(self.worksheet, self.header_map)
            self.refresh_tree()
            if self.current_row_number and self.tree.exists(str(self.current_row_number)):
                self.tree.selection_set(str(self.current_row_number))
                raw_image_path = get_cell_value(self.worksheet, self.current_row_number, self.header_map, HEADERS["local_image"])
                self.load_image(raw_image_path)
            self.status_var.set(f"批量下载完成：成功 {success_count}，失败 {failure_count}")
            messagebox.showinfo("批量下载完成", f"成功：{success_count}\n失败：{failure_count}\n\n请点击“保存表格”写回 Excel。")
        except Exception as exc:
            messagebox.showerror("批量下载失败", str(exc))

    def save_table(self):
        try:
            self.workbook.save(STANDARD_FILE)
            self.status_var.set(f"表格已保存：{STANDARD_FILE}")
            messagebox.showinfo("保存成功", f"表格已保存：\n{STANDARD_FILE}")
        except Exception as exc:
            messagebox.showerror("保存失败", str(exc))

    def export_search_queue(self):
        try:
            export_result = export_search_task_files(
                self.worksheet,
                self.header_map,
            )
            new_count = export_result["new_count"]
            existing_count = export_result["existing_count"]
            total_count = export_result["total_count"]
            backup_dir = export_result["backup_dir"]
            self.status_var.set(
                f"任务队列增量导出完成：新增 {new_count} 条，当前共 {total_count} 条"
            )
            if total_count == 0:
                messagebox.showwarning(
                    "没有可导出的搜款任务",
                    "没有可导出的搜款任务。\n\n"
                    "已有搜款结果表未被清空。\n"
                    f"备份位置：\n{backup_dir}",
                )
                return
            result_message = (
                "已有搜款结果表未被清空。"
                if export_result["result_preserved"]
                else "搜款结果表原不存在，已创建空模板。"
            )
            messagebox.showinfo(
                "增量导出完成",
                "任务队列增量导出完成：\n"
                f"新增任务：{new_count} 条\n"
                f"已存在任务：{existing_count} 条\n"
                f"当前任务总数：{total_count} 条\n\n"
                "已有任务ID和任务状态已保留。\n"
                f"{result_message}\n"
                f"备份位置：\n{backup_dir}",
            )
        except Exception as exc:
            messagebox.showerror("导出失败", str(exc))


def run_self_test():
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        workbook_copy = tmp_path / "Fastmoss_test.xlsx"
        shutil.copy2(STANDARD_FILE, workbook_copy)
        workbook, worksheet, header_map = load_standard_workbook(workbook_copy)

        rows = read_product_rows(worksheet, header_map)
        if not rows:
            raise AssertionError("标准表没有可读取的商品行。")
        if CROP_HEADER not in header_map:
            raise AssertionError("未能新增主体裁剪图路径列。")
        for row in rows:
            set_cell_value(
                worksheet,
                row["row_number"],
                header_map,
                HEADERS["should_search"],
                "否",
            )
            set_cell_value(
                worksheet,
                row["row_number"],
                header_map,
                HEADERS["search_status"],
                "跳过",
            )
            set_cell_value(
                worksheet,
                row["row_number"],
                header_map,
                HEADERS["crop_path"],
                "",
            )

        sample_images = sorted((ROOT_DIR / "03_商品图片").glob("*.png"))
        if not sample_images:
            raise AssertionError("未找到可用于测试的本地图片。")

        row_number = rows[0]["row_number"]
        set_cell_value(worksheet, row_number, header_map, HEADERS["local_image"], str(sample_images[0]))
        resolved = resolve_image_path(get_cell_value(worksheet, row_number, header_map, HEADERS["local_image"]))
        if resolved is None:
            raise AssertionError("本地图片路径解析失败。")

        with Image.open(resolved) as image:
            right = min(80, image.width)
            bottom = min(80, image.height)
        output_path = save_crop_for_row(worksheet, row_number, header_map, resolved, (0, 0, right, bottom))
        image_url = get_cell_value(worksheet, row_number, header_map, HEADERS["image_url"])
        downloaded_path = download_image_for_row(worksheet, row_number, header_map)
        bad_row_number = rows[-1]["row_number"]
        set_cell_value(worksheet, bad_row_number, header_map, HEADERS["image_url"], "http://127.0.0.1:9/not-found.jpg")
        set_cell_value(worksheet, bad_row_number, header_map, HEADERS["local_image"], "")
        try:
            download_image_for_row(worksheet, bad_row_number, header_map)
        except Exception:
            pass
        else:
            raise AssertionError("无效图片链接应下载失败。")
        for row in rows:
            if row["row_number"] == row_number:
                continue
            set_cell_value(worksheet, row["row_number"], header_map, HEADERS["image_url"], "")
            set_cell_value(worksheet, row["row_number"], header_map, HEADERS["local_image"], "")
        batch_success_row = rows[1]["row_number"]
        batch_failure_row = rows[2]["row_number"]
        set_cell_value(worksheet, batch_success_row, header_map, HEADERS["image_url"], image_url)
        set_cell_value(worksheet, batch_failure_row, header_map, HEADERS["image_url"], "http://127.0.0.1:9/not-found.jpg")
        batch_success_count, batch_failure_count = batch_download_missing_images(worksheet, header_map)
        mark_join_search(worksheet, row_number, header_map)
        mark_skip(worksheet, row_number, header_map)

        valid_row = rows[4]["row_number"]
        missing_crop_row = rows[5]["row_number"]
        nonexistent_crop_row = rows[6]["row_number"]
        wrong_status_row = rows[7]["row_number"]
        relative_crop_path = output_path.relative_to(ROOT_DIR)
        set_cell_value(worksheet, valid_row, header_map, HEADERS["should_search"], "是")
        set_cell_value(worksheet, valid_row, header_map, HEADERS["search_status"], "已裁剪")
        set_cell_value(worksheet, valid_row, header_map, HEADERS["crop_path"], str(relative_crop_path))
        set_cell_value(worksheet, missing_crop_row, header_map, HEADERS["should_search"], "是")
        set_cell_value(worksheet, missing_crop_row, header_map, HEADERS["search_status"], "已裁剪")
        set_cell_value(worksheet, missing_crop_row, header_map, HEADERS["crop_path"], "")
        set_cell_value(worksheet, nonexistent_crop_row, header_map, HEADERS["should_search"], "是")
        set_cell_value(worksheet, nonexistent_crop_row, header_map, HEADERS["search_status"], "未搜")
        set_cell_value(
            worksheet,
            nonexistent_crop_row,
            header_map,
            HEADERS["crop_path"],
            "images/crop_subject/not_exists.jpg",
        )
        set_cell_value(worksheet, wrong_status_row, header_map, HEADERS["should_search"], "是")
        set_cell_value(worksheet, wrong_status_row, header_map, HEADERS["search_status"], "已搜")
        set_cell_value(worksheet, wrong_status_row, header_map, HEADERS["crop_path"], str(relative_crop_path))
        task_queue_test = tmp_path / "1688_queue_test.xlsx"
        search_results_test = tmp_path / "1688_results_test.xlsx"
        manual_summary_test = tmp_path / "1688_summary_test.xlsx"
        backup_test_dir = tmp_path / "backup"
        first_export = export_search_task_files(
            worksheet,
            header_map,
            task_queue_test,
            search_results_test,
            manual_summary_test,
            backup_test_dir,
        )
        exported_count = first_export["new_count"]
        workbook.save(workbook_copy)
        workbook.close()

        verify_wb = load_workbook(workbook_copy, data_only=True)
        verify_ws = verify_wb.active
        verify_headers = get_header_map(verify_ws)
        values = {
            header: verify_ws.cell(row_number, verify_headers[header]).value
            for header in [CROP_HEADER, HEADERS["local_image"], HEADERS["should_search"], HEADERS["search_status"], HEADERS["note"]]
        }
        bad_local_path = verify_ws.cell(bad_row_number, verify_headers[HEADERS["local_image"]]).value
        bad_note = verify_ws.cell(bad_row_number, verify_headers[HEADERS["note"]]).value
        batch_local_path = verify_ws.cell(batch_success_row, verify_headers[HEADERS["local_image"]]).value
        batch_bad_local_path = verify_ws.cell(batch_failure_row, verify_headers[HEADERS["local_image"]]).value
        verify_wb.close()

        queue_wb = load_workbook(task_queue_test, data_only=True)
        queue_ws = queue_wb.active
        queue_headers = [queue_ws.cell(1, col).value for col in range(1, queue_ws.max_column + 1)]
        queue_values = [queue_ws.cell(2, col).value for col in range(1, queue_ws.max_column + 1)]
        queue_wb.close()
        result_wb = load_workbook(search_results_test, data_only=True)
        result_ws = result_wb.active
        result_headers = [result_ws.cell(1, col).value for col in range(1, result_ws.max_column + 1)]
        result_row_count = result_ws.max_row
        result_wb.close()

        if not output_path.exists():
            raise AssertionError("裁剪图未生成。")
        if resolve_image_path(values[CROP_HEADER]) != output_path:
            raise AssertionError("主体裁剪图路径未正确写入。")
        if not downloaded_path.exists() or downloaded_path.stat().st_size <= 0:
            raise AssertionError("商品图片未成功下载。")
        if values[HEADERS["local_image"]] != str(downloaded_path):
            raise AssertionError("本地图片路径未正确写入。")
        if values[HEADERS["should_search"]] != "否":
            raise AssertionError("跳过状态未正确写入是否进入搜款。")
        if values[HEADERS["search_status"]] != "跳过":
            raise AssertionError("跳过状态未正确写入搜款状态。")
        if bad_local_path:
            raise AssertionError("下载失败时不应写入本地图片路径。")
        if not text_value(bad_note).startswith("图片下载失败："):
            raise AssertionError("下载失败备注未正确写入。")
        if (batch_success_count, batch_failure_count) != (1, 1):
            raise AssertionError("批量下载成功/失败数量不正确。")
        if not batch_local_path or not Path(batch_local_path).exists():
            raise AssertionError("批量下载未写入有效本地图片路径。")
        if batch_bad_local_path:
            raise AssertionError("批量下载失败时不应写入本地图片路径。")
        if exported_count != 1:
            raise AssertionError("任务队列筛选数量不正确。")
        if queue_headers != TASK_QUEUE_HEADERS:
            raise AssertionError("任务队列表头不正确。")
        if queue_values[0] != "SEARCH_000001" or queue_values[1] != valid_row:
            raise AssertionError("任务ID或源表行号不正确。")
        if queue_values[5] != str(output_path) or queue_values[10] != "待搜款":
            raise AssertionError("任务队列字段值不正确。")
        if result_headers != SEARCH_RESULT_HEADERS or result_row_count != 1:
            raise AssertionError("搜款结果表模板不正确。")

        queue_wb = load_workbook(task_queue_test)
        queue_ws = queue_wb.active
        queue_header_map = get_header_map(queue_ws)
        set_cell_value(
            queue_ws,
            2,
            queue_header_map,
            "任务状态",
            "已搜索",
        )
        queue_wb.save(task_queue_test)
        queue_wb.close()

        result_wb = load_workbook(search_results_test)
        result_ws = result_wb.active
        result_ws.append(
            [
                "SEARCH_000001",
                valid_row,
                "TEST001",
                "SPU001",
                "测试商品",
                "https://example.com/fastmoss",
                str(output_path),
                "已搜索",
                1,
                "测试1688商品",
                "https://detail.1688.com/offer/test.html",
                "",
                "",
                10,
                1,
                "测试供应商",
                "",
                "疑似同款",
                "人工填写",
                "测试结果",
            ]
        )
        result_wb.save(search_results_test)
        result_wb.close()
        save_output_workbook(
            manual_summary_test,
            "人工搜款汇总",
            ["任务ID", "备注"],
            [["SEARCH_000001", "测试汇总"]],
        )
        result_bytes_before = search_results_test.read_bytes()
        summary_bytes_before = manual_summary_test.read_bytes()

        incremental_row = rows[8]["row_number"]
        set_cell_value(
            worksheet,
            incremental_row,
            header_map,
            HEADERS["product_id"],
            "INCREMENTAL_TEST_002",
        )
        set_cell_value(
            worksheet,
            incremental_row,
            header_map,
            HEADERS["should_search"],
            "是",
        )
        set_cell_value(
            worksheet,
            incremental_row,
            header_map,
            HEADERS["search_status"],
            "未搜",
        )
        set_cell_value(
            worksheet,
            incremental_row,
            header_map,
            HEADERS["crop_path"],
            str(relative_crop_path),
        )
        second_export = export_search_task_files(
            worksheet,
            header_map,
            task_queue_test,
            search_results_test,
            manual_summary_test,
            backup_test_dir,
        )
        if (
            second_export["new_count"],
            second_export["existing_count"],
            second_export["total_count"],
        ) != (1, 1, 2):
            raise AssertionError("增量导出新增/已有/总任务数量不正确。")
        if not second_export["result_preserved"]:
            raise AssertionError("已有搜款结果表未被识别为保留状态。")
        if len(second_export["backup_paths"]) != 3:
            raise AssertionError("任务队列、结果表和人工汇总表未全部备份。")
        if search_results_test.read_bytes() != result_bytes_before:
            raise AssertionError("增量导出修改了已有搜款结果表。")
        if manual_summary_test.read_bytes() != summary_bytes_before:
            raise AssertionError("增量导出修改了人工汇总表。")

        incremental_wb = load_workbook(task_queue_test, read_only=True, data_only=True)
        incremental_ws = incremental_wb.active
        incremental_header_map = get_header_map(incremental_ws)
        incremental_ids = [
            incremental_ws.cell(row, incremental_header_map["任务ID"]).value
            for row in range(2, incremental_ws.max_row + 1)
        ]
        incremental_statuses = [
            incremental_ws.cell(row, incremental_header_map["任务状态"]).value
            for row in range(2, incremental_ws.max_row + 1)
        ]
        incremental_wb.close()
        if incremental_ids != ["SEARCH_000001", "SEARCH_000002"]:
            raise AssertionError("新任务ID未从已有最大编号继续递增。")
        if incremental_statuses != ["已搜索", "待搜款"]:
            raise AssertionError("旧任务状态未保留或新任务状态不正确。")

        third_export = export_search_task_files(
            worksheet,
            header_map,
            task_queue_test,
            search_results_test,
            manual_summary_test,
            backup_test_dir,
        )
        if (
            third_export["new_count"],
            third_export["existing_count"],
            third_export["total_count"],
        ) != (0, 2, 2):
            raise AssertionError("重复导出时仍然新增了重复任务。")
        if search_results_test.read_bytes() != result_bytes_before:
            raise AssertionError("重复导出修改了已有搜款结果表。")
        if manual_summary_test.read_bytes() != summary_bytes_before:
            raise AssertionError("重复导出修改了人工汇总表。")

        blocked_backup_dir = tmp_path / "blocked_backup"
        blocked_backup_dir.write_text("not a directory", encoding="utf-8")
        queue_bytes_before_failure = task_queue_test.read_bytes()
        try:
            export_search_task_files(
                worksheet,
                header_map,
                task_queue_test,
                search_results_test,
                manual_summary_test,
                blocked_backup_dir,
            )
        except OSError:
            pass
        else:
            raise AssertionError("备份失败时应停止增量导出。")
        if task_queue_test.read_bytes() != queue_bytes_before_failure:
            raise AssertionError("备份失败后任务队列仍被修改。")
        if search_results_test.read_bytes() != result_bytes_before:
            raise AssertionError("备份失败后结果表仍被修改。")
        if manual_summary_test.read_bytes() != summary_bytes_before:
            raise AssertionError("备份失败后人工汇总表仍被修改。")
        missing_header_map = dict(header_map)
        missing_header_map.pop(HEADERS["crop_path"])
        try:
            collect_search_tasks(worksheet, missing_header_map)
        except ValueError as exc:
            if HEADERS["crop_path"] not in str(exc):
                raise AssertionError("缺少必要列时的提示不清楚。") from exc
        else:
            raise AssertionError("缺少必要列时应停止导出。")
        print("SELF_TEST_OK")
        print(f"rows={len(rows)}")
        print(f"sample_image={resolved}")
        print(f"image_url={image_url}")
        print(f"downloaded_path={downloaded_path}")
        print(f"batch_downloaded_path={batch_local_path}")
        print(f"crop_path={output_path}")
        print(f"exported_tasks={exported_count}")
        print("incremental_export=OK")
        print("existing_status_preserved=OK")
        print("result_protection=OK")
        print("summary_protection=OK")
        print("backup_failure_stop=OK")
        print(f"task_queue={task_queue_test}")
        print(f"search_results={search_results_test}")


def main():
    parser = argparse.ArgumentParser(description="Fastmoss 搜款前准备工具")
    parser.add_argument("--self-test", action="store_true", help="运行非界面自测")
    args = parser.parse_args()

    if args.self_test:
        run_self_test()
        return 0

    root = tk.Tk()
    SearchPrepApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
