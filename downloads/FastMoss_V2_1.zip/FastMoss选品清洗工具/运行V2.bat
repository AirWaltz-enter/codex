@echo off
chcp 65001 >nul
call "%~dp004_脚本\运行清洗.bat" %*
exit /b %ERRORLEVEL%
