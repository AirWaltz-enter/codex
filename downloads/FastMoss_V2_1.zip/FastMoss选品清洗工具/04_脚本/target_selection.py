"""Strict product audience/type checks. Images require explicit product-style review."""
import hashlib
import re


IMAGE_AUDIT_OPTIONS = ["待审核", "确认女士运动外套", "男款", "卫衣", "非运动外套", "无法确认"]
TARGET_HEADERS = ["目标分类", "适用人群判定", "服装类型判定", "目标匹配依据", "图片款式审核", "图片审核指纹"]


def audit_fingerprint(record):
    # An unchanged product ID alone must not preserve review of a different image/title.
    parts = [str(record.get(k) or "").strip() for k in ("商品名称", "商品分类", "_image_url", "_image_signature")]
    return hashlib.sha256("\x1f".join(parts).encode()).hexdigest()


def evaluate_target(record, config, manual, hit):
    hard, review = [], []
    fingerprint = audit_fingerprint(record)
    audit = manual.get("图片款式审核") or "待审核"
    if audit not in IMAGE_AUDIT_OPTIONS:
        audit = "待审核"
        review.append("图片款式审核值无效，已重置待审核")
    if audit != "待审核" and manual.get("图片审核指纹") != fingerprint:
        audit = "待审核"
        review.append("标题、类目或图片来源已变化，图片款式需重新审核")
    data = {"目标分类": config.get("target_name", "女士运动服饰"), "图片款式审核": audit,
            "图片审核指纹": fingerprint, "_target_enabled": config.get("enabled", False),
            "_target_has_outerwear": False}
    if not config.get("enabled"):
        data.update({"目标分类": "女士运动服饰（宽泛模式）", "适用人群判定": "未启用严格判定",
                     "服装类型判定": "未启用严格判定", "目标匹配依据": "target_config.enabled=false"})
        return data, [], []
    title = str(record.get("商品名称") or "")
    category = str(record.get("商品分类") or "")
    content = title + " " + category
    def hits(key, value=content):
        return [word for word in config[key] if hit(value, word)]
    female, male = hits("female_keywords"), hits("male_keywords")
    # Match standalone Chinese gender labels, including compact catalog paths.
    if re.search(r"(?:^|[\s/＞>\-（(])女(?:$|[\s/＞>\-）)])", content) or re.search(r"(?:外套|夹克|风衣)女(?:款|式|$)", title):
        female.append("女类目标注")
    if re.search(r"(?:^|[\s/＞>\-（(])男(?:$|[\s/＞>\-）)])", content) or re.search(r"(?:外套|夹克|风衣)男(?:款|式|$)", title):
        male.append("男类目标注")
    unisex, children = hits("unisex_keywords"), hits("children_keywords")
    sweatshirt = hits("sweatshirt_keywords")
    outer_title = hits("outerwear_keywords", title)
    outer_category = hits("outerwear_keywords", category)
    other_title = hits("other_garment_keywords", title)
    other_category = hits("other_garment_keywords", category)
    non_sport, sport = hits("non_sport_keywords"), hits("sport_keywords")
    confirmed = audit == "确认女士运动外套"
    if male:
        hard.append("目标硬排除：明确男款/混合人群词（" + "、".join(male) + "）")
    if unisex:
        hard.append("目标硬排除：男女同款/中性款不属于专门女款（" + "、".join(unisex) + "）")
    if children:
        hard.append("目标硬排除：儿童款（" + "、".join(children) + "）")
    if sweatshirt:
        hard.append("目标硬排除：卫衣/套头衫（" + "、".join(sweatshirt) + "）")
    if non_sport:
        hard.append("目标硬排除：非运动外套款式（" + "、".join(non_sport) + "）")
    if audit in ("男款", "卫衣", "非运动外套"):
        hard.append("图片款式人工排除：" + audit)
    if sweatshirt:
        kind = "卫衣/套头衫"
    elif (outer_title and (other_title or other_category)) or (outer_category and other_title):
        kind = "外套（人工确认）" if confirmed else "外套/其他品类冲突或组合款"
        if not confirmed:
            review.append("标题与类目冲突或含其他服装品类，需确认是否独立运动外套")
    elif outer_title or outer_category:
        kind = "外套"
        if outer_category and not outer_title and not confirmed:
            review.append("仅类目标注外套，标题未明确款式")
    elif other_title or other_category:
        kind = "非外套"
        hard.append("目标硬排除：裤子/文胸/上衣等非外套品类（" + "、".join(dict.fromkeys(other_title + other_category)) + "）")
    elif confirmed:
        kind = "外套（人工确认）"
    else:
        kind = "款式未明确"
        review.append("缺少明确外套信息，需图片款式审核")
    if not female and not confirmed:
        review.append("缺少女款标注，适用人群待确认")
    if not sport and not confirmed:
        review.append("未发现明确运动用途，需确认运动外套款式")
    if not record.get("_image_url") and not record.get("_image_signature"):
        review.append("图片来源缺失，无法确认图片款式")
    if config["require_image_review"] and not confirmed:
        review.append("图片款式未确认为女士运动外套" if audit == "待审核" else "图片款式无法确认")
    data.update({"适用人群判定": "男款/混合人群" if male or unisex else "儿童款" if children else "女款明示" if female else "女款（人工确认）" if confirmed else "人群未明确",
                 "服装类型判定": kind,
                 "目标匹配依据": "；".join(["女款词=" + ("、".join(female) or "无"), "男款词=" + ("、".join(male) or "无"),
                                          "标题外套词=" + ("、".join(outer_title) or "无"), "类目外套词=" + ("、".join(outer_category) or "无"),
                                          "运动词=" + ("、".join(sport) or "无"), "卫衣词=" + ("、".join(sweatshirt) or "无")]),
                 "_target_has_outerwear": kind in ("外套", "外套（人工确认）")})
    return data, hard, review
