import copy
import argparse
import hashlib
import io
import math
import os
import re
import shutil
import sys
import traceback
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse

from v2_config import load_config
from potential_scoring import V2_HEADERS, context_for, record_key, score_record


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
RAW_DIR = ROOT_DIR / "01_FastMoss原始表"
OUTPUT_DIR = ROOT_DIR / "02_筛选后表格"
IMAGE_DIR = ROOT_DIR / "03_商品图片"
CLEANED_DIR = ROOT_DIR / "cleaned"
STANDARD_SEARCH_FILE = CLEANED_DIR / "Fastmoss_待搜款清洗表.xlsx"
BACKUP_DIR = ROOT_DIR / "backup"
PROGRESS_LOG = ROOT_DIR / "清洗进度.log"

try:
    import requests
    import xlsxwriter
    from openpyxl import Workbook, load_workbook
    from openpyxl.comments import Comment
    from openpyxl.drawing.image import Image as XLImage
    from openpyxl.drawing.spreadsheet_drawing import AnchorMarker, OneCellAnchor
    from openpyxl.drawing.xdr import XDRPositiveSize2D
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    from openpyxl.utils import get_column_letter
    from openpyxl.utils.datetime import from_excel
    from openpyxl.utils.units import pixels_to_EMU
    from PIL import Image as PILImage
    from selection_report import load_manual_states, save_report
    from light_report import save_light_report
except Exception as exc:
    message = (
        "依赖导入失败，请先运行 04_脚本\\运行清洗.bat 安装依赖。\n"
        f"错误信息：{exc}\n"
    )
    try:
        PROGRESS_LOG.parent.mkdir(parents=True, exist_ok=True)
        with PROGRESS_LOG.open("a", encoding="utf-8") as handle:
            handle.write(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
    except Exception:
        pass
    print(message)
    sys.exit(1)

TODAY = datetime.now(timezone(timedelta(hours=8))).date()
RECENT_DAYS = 90
SKIP_IMAGE_DOWNLOAD = False
NUMERIC_GROWTH_MODE = "percent_points"

FIELD_ALIASES = {
    "商品ID": ["商品ID", "商品 Id", "商品id", "Product ID", "ProductID", "ID"],
    "SPU": ["SPU", "spu"],
    "商品图片": ["商品图片", "商品图", "图片", "主图"],
    "店铺名": ["店铺名", "店铺名称", "商家名", "店铺"],
    "商品售价": ["商品售价", "售价", "价格", "商品价格"],
    "国家/地区": ["国家/地区", "国家", "地区", "市场"],
    "商品分类": ["商品分类", "分类", "类目", "商品类目"],
    "销量": ["近7天销量", "近七天销量", "7天销量", "销量"],
    "销量环比": ["销量环比", "环比", "销量增长", "增长率"],
    "总销量": ["总销量", "累计销量", "总销售"],
    "预估商品上架时间": ["预估商品上架时间", "上架时间", "发布时间", "商品上架时间"],
    "FastMoss 商品详情页": ["FastMoss商品详情页", "商品详情页", "详情页", "商品链接", "链接"],
    "商品状态": ["商品状态", "状态"],
    "商品名称": ["商品名称", "商品标题", "标题", "商品名"],
    "同类商品数量": ["同类商品数量", "同类数量", "Similar product count"],
    "关键词竞争数量": ["关键词竞争数量", "关键词商品数量", "Keyword competition count"],
    "品牌": ["品牌", "品牌名", "Brand"],
}

REQUIRED_FIELDS = ["销量", "预估商品上架时间"]

FILTERED_HEADERS = [
    "商品图片",
    "店铺名",
    "商品售价",
    "国家/地区",
    "商品分类",
    "销量",
    "销量环比",
    "总销量",
    "预估商品上架时间",
    "FastMoss 商品详情页",
    "打开链接",
    "商品状态",
    "商品名称",
    "备注",
] + V2_HEADERS

DELETED_HEADERS = [
    "删除原因",
    "店铺名",
    "商品售价",
    "国家/地区",
    "商品分类",
    "销量",
    "销量环比",
    "总销量",
    "预估商品上架时间",
    "商品状态",
    "商品名称",
    "商品详情页",
] + V2_HEADERS

SAME_1688_HEADERS = [
    "FastMoss编号/商品图",
    "平台",
    "1688主图",
    "工厂/店铺名称",
    "价格",
    "上架时间",
    "30天销量",
    "月代销",
    "年成交件数",
    "年成交笔数",
    "评论数",
    "好评率",
    "揽收率",
    "商品页",
    "备注",
]

STANDARD_SEARCH_HEADERS = [
    "商品ID",
    "SPU",
    "商品标题",
    "商品链接",
    "商品图片链接",
    "本地图片路径",
    "近7天销量",
    "销量环比",
    "商品价格",
    "类目",
    "预估上架时间",
    "是否进入搜款",
    "搜款状态",
    "备注",
    "主体裁剪图路径",
] + V2_HEADERS

PRESERVED_SEARCH_HEADERS = [
    "本地图片路径",
    "主体裁剪图路径",
    "是否进入搜款",
    "搜款状态",
    "备注",
]

HEADER_FILL = PatternFill("solid", fgColor="0F766E")
BODY_FILL = PatternFill("solid", fgColor="E7F4E8")
YELLOW_FILL = PatternFill("solid", fgColor="FFF2CC")
ORANGE_FILL = PatternFill("solid", fgColor="FCE4D6")
RED_FILL = PatternFill("solid", fgColor="FFC7CE")
WHITE_FONT = Font(color="FFFFFF", bold=True)
THIN_SIDE = Side(style="thin", color="B7C9B8")
BORDER = Border(left=THIN_SIDE, right=THIN_SIDE, top=THIN_SIDE, bottom=THIN_SIDE)
CENTER_WRAP = Alignment(horizontal="center", vertical="center", wrap_text=True)


class ProgressLogger:
    def __init__(self, log_path):
        self.log_path = Path(log_path)
        self.last_percent_by_stage = {}
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.log_path.write_text(
            f"FastMoss 清洗进度日志\n开始时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n",
            encoding="utf-8",
        )

    def write(self, message):
        line = f"[{datetime.now().strftime('%H:%M:%S')}] {message}"
        print(line, flush=True)
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")

    def progress(self, stage, current, total, message=""):
        total = max(int(total or 0), 1)
        current = min(max(int(current or 0), 0), total)
        percent = int(current * 100 / total)
        last_percent = self.last_percent_by_stage.get(stage, -1)
        should_log = (
            current == 0
            or current == total
            or percent == 100
            or percent - last_percent >= 5
        )
        if should_log:
            self.last_percent_by_stage[stage] = percent
            suffix = f" - {message}" if message else ""
            self.write(f"{stage}：{current}/{total}（{percent}%）{suffix}")


def normalize_header(value):
    text = "" if value is None else str(value).strip().lower()
    text = text.replace("\n", "").replace("\r", "")
    return re.sub(r"[\s/_\-：:（）()\[\]【】]+", "", text)


ALIAS_TO_FIELD = {}
SORTED_ALIASES = []
for field, aliases in FIELD_ALIASES.items():
    for alias in aliases:
        normalized = normalize_header(alias)
        ALIAS_TO_FIELD[normalized] = field
        SORTED_ALIASES.append((normalized, field))
SORTED_ALIASES.sort(key=lambda item: len(item[0]), reverse=True)


def match_field(header_value):
    normalized = normalize_header(header_value)
    if not normalized:
        return None
    if normalized in ALIAS_TO_FIELD:
        return ALIAS_TO_FIELD[normalized]
    for alias, field in SORTED_ALIASES:
        if len(alias) < 3:
            continue
        if alias in normalized:
            return field
    return None


def find_latest_excel():
    files = []
    for pattern in ("*.xlsx", "*.xlsm"):
        files.extend(RAW_DIR.glob(pattern))
    files = [
        file
        for file in files
        if file.is_file() and not file.name.startswith("~$")
    ]
    if not files:
        return None
    return max(files, key=lambda file: file.stat().st_mtime)


def find_header_row(ws, scan_rows=50):
    best = None
    max_row = min(ws.max_row, scan_rows)
    for row_idx in range(1, max_row + 1):
        field_to_col = {}
        for col_idx in range(1, ws.max_column + 1):
            field = match_field(ws.cell(row_idx, col_idx).value)
            if field and field not in field_to_col:
                field_to_col[field] = col_idx
        score = len(field_to_col)
        required_score = sum(1 for field in REQUIRED_FIELDS if field in field_to_col)
        if not best or (required_score, score) > (best[0], best[1]):
            best = (required_score, score, row_idx, field_to_col)
    if not best or best[1] == 0:
        return None, {}
    return best[2], best[3]


def cell_text(value):
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")
    return str(value).strip()


def get_field_value(ws, row_idx, cols, field):
    col_idx = cols.get(field)
    if not col_idx:
        return None
    return ws.cell(row_idx, col_idx).value


def get_field_cell(ws, row_idx, cols, field):
    col_idx = cols.get(field)
    if not col_idx:
        return None
    return ws.cell(row_idx, col_idx)


def parse_number(value):
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        number = float(value)
        return number if math.isfinite(number) else None
    text = str(value).strip().lower()
    if not text:
        return None
    match = re.fullmatch(r"\s*([+-]?\d+(?:,\d{3})*(?:\.\d+)?)\s*([km万]?)\s*(?:件|个)?\s*", text)
    if not match:
        return None
    number = float(match.group(1).replace(",", "")) * {"": 1, "k": 1000, "m": 1000000, "万": 10000}[match.group(2)]
    return number if math.isfinite(number) else None


def parse_percent(value, number_format=""):
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        number = float(value)
        if not math.isfinite(number):
            return None
        if "%" in str(number_format):
            return number
        return number if NUMERIC_GROWTH_MODE == "fraction" else number / 100
    text = str(value).strip()
    if not text:
        return None
    negative = False
    if text.startswith("(") and text.endswith(")"):
        negative = True
    text = text.replace(",", "")
    match = re.fullmatch(r"\(?\s*([+-]?\d+(?:\.\d+)?)\s*%?\s*\)?", text)
    if not match:
        return None
    number = float(match.group(1))
    if not math.isfinite(number):
        return None
    if negative:
        number = -abs(number)
    if "%" in text:
        return number / 100
    return number if NUMERIC_GROWTH_MODE == "fraction" else number / 100


def parse_date(value):
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, (int, float)):
        try:
            return from_excel(value).date()
        except Exception:
            return None

    text = str(value).strip()
    if not text:
        return None

    relative = re.search(r"(\d+)\s*(天|日)\s*前", text)
    if relative:
        return TODAY - timedelta(days=int(relative.group(1)))
    relative = re.search(r"(\d+)\s*(周|星期)\s*前", text)
    if relative:
        return TODAY - timedelta(days=int(relative.group(1)) * 7)
    relative = re.search(r"(\d+)\s*个?月\s*前", text)
    if relative:
        return TODAY - timedelta(days=int(relative.group(1)) * 30)
    if any(word in text for word in ["今天", "今日"]):
        return TODAY
    if "昨天" in text:
        return TODAY - timedelta(days=1)

    cleaned = text
    cleaned = re.sub(r"[年月.]", "-", cleaned)
    cleaned = re.sub(r"[日号]", "", cleaned)
    cleaned = cleaned.replace("/", "-")
    match = re.search(r"(\d{4}-\d{1,2}-\d{1,2})", cleaned)
    if match:
        cleaned = match.group(1)
    for fmt in ("%Y-%m-%d", "%Y-%m", "%m-%d-%Y", "%m-%d-%y"):
        try:
            parsed = datetime.strptime(cleaned[:10], fmt)
            if fmt == "%Y-%m":
                return date(parsed.year, parsed.month, 1)
            return parsed.date()
        except ValueError:
            continue
    return None


def extract_url_from_cell(cell):
    if cell is None:
        return ""
    if cell.hyperlink and cell.hyperlink.target:
        return str(cell.hyperlink.target).strip()
    value = cell.value
    if value is None:
        return ""
    text = str(value).strip()
    hyperlink_formula = re.search(r'HYPERLINK\(\s*"([^"]+)"', text, flags=re.IGNORECASE)
    if hyperlink_formula:
        return hyperlink_formula.group(1)
    match = re.search(r"https?://[^\s\"<>）)]+", text)
    return match.group(0) if match else text if text.startswith("www.") else ""


def keyword_hit(text, keyword):
    lower_text = text.lower()
    lower_keyword = keyword.lower()
    if re.fullmatch(r"[a-z0-9 ]+", lower_keyword):
        pattern = r"(?<![a-z0-9])" + re.escape(lower_keyword) + r"(?![a-z0-9])"
        return re.search(pattern, lower_text) is not None
    return lower_keyword in lower_text


def matched_keywords(text, keywords):
    return [keyword for keyword in keywords if keyword_hit(text, keyword)]


def safe_filename_part(value, max_len=30):
    text = cell_text(value) or "未知店铺"
    text = re.sub(r'[\\/:*?"<>|]+', "_", text)
    text = re.sub(r"\s+", "_", text).strip("._ ")
    return (text or "未知店铺")[:max_len]


def image_map_by_anchor(ws):
    images = {}
    for image in getattr(ws, "_images", []):
        try:
            anchor = image.anchor._from
            row = anchor.row + 1
            col = anchor.col + 1
            images[(row, col)] = image
        except Exception:
            continue
    return images


def ensure_png_bytes(raw_bytes):
    with PILImage.open(io.BytesIO(raw_bytes)) as image:
        image.thumbnail((300, 300))
        output = io.BytesIO()
        image.convert("RGBA").save(output, format="PNG")
        return output.getvalue()


def bytes_from_excel_image(image):
    try:
        if not hasattr(image, "_v2_cached_bytes"):
            image._v2_cached_bytes = image._data()
        return image._v2_cached_bytes
    except Exception:
        return None


def download_image(url):
    if not url or not re.match(r"^https?://", url, flags=re.IGNORECASE):
        return None
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36"
        )
    }
    response = requests.get(url, headers=headers, timeout=15)
    response.raise_for_status()
    content_type = response.headers.get("Content-Type", "")
    if "image" not in content_type.lower() and not urlparse(url).path.lower().endswith(
        (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp")
    ):
        return None
    return response.content


def save_product_image(raw_bytes, index, sales_value, shop_name):
    png_bytes = ensure_png_bytes(raw_bytes)
    sales_int = int(sales_value or 0)
    file_name = f"FM{index:03d}_销量{sales_int}_{safe_filename_part(shop_name)}.png"
    target = IMAGE_DIR / file_name
    suffix = 1
    while target.exists():
        target = IMAGE_DIR / f"FM{index:03d}_销量{sales_int}_{safe_filename_part(shop_name)}_{suffix}.png"
        suffix += 1
    target.write_bytes(png_bytes)
    return target


def get_row_image_path(ws, row_idx, cols, images_by_anchor, output_index, sales_value, shop_name):
    image_col = cols.get("商品图片")
    raw_bytes = None
    if image_col:
        anchored_image = images_by_anchor.get((row_idx, image_col))
        if anchored_image:
            raw_bytes = bytes_from_excel_image(anchored_image)
        if raw_bytes is None:
            image_cell = ws.cell(row_idx, image_col)
            image_url = extract_url_from_cell(image_cell)
            if image_url and not SKIP_IMAGE_DOWNLOAD:
                raw_bytes = download_image(image_url)
    if raw_bytes is None:
        return None
    return save_product_image(raw_bytes, output_index, sales_value, shop_name)


def prepare_candidate_images(records, source_ws, cols, images_by_anchor, logger):
    logger.progress("准备候选图片", 0, len(records))
    for index, record in enumerate(records, 1):
        image_path = None
        try:
            image_path = get_row_image_path(source_ws, record["_source_row"], cols, images_by_anchor,
                                           index, record.get("_sales"), record.get("店铺名"))
        except Exception as exc:
            record["_image_error"] = str(exc)
            record["_notes"].append(f"图片未获取：{exc}")
        record["_image_prepared"] = True
        if image_path:
            record["_local_image_path"] = str(image_path)
        else:
            record["_notes"].append("图片未获取")
            if SKIP_IMAGE_DOWNLOAD:
                record["_image_error"] = "本次跳过网络图片下载，未进行图片款式自动识别"
        logger.progress("准备候选图片", index, len(records))


def build_record(ws, row_idx, cols):
    link_cell = get_field_cell(ws, row_idx, cols, "FastMoss 商品详情页")
    image_cell = get_field_cell(ws, row_idx, cols, "商品图片")
    record = {}
    for field in FIELD_ALIASES:
        record[field] = get_field_value(ws, row_idx, cols, field)
    record["FastMoss 商品详情页"] = extract_url_from_cell(link_cell) or cell_text(
        record.get("FastMoss 商品详情页")
    )
    record["_image_url"] = extract_url_from_cell(image_cell) or (
        cell_text(record.get("商品图片")) if cell_text(record.get("商品图片")).startswith(("http://", "https://")) else ""
    )
    record["_source_row"] = row_idx
    return record


def prepare_record(record, growth_cell):
    sales = parse_number(record.get("销量"))
    record["_listing_date"] = parse_date(record.get("预估商品上架时间"))
    record["_growth"] = parse_percent(record.get("销量环比"), growth_cell.number_format if growth_cell else "")
    record["_sales_missing"] = sales is None or sales < 0
    record["_sales"] = sales if sales is not None and sales >= 0 else 0
    record["_total_sales"] = parse_number(record.get("总销量"))
    for field, target in (("同类商品数量", "_competition_count"), ("关键词竞争数量", "_keyword_competition_count")):
        number = parse_number(record.get(field))
        record[target] = number if number is not None and number >= 0 else None
    record["_notes"] = []
    return record


def evaluate_record(record, growth_cell):
    """Compatibility API; the batch pipeline supplies full-export competition context."""
    keywords, config = load_config(ROOT_DIR)
    prepare_record(record, growth_cell)
    score_record(record, TODAY, keywords, config, context_for([record], keywords))
    return record["_delete_reasons"]


def append_row(ws, values):
    ws.append(values)
    return ws.max_row


def add_image_to_cell(ws, image_path, row_idx, col_idx=1, width=82, height=82, x_offset=10, y_offset=8):
    image = XLImage(str(image_path))
    image.width = width
    image.height = height
    marker = AnchorMarker(
        col=col_idx - 1,
        colOff=pixels_to_EMU(x_offset),
        row=row_idx - 1,
        rowOff=pixels_to_EMU(y_offset),
    )
    image.anchor = OneCellAnchor(
        _from=marker,
        ext=XDRPositiveSize2D(cx=pixels_to_EMU(width), cy=pixels_to_EMU(height)),
    )
    ws.add_image(image)


def style_sheet(ws, max_row, max_col, percent_col=None, reserved_rows=0):
    if max_row < 1:
        return
    final_row = max(max_row, reserved_rows)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(max_col)}{final_row}"

    for row in ws.iter_rows(min_row=1, max_row=final_row, max_col=max_col):
        for cell in row:
            cell.alignment = CENTER_WRAP
            cell.border = BORDER
            if cell.row == 1:
                cell.fill = HEADER_FILL
                cell.font = copy.copy(WHITE_FONT)
            else:
                cell.fill = BODY_FILL

    if percent_col:
        for row_idx in range(2, max_row + 1):
            cell = ws.cell(row_idx, percent_col)
            cell.number_format = "0%"
            if isinstance(cell.value, (int, float)):
                if 0 <= cell.value <= 1:
                    cell.fill = YELLOW_FILL
                elif 1 < cell.value <= 2:
                    cell.fill = ORANGE_FILL
                elif cell.value > 2:
                    cell.fill = RED_FILL

    for row_idx in range(2, final_row + 1):
        ws.row_dimensions[row_idx].height = 78
    ws.row_dimensions[1].height = 26


def set_common_widths(ws, widths):
    for col_idx, width in widths.items():
        ws.column_dimensions[get_column_letter(col_idx)].width = width


def xlsx_date_value(value):
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    return value


def make_xlsx_formats(workbook):
    base = {
        "align": "center",
        "valign": "vcenter",
        "text_wrap": True,
        "border": 1,
        "border_color": "#7F7F7F",
        "font_name": "宋体",
        "font_size": 12,
        "bold": True,
    }
    return {
        "header": workbook.add_format(
            {
                **base,
                "font_color": "#000000",
                "bg_color": "#4BACC6",
            }
        ),
        "title": workbook.add_format(
            {
                "align": "center",
                "valign": "vcenter",
                "font_name": "黑体",
                "font_size": 18,
                "bold": True,
                "font_color": "#000000",
                "bg_color": "#C6E0B4",
                "border": 1,
                "border_color": "#7F7F7F",
            }
        ),
        "body_odd": workbook.add_format({**base, "bg_color": "#DDEBF7"}),
        "body_even": workbook.add_format({**base, "bg_color": "#D9EAD3"}),
        "date_odd": workbook.add_format({**base, "bg_color": "#DDEBF7", "num_format": "yyyy-mm-dd"}),
        "date_even": workbook.add_format({**base, "bg_color": "#D9EAD3", "num_format": "yyyy-mm-dd"}),
        "int_odd": workbook.add_format({**base, "bg_color": "#DDEBF7", "num_format": "#,##0"}),
        "int_even": workbook.add_format({**base, "bg_color": "#D9EAD3", "num_format": "#,##0"}),
        "percent_odd": workbook.add_format({**base, "bg_color": "#DDEBF7", "num_format": "0.##%"}),
        "percent_even": workbook.add_format({**base, "bg_color": "#D9EAD3", "num_format": "0.##%"}),
        "percent_yellow": workbook.add_format({**base, "bg_color": "#FFFF00", "num_format": "0%"}),
        "percent_orange": workbook.add_format({**base, "bg_color": "#FFC000", "num_format": "0%"}),
        "percent_red": workbook.add_format({**base, "bg_color": "#FF0000", "num_format": "0%"}),
        "open_text_odd": workbook.add_format({**base, "bg_color": "#DDEBF7", "font_color": "#0000FF", "underline": True}),
        "open_text_even": workbook.add_format({**base, "bg_color": "#D9EAD3", "font_color": "#0000FF", "underline": True}),
    }


def row_base_format(formats, row):
    return formats["body_odd"] if row % 2 == 0 else formats["body_even"]


def int_format(formats, row):
    return formats["int_odd"] if row % 2 == 0 else formats["int_even"]


def date_format(formats, row):
    return formats["date_odd"] if row % 2 == 0 else formats["date_even"]


def open_text_format(formats, row):
    return formats["open_text_odd"] if row % 2 == 0 else formats["open_text_even"]


def percent_format(formats, value, row):
    if not isinstance(value, (int, float)):
        return row_base_format(formats, row)
    if 0 <= value <= 1:
        return formats["percent_yellow"]
    if 1 < value <= 2:
        return formats["percent_orange"]
    if value > 2:
        return formats["percent_red"]
    return formats["percent_odd"] if row % 2 == 0 else formats["percent_even"]


def write_xlsx_cell(ws, row, col, value, formats, fmt=None):
    fmt = fmt or row_base_format(formats, row)
    if isinstance(value, (datetime, date)):
        ws.write_datetime(row, col, xlsx_date_value(value), fmt if fmt else date_format(formats, row))
    elif isinstance(value, (int, float)):
        ws.write_number(row, col, value, fmt)
    elif value is None:
        ws.write_blank(row, col, None, fmt)
    else:
        ws.write_string(row, col, str(value), fmt)


def setup_xlsx_sheet(ws, headers, widths, total_rows, formats, title_text=None, table_name=None):
    header_row = 1 if title_text else 0
    first_data_row = header_row + 1
    if title_text:
        ws.set_row(0, 34, formats["title"])
        ws.merge_range(0, 2, 0, len(headers) - 1, title_text, formats["title"])
        for col_idx in range(0, 2):
            ws.write_blank(0, col_idx, None, formats["title"])
    ws.freeze_panes(first_data_row, 0)
    ws.set_row(header_row, 34, formats["header"])
    for col_idx, header in enumerate(headers):
        ws.write(header_row, col_idx, header, formats["header"])
    for col_idx, width in widths.items():
        ws.set_column(col_idx - 1, col_idx - 1, width)
    for row_idx in range(first_data_row, first_data_row + total_rows):
        ws.set_row(row_idx, 78)
    if total_rows >= 0:
        ws.add_table(
            header_row,
            0,
            header_row + max(total_rows, 1),
            len(headers) - 1,
            {
                "name": table_name,
                "style": "Table Style Medium 3",
                "columns": [{"header": header} for header in headers],
                "banded_rows": True,
            },
        )
    return first_data_row


def standard_search_row(record, should_search, note=""):
    notes = list(record.get("_notes") or [])
    if note:
        notes.append(note)
    return [
        cell_text(record.get("商品ID")),
        cell_text(record.get("SPU")),
        cell_text(record.get("商品名称")),
        cell_text(record.get("FastMoss 商品详情页")),
        cell_text(record.get("_image_url")),
        cell_text(record.get("_local_image_path")),
        record.get("_sales") if "_sales" in record else record.get("销量"),
        record.get("_growth") if "_growth" in record else record.get("销量环比"),
        record.get("商品售价"),
        cell_text(record.get("商品分类")),
        record.get("_listing_date") or record.get("预估商品上架时间"),
        "是" if should_search else "否",
        "未搜",
        "；".join(dict.fromkeys(notes)),
        "",
    ] + [record.get(header) for header in V2_HEADERS]


def standard_row_match_key(product_id, spu, product_link):
    product_id = cell_text(product_id)
    spu = cell_text(spu)
    product_link = cell_text(product_link)
    if product_id:
        return "商品ID", product_id
    if spu:
        return "SPU", spu
    if product_link:
        return "商品链接", product_link
    return None


def load_preserved_search_states(standard_file, logger=None):
    standard_file = Path(standard_file)
    if not standard_file.is_file():
        return {}
    workbook = load_workbook(standard_file, read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        row_iterator = worksheet.iter_rows(values_only=True)
        headers = next(row_iterator, ())
        header_map = {
            normalize_header(header): index
            for index, header in enumerate(headers)
            if normalize_header(header)
        }

        def old_value(row_values, header):
            column = header_map.get(normalize_header(header))
            if column is None or column >= len(row_values):
                return ""
            return row_values[column]

        states = {}
        for row_values in row_iterator:
            key = standard_row_match_key(
                old_value(row_values, "商品ID"),
                old_value(row_values, "SPU"),
                old_value(row_values, "商品链接"),
            )
            if not key or key in states:
                continue
            states[key] = {
                header: old_value(row_values, header)
                for header in PRESERVED_SEARCH_HEADERS
            }
        if logger:
            logger.write(f"已读取旧标准表状态：{len(states)} 条可匹配记录。")
        return states
    finally:
        workbook.close()


def merge_preserved_search_state(row_values, preserved_states):
    header_index = {header: index for index, header in enumerate(STANDARD_SEARCH_HEADERS)}
    key = standard_row_match_key(
        row_values[header_index["商品ID"]],
        row_values[header_index["SPU"]],
        row_values[header_index["商品链接"]],
    )
    old_state = preserved_states.get(key, {}) if key else {}
    for header in PRESERVED_SEARCH_HEADERS:
        old_value = old_state.get(header, "")
        if cell_text(old_value):
            row_values[header_index[header]] = old_value

    if not cell_text(row_values[header_index["是否进入搜款"]]):
        row_values[header_index["是否进入搜款"]] = "否"
    if not cell_text(row_values[header_index["搜款状态"]]):
        row_values[header_index["搜款状态"]] = "未搜"
    return row_values


def backup_standard_search_file(standard_file, logger=None):
    standard_file = Path(standard_file)
    if not standard_file.is_file():
        return None
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = BACKUP_DIR / f"Fastmoss_待搜款清洗表_{timestamp}.xlsx"
    sequence = 1
    while backup_file.exists():
        backup_file = BACKUP_DIR / f"Fastmoss_待搜款清洗表_{timestamp}_{sequence}.xlsx"
        sequence += 1
    shutil.copy2(standard_file, backup_file)
    if logger:
        logger.write(f"旧标准表已备份：{backup_file}")
    return backup_file


def save_standard_search_workbook(output_file, kept_records, deleted_records, logger=None):
    output_file = Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    preserved_states = load_preserved_search_states(output_file, logger)
    backup_standard_search_file(output_file, logger)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    temp_output_file = output_file.with_name(
        f".{output_file.stem}_{timestamp}.tmp.xlsx"
    )
    workbook = xlsxwriter.Workbook(str(temp_output_file), {"strings_to_urls": False, "strings_to_formulas": False})
    header_format = workbook.add_format(
        {
            "bold": True,
            "font_name": "宋体",
            "font_size": 11,
            "align": "center",
            "valign": "vcenter",
            "text_wrap": True,
            "border": 1,
            "bg_color": "#D9EAD3",
        }
    )
    text_format = workbook.add_format(
        {
            "font_name": "宋体",
            "font_size": 11,
            "align": "center",
            "valign": "vcenter",
            "text_wrap": True,
            "border": 1,
        }
    )
    date_fmt = workbook.add_format(
        {
            "font_name": "宋体",
            "font_size": 11,
            "align": "center",
            "valign": "vcenter",
            "text_wrap": True,
            "border": 1,
            "num_format": "yyyy-mm-dd",
        }
    )
    number_fmt = workbook.add_format(
        {
            "font_name": "宋体",
            "font_size": 11,
            "align": "center",
            "valign": "vcenter",
            "text_wrap": True,
            "border": 1,
            "num_format": "#,##0",
        }
    )
    percent_fmt = workbook.add_format(
        {
            "font_name": "宋体",
            "font_size": 11,
            "align": "center",
            "valign": "vcenter",
            "text_wrap": True,
            "border": 1,
            "num_format": "0.##%",
        }
    )

    ws = workbook.add_worksheet("待搜款清洗表")
    ws.freeze_panes(1, 0)
    ws.autofilter(0, 0, 0, len(STANDARD_SEARCH_HEADERS) - 1)
    ws.set_row(0, 28)
    widths = [14, 14, 46, 52, 52, 52, 12, 12, 12, 24, 18, 14, 12, 34, 52]
    for col, width in enumerate(widths):
        ws.set_column(col, col, width)
    for col, header in enumerate(STANDARD_SEARCH_HEADERS):
        ws.write(0, col, header, header_format)

    rows = []
    for record in kept_records:
        row = standard_search_row(record, True)
        rows.append(merge_preserved_search_state(row, preserved_states))
    for item in deleted_records:
        row = standard_search_row(item["record"], False, item.get("reason", ""))
        row = merge_preserved_search_state(row, preserved_states)
        if item["record"].get("_target_enabled"):
            # Old opt-in must not reintroduce a rejected male/hoodie or unaudited item.
            row[STANDARD_SEARCH_HEADERS.index("是否进入搜款")] = "否"
        rows.append(row)

    ws.autofilter(0, 0, max(len(rows), 1), len(STANDARD_SEARCH_HEADERS) - 1)

    for row_idx, row_values in enumerate(rows, start=1):
        ws.set_row(row_idx, 42)
        for col, value in enumerate(row_values):
            if col == 6 and isinstance(value, (int, float)):
                ws.write_number(row_idx, col, value, number_fmt)
            elif col == 7 and isinstance(value, (int, float)):
                ws.write_number(row_idx, col, value, percent_fmt)
            elif col == 10 and isinstance(value, (datetime, date)):
                ws.write_datetime(row_idx, col, xlsx_date_value(value), date_fmt)
            elif value is None:
                ws.write_blank(row_idx, col, None, text_format)
            else:
                ws.write(row_idx, col, value, text_format)

    try:
        workbook.close()
        os.replace(temp_output_file, output_file)
    except Exception:
        try:
            if temp_output_file.exists():
                temp_output_file.unlink()
        except OSError:
            pass
        raise
    if logger:
        logger.write(f"标准待搜款清洗表已生成：{output_file}")


def embed_cell_image(ws, row, col, image_path, formats, fallback_text=""):
    if image_path and Path(image_path).exists():
        result = ws.embed_image(row, col, str(image_path), {"cell_format": row_base_format(formats, row)})
        if result == 0:
            return True
    ws.write(row, col, fallback_text, row_base_format(formats, row))
    return False


def title_text_from_source_file(source_file):
    name = Path(source_file).stem
    week_match = re.search(r"(20\d{2})[-_]?(\d{1,2})\s*周", name)
    if week_match:
        year = int(week_match.group(1))
        week = int(week_match.group(2))
        start = date.fromisocalendar(year, week, 1)
        end = date.fromisocalendar(year, week, 7)
        return f"{start.year}.{start.month}.{start.day}~{end.year}.{end.month}.{end.day}"
    if "TT销量榜" in name or "FastMoss" in name or "fastmoss" in name.lower():
        start = date.fromisocalendar(2026, 27, 1)
        end = date.fromisocalendar(2026, 27, 7)
        return f"{start.year}.{start.month}.{start.day}~{end.year}.{end.month}.{end.day}"
    date_match = re.search(r"(20\d{2})(\d{2})(\d{2})", name)
    if date_match:
        year = int(date_match.group(1))
        month = int(date_match.group(2))
        day = int(date_match.group(3))
        return f"{year}.{month}.{day}"
    return datetime.now().strftime("%Y.%m.%d")


def save_output_workbook_xlsxwriter(
    output_file,
    kept_records,
    deleted_records,
    source_ws,
    source_file,
    cols,
    images_by_anchor,
    logger=None,
):
    workbook = xlsxwriter.Workbook(str(output_file), {"strings_to_urls": False, "strings_to_formulas": False})
    formats = make_xlsx_formats(workbook)
    ws_filtered = workbook.add_worksheet("FastMoss筛选表")
    ws_deleted = workbook.add_worksheet("删除记录")
    ws_1688 = workbook.add_worksheet("1688同款数据")

    filtered_widths = {
        1: 15.875,
        2: 22,
        3: 13,
        4: 13,
        5: 23.125,
        6: 12,
        7: 13,
        8: 13,
        9: 25,
        10: 48,
        11: 12,
        12: 13,
        13: 48,
        14: 34,
    }
    deleted_widths = {
        1: 34,
        2: 18,
        3: 12,
        4: 12,
        5: 20,
        6: 12,
        7: 12,
        8: 12,
        9: 18,
        10: 14,
        11: 36,
        12: 42,
    }
    same_1688_widths = {
        1: 15.875,
        2: 34.875,
        3: 13,
        4: 13,
        5: 23.125,
        6: 23.125,
        7: 19.25,
        8: 17.25,
        9: 19.625,
        10: 16.25,
        11: 10.5,
        12: 11,
        13: 13,
        14: 13.75,
        15: 17.75,
    }

    kept_records.sort(key=lambda item: item.get("_sales") or 0, reverse=True)
    filtered_first_row = setup_xlsx_sheet(
        ws_filtered,
        FILTERED_HEADERS,
        filtered_widths,
        len(kept_records),
        formats,
        title_text=title_text_from_source_file(source_file),
        table_name="FastMossTable",
    )
    deleted_first_row = setup_xlsx_sheet(ws_deleted, DELETED_HEADERS, deleted_widths, len(deleted_records), formats, table_name="DeletedTable")
    same_1688_first_row = setup_xlsx_sheet(ws_1688, SAME_1688_HEADERS, same_1688_widths, 100, formats, table_name="Same1688Table")

    for sheet, headers, first_row, total in (
        (ws_filtered, FILTERED_HEADERS, filtered_first_row, len(kept_records)),
        (ws_deleted, DELETED_HEADERS, deleted_first_row, len(deleted_records)),
    ):
        for name in V2_HEADERS:
            col = headers.index(name)
            sheet.set_column(col, col, 48 if "依据" in name or "原因" in name else 22)
        for name, colors in (
            ("商品生命周期", {"新品": "#C6EFCE", "成长款": "#FFEB9C", "老款": "#D9D9D9", "待核对": "#FCE4D6"}),
            ("商品等级", {"A类": "#C6EFCE", "B类": "#DDEBF7", "C类": "#FFEB9C", "D类": "#D9D9D9"}),
        ):
            col = headers.index(name)
            for value, color in colors.items():
                sheet.conditional_format(first_row, col, first_row + max(total, 1) - 1, col,
                    {"type": "cell", "criteria": "equal to", "value": f'"{value}"', "format": workbook.add_format({"bg_color": color})})

    if logger:
        logger.progress("生成筛选表并处理单元格图片", 0, len(kept_records), "开始写入保留商品")

    fm_image_paths = {}
    for index, record in enumerate(kept_records, start=1):
        row = filtered_first_row + index - 1
        fm_code = f"FM{index:03d}"
        notes = list(record.get("_notes") or [])
        image_path = None
        try:
            image_path = record.get("_local_image_path") if record.get("_image_prepared") else get_row_image_path(
                source_ws,
                record["_source_row"],
                cols,
                images_by_anchor,
                index,
                record.get("_sales"),
                record.get("店铺名"),
            )
        except Exception as exc:
            notes.append(f"图片未获取：{exc}")
            record["_image_error"] = str(exc)
        if image_path is None:
            notes.append("图片未获取")
            if SKIP_IMAGE_DOWNLOAD:
                record["_image_error"] = "本次运行跳过了网络图片下载；可重跑默认入口获取图片"
        else:
            fm_image_paths[fm_code] = image_path
            record["_local_image_path"] = str(image_path)
        record["_notes"] = notes

        link = cell_text(record.get("FastMoss 商品详情页"))
        image_ok = embed_cell_image(ws_filtered, row, 0, image_path, formats, fm_code)
        if image_ok:
            ws_filtered.write_comment(row, 0, f"{fm_code}\n{image_path}")

        row_values = [
            cell_text(record.get("店铺名")),
            record.get("商品售价"),
            cell_text(record.get("国家/地区")),
            cell_text(record.get("商品分类")),
            record.get("_sales"),
            record.get("_growth"),
            record.get("_total_sales") if record.get("_total_sales") is not None else record.get("总销量"),
            record.get("_listing_date"),
            link,
            "打开" if link else "",
            cell_text(record.get("商品状态")),
            cell_text(record.get("商品名称")),
            "；".join(dict.fromkeys(notes)),
        ] + [record.get(header) for header in V2_HEADERS]
        for offset, value in enumerate(row_values, start=1):
            col = offset
            if col == 6:
                write_xlsx_cell(ws_filtered, row, col, value, formats, percent_format(formats, value, row))
            elif col in (5, 7):
                write_xlsx_cell(ws_filtered, row, col, value, formats, int_format(formats, row))
            elif col == 8:
                write_xlsx_cell(ws_filtered, row, col, value, formats, date_format(formats, row))
            elif col == 10:
                if link:
                    ws_filtered.write_url(row, col, link, open_text_format(formats, row), string="打开")
                else:
                    ws_filtered.write(row, col, value, open_text_format(formats, row))
            else:
                write_xlsx_cell(ws_filtered, row, col, value, formats)

        if logger:
            logger.progress("生成筛选表并处理单元格图片", index, len(kept_records), f"当前商品 {fm_code}")

    if logger:
        logger.progress("写入删除记录", 0, len(deleted_records), "开始写入删除原因")

    for index, item in enumerate(deleted_records, start=1):
        record = item["record"]
        row_values = [
            item["reason"],
            cell_text(record.get("店铺名")),
            record.get("商品售价"),
            cell_text(record.get("国家/地区")),
            cell_text(record.get("商品分类")),
            record.get("_sales") if "_sales" in record else record.get("销量"),
            record.get("_growth") if "_growth" in record else record.get("销量环比"),
            record.get("_total_sales") if record.get("_total_sales") is not None else record.get("总销量"),
            record.get("_listing_date") or record.get("预估商品上架时间"),
            cell_text(record.get("商品状态")),
            cell_text(record.get("商品名称")),
            cell_text(record.get("FastMoss 商品详情页")),
        ] + [record.get(header) for header in V2_HEADERS]
        row = deleted_first_row + index - 1
        for col, value in enumerate(row_values):
            if col in (5, 7):
                write_xlsx_cell(ws_deleted, row, col, value, formats, int_format(formats, row))
            elif col == 8:
                write_xlsx_cell(ws_deleted, row, col, value, formats, date_format(formats, row))
            else:
                write_xlsx_cell(ws_deleted, row, col, value, formats)
        if logger:
            logger.progress("写入删除记录", index, len(deleted_records))

    for index in range(1, 101):
        row = same_1688_first_row + index - 1
        if index <= len(kept_records):
            fm_code = f"FM{index:03d}"
            image_path = fm_image_paths.get(fm_code)
            image_ok = embed_cell_image(ws_1688, row, 0, image_path, formats, fm_code)
            if image_ok:
                ws_1688.write_comment(row, 0, fm_code)
        else:
            ws_1688.write_blank(row, 0, None, row_base_format(formats, row))
        for col in range(1, len(SAME_1688_HEADERS)):
            ws_1688.write_blank(row, col, None, row_base_format(formats, row))

    if logger:
        logger.write("正在保存含单元格图片的 Excel...")
    workbook.close()


def create_output_workbook(kept_records, deleted_records, source_ws, cols, images_by_anchor, logger=None):
    wb = Workbook()
    ws_filtered = wb.active
    ws_filtered.title = "FastMoss筛选表"
    ws_deleted = wb.create_sheet("删除记录")
    ws_1688 = wb.create_sheet("1688同款数据")

    ws_filtered.append(FILTERED_HEADERS)
    ws_deleted.append(DELETED_HEADERS)
    ws_1688.append(SAME_1688_HEADERS)

    kept_records.sort(key=lambda item: item.get("_sales") or 0, reverse=True)

    if logger:
        logger.progress("生成筛选表并处理图片", 0, len(kept_records), "开始写入保留商品")

    fm_image_paths = {}

    for index, record in enumerate(kept_records, start=1):
        fm_code = f"FM{index:03d}"
        notes = list(record.get("_notes") or [])
        image_path = None
        try:
            image_path = get_row_image_path(
                source_ws,
                record["_source_row"],
                cols,
                images_by_anchor,
                index,
                record.get("_sales"),
                record.get("店铺名"),
            )
        except Exception as exc:
            notes.append(f"图片未获取：{exc}")
        if image_path is None:
            notes.append("图片未获取")
        else:
            fm_image_paths[fm_code] = image_path

        link = cell_text(record.get("FastMoss 商品详情页"))
        row_values = [
            fm_code,
            cell_text(record.get("店铺名")),
            record.get("商品售价"),
            cell_text(record.get("国家/地区")),
            cell_text(record.get("商品分类")),
            record.get("_sales"),
            record.get("_growth"),
            record.get("_total_sales") if record.get("_total_sales") is not None else record.get("总销量"),
            record.get("_listing_date"),
            link,
            "打开" if link else "",
            cell_text(record.get("商品状态")),
            cell_text(record.get("商品名称")),
            "；".join(dict.fromkeys(notes)),
        ]
        row_idx = append_row(ws_filtered, row_values)
        if image_path:
            try:
                add_image_to_cell(ws_filtered, image_path, row_idx, 1)
                ws_filtered.cell(row_idx, 1).comment = Comment(str(image_path), "FastMoss清洗工具")
            except Exception as exc:
                current_note = ws_filtered.cell(row_idx, 14).value or ""
                ws_filtered.cell(row_idx, 14).value = (current_note + "；图片未插入：" + str(exc)).strip("；")
        if link:
            ws_filtered.cell(row_idx, 11).hyperlink = link
            ws_filtered.cell(row_idx, 11).style = "Hyperlink"

        if logger:
            logger.progress("生成筛选表并处理图片", index, len(kept_records), f"当前商品 {fm_code}")

    if logger:
        logger.progress("写入删除记录", 0, len(deleted_records), "开始写入删除原因")

    for index, item in enumerate(deleted_records, start=1):
        record = item["record"]
        row_values = [
            item["reason"],
            cell_text(record.get("店铺名")),
            record.get("商品售价"),
            cell_text(record.get("国家/地区")),
            cell_text(record.get("商品分类")),
            record.get("_sales") if "_sales" in record else record.get("销量"),
            record.get("_growth") if "_growth" in record else record.get("销量环比"),
            record.get("_total_sales") if record.get("_total_sales") is not None else record.get("总销量"),
            record.get("_listing_date") or record.get("预估商品上架时间"),
            cell_text(record.get("商品状态")),
            cell_text(record.get("商品名称")),
            cell_text(record.get("FastMoss 商品详情页")),
        ]
        ws_deleted.append(row_values)

        if logger:
            logger.progress("写入删除记录", index, len(deleted_records))

    for row_idx in range(2, 102):
        if row_idx - 1 <= len(kept_records):
            fm_code = f"FM{row_idx - 1:03d}"
            ws_1688.cell(row_idx, 1).value = fm_code
            image_path = fm_image_paths.get(fm_code)
            if image_path:
                try:
                    add_image_to_cell(ws_1688, image_path, row_idx, 1)
                    ws_1688.cell(row_idx, 1).comment = Comment(str(image_path), "FastMoss清洗工具")
                except Exception as exc:
                    ws_1688.cell(row_idx, 15).value = f"FastMoss商品图未插入：{exc}"
        else:
            ws_1688.cell(row_idx, 1).value = ""

    for ws in [ws_filtered, ws_deleted, ws_1688]:
        if ws.max_row > 1:
            for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
                for cell in row:
                    if isinstance(cell.value, date):
                        cell.number_format = "yyyy-mm-dd"
                    elif isinstance(cell.value, (int, float)) and ws.title != "FastMoss筛选表":
                        cell.number_format = "#,##0"

    if logger:
        logger.write("正在设置 Excel 样式、冻结首行、筛选和列宽...")

    style_sheet(ws_filtered, ws_filtered.max_row, len(FILTERED_HEADERS), percent_col=7)
    style_sheet(ws_deleted, ws_deleted.max_row, len(DELETED_HEADERS))
    style_sheet(ws_1688, 101, len(SAME_1688_HEADERS), reserved_rows=101)

    set_common_widths(
        ws_filtered,
        {
            1: 18,
            2: 18,
            3: 12,
            4: 12,
            5: 20,
            6: 12,
            7: 12,
            8: 12,
            9: 18,
            10: 42,
            11: 12,
            12: 14,
            13: 36,
            14: 34,
        },
    )
    set_common_widths(
        ws_deleted,
        {
            1: 34,
            2: 18,
            3: 12,
            4: 12,
            5: 20,
            6: 12,
            7: 12,
            8: 12,
            9: 18,
            10: 14,
            11: 36,
            12: 42,
        },
    )
    set_common_widths(
        ws_1688,
        {
            1: 20,
            2: 12,
            3: 18,
            4: 22,
            5: 12,
            6: 16,
            7: 12,
            8: 12,
            9: 14,
            10: 14,
            11: 12,
            12: 12,
            13: 12,
            14: 42,
            15: 30,
        },
    )

    return wb


def clean_fastmoss(source_file=None):
    for folder in (RAW_DIR, OUTPUT_DIR, IMAGE_DIR, CLEANED_DIR):
        folder.mkdir(parents=True, exist_ok=True)
    logger = ProgressLogger(PROGRESS_LOG)
    logger.write("FastMoss女士运动服饰选品系统 V2.1 启动。")
    logger.write(f"评估日期：{TODAY}；进度日志：{PROGRESS_LOG}")
    try:
        keywords, config = load_config(ROOT_DIR)
        global NUMERIC_GROWTH_MODE
        NUMERIC_GROWTH_MODE = config["growth_numeric_mode"]
        target = config["target_selection"]
        logger.write(f"筛选目标：{target['target_name']}；严格模式：{target['enabled']}；图片款式审核：{target['require_image_review']}")
        report_file = OUTPUT_DIR / "选品报告.xlsx"
        manual_states = load_manual_states(report_file)
        logger.write(f"已读取人工审核状态：{len(manual_states)} 条。")
        source_file = Path(source_file) if source_file else find_latest_excel()
        if source_file is None:
            raise ValueError(f"未找到原始 Excel：请把 .xlsx 或 .xlsm 文件放入：{RAW_DIR}")
        logger.write(f"正在读取原始 Excel：{source_file}")
        source_wb = load_workbook(source_file, data_only=False)
        try:
            # Ignore cover sheets when another worksheet has a recognizable product table.
            candidates = [(ws, *find_header_row(ws)) for ws in source_wb]
            candidates = [item for item in candidates if item[1] and ("商品名称" in item[2] or "商品ID" in item[2])]
            if not candidates:
                raise ValueError("未能识别商品表头：至少需要商品名称或商品ID，请检查原表字段。")
            source_ws, header_row, cols = max(candidates, key=lambda item: len(item[2]))
            logger.write(f"已识别工作表 {source_ws.title}，表头第 {header_row} 行，字段：{'、'.join(cols)}")
            missing = [field for field in REQUIRED_FIELDS if field not in cols]
            if missing:
                logger.write(f"缺失关键列 {'、'.join(missing)}：方向匹配的记录将进入人工复查，不补造数据。")
            images_by_anchor = image_map_by_anchor(source_ws)
            records = []
            total_rows = max(source_ws.max_row - header_row, 0)
            logger.progress("读取与清洗", 0, total_rows)
            for current, row_idx in enumerate(range(header_row + 1, source_ws.max_row + 1), 1):
                if any(source_ws.cell(row_idx, c).value not in (None, "") for c in range(1, source_ws.max_column + 1)):
                    record = build_record(source_ws, row_idx, cols)
                    embedded = images_by_anchor.get((row_idx, cols.get("商品图片")))
                    if embedded:
                        data = bytes_from_excel_image(embedded)
                        if data:
                            record["_image_signature"] = hashlib.sha256(data).hexdigest()
                    records.append(prepare_record(record, get_field_cell(source_ws, row_idx, cols, "销量环比")))
                logger.progress("读取与清洗", current, total_rows)
            kept, review, deleted = [], [], []
            context = context_for(records, keywords)
            logger.progress("潜力评分与分类", 0, len(records))
            for current, record in enumerate(records, 1):
                outcome = score_record(record, TODAY, keywords, config, context, manual_states.get(record_key(record)))
                record["_outcome"] = outcome
                if outcome == "删除":
                    deleted.append({"record": record, "reason": "；".join(record["_delete_reasons"])})
                elif outcome == "复查":
                    review.append(record)
                    record["_notes"].append(record["人工复查原因"])
                else:
                    kept.append(record)
                logger.progress("潜力评分与分类", current, len(records), f"推荐 {len(kept)}；复查 {len(review)}；删除 {len(deleted)}")
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            output_file = OUTPUT_DIR / f"FastMoss清洗结果_{timestamp}.xlsx"
            logger.write("生成兼容旧流程的清洗结果...")
            if target["enabled"]:
                candidates = sorted(kept, key=lambda r: r.get("_sales") or 0, reverse=True) + sorted(review, key=lambda r: r.get("_sales") or 0, reverse=True)
                prepare_candidate_images(candidates, source_ws, cols, images_by_anchor, logger)
            # In strict target mode, unconfirmed candidates live only in the review report.
            filtered_records = kept if target["enabled"] else kept + review
            save_output_workbook_xlsxwriter(output_file, filtered_records, deleted, source_ws, source_file, cols, images_by_anchor, logger)
            # Missing-data rows do not automatically enter the sourcing queue.
            review_items = [{"record": r, "reason": "人工复查：" + r["人工复查原因"]} for r in review]
            save_standard_search_workbook(STANDARD_SEARCH_FILE, kept, review_items + deleted, logger)
            save_report(report_file, kept, review, deleted, source_file, source_wb, source_ws, TODAY, keywords, config, BACKUP_DIR, logger)
            light_file = save_light_report(report_file)
            logger.write(f"轻量报告：{light_file}（{light_file.stat().st_size:,} 字节，不含图片，用于反馈误筛）")
            logger.write(f"清洗完成：推荐 {len(kept)}；待人工复查 {len(review)}；删除 {len(deleted)}；总计 {len(records)}。")
            logger.write(f"清洗结果：{output_file}")
            logger.write(f"标准搜款表：{STANDARD_SEARCH_FILE}")
            return 0
        finally:
            source_wb.close()
    except Exception as exc:
        logger.write(f"运行失败：{exc}")
        logger.write("请检查输入与配置；若Excel打开导致文件被占用，请关闭后重试。")
        with PROGRESS_LOG.open("a", encoding="utf-8") as handle:
            handle.write(traceback.format_exc())
        return 1


def main(argv=None):
    global ROOT_DIR, RAW_DIR, OUTPUT_DIR, IMAGE_DIR, CLEANED_DIR, STANDARD_SEARCH_FILE, BACKUP_DIR, PROGRESS_LOG, TODAY, SKIP_IMAGE_DOWNLOAD
    parser = argparse.ArgumentParser(description="FastMoss女士运动服饰选品系统 V2.1：女士运动外套")
    parser.add_argument("--input", type=Path, help="指定原始xlsx/xlsm；默认读取原始目录最新文件")
    parser.add_argument("--root", type=Path, default=ROOT_DIR, help="项目根目录（包含配置及数据目录）")
    parser.add_argument("--as-of", type=date.fromisoformat, help="历史回测日期 YYYY-MM-DD；默认北京时间当天")
    parser.add_argument("--no-download-images", action="store_true", help="跳过网络图片下载，仍复制原表嵌入图片")
    args = parser.parse_args(argv)
    ROOT_DIR = args.root.resolve()
    RAW_DIR = ROOT_DIR / "01_FastMoss原始表"
    OUTPUT_DIR = ROOT_DIR / "02_筛选后表格"
    IMAGE_DIR = ROOT_DIR / "03_商品图片"
    CLEANED_DIR = ROOT_DIR / "cleaned"
    STANDARD_SEARCH_FILE = CLEANED_DIR / "Fastmoss_待搜款清洗表.xlsx"
    BACKUP_DIR = ROOT_DIR / "backup"
    PROGRESS_LOG = ROOT_DIR / "清洗进度.log"
    TODAY = args.as_of or datetime.now(timezone(timedelta(hours=8))).date()
    SKIP_IMAGE_DOWNLOAD = args.no_download_images
    return clean_fastmoss(args.input)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("用户已取消运行。")
        sys.exit(130)
    except Exception as exc:
        print("运行失败，未预期错误如下：")
        print(exc)
        sys.exit(1)
