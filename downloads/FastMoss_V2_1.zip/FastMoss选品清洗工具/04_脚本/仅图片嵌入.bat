@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PY_CMD=python"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 set "PY_CMD=py -3"

%PY_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo Python 3 was not found. Please install Python 3 and add it to PATH.
    pause
    exit /b 1
)

echo Installing/checking dependencies...
%PY_CMD% -m pip install -r requirements.txt
if errorlevel 1 (
    echo Dependency install failed. Please check Python, pip, or network access.
    pause
    exit /b 1
)

echo.
echo Running image embedder only. No filtering, no deleting, no sorting.
%PY_CMD% image_embedder.py
set "EXIT_CODE=%ERRORLEVEL%"

echo.
echo Done. Exit code: %EXIT_CODE%
pause
exit /b %EXIT_CODE%
