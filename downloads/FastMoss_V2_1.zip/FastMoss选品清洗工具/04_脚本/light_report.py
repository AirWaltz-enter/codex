"""Create a small, image-free report for feedback without loading large media."""
import argparse
import os
from datetime import date, datetime
from pathlib import Path

import xlsxwriter
from openpyxl import load_workbook


def save_light_report(source, output=None):
    source = Path(source)
    output = Path(output) if output else source.with_name(source.stem + "_轻量.xlsx")
    if source.resolve() == output.resolve():
        raise ValueError("轻量输出不能覆盖原报告")
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_name(f".{output.stem}_{datetime.now():%Y%m%d_%H%M%S_%f}.tmp.xlsx")
    raw = load_workbook(source, read_only=True, data_only=True)
    try:
        with xlsxwriter.Workbook(str(temp), {"strings_to_urls": False, "strings_to_formulas": False}) as target:
            header = target.add_format({"bold": True, "bg_color": "#D9EAD3"})
            date_format = target.add_format({"num_format": "yyyy-mm-dd"})
            percentage = target.add_format({"num_format": "0.##%"})
            link = target.add_format({"font_color": "blue", "underline": 1})
            intro = target.add_worksheet("轻量表说明")
            intro.write(0, 0, "仅用于误筛反馈和数据诊断，不含图片，不是人工审核状态来源；请在原选品报告.xlsx填写审核。")
            intro.set_column(0, 0, 100)
            intro.write(1, 0, "源文件：" + source.name)
            for sheet in raw:
                ws = target.add_worksheet(sheet.title)
                ws.freeze_panes(1, 0)
                ws.set_column(0, sheet.max_column - 1, 20)
                headers = [cell.value for cell in next(sheet.iter_rows(min_row=1, max_row=1))]
                for row_idx, row in enumerate(sheet.values):
                    for col_idx, value in enumerate(row):
                        if value is None:
                            continue
                        field = headers[col_idx] if col_idx < len(headers) else None
                        if isinstance(value, (date, datetime)):
                            dt = value if isinstance(value, datetime) else datetime.combine(value, datetime.min.time())
                            ws.write_datetime(row_idx, col_idx, dt, date_format)
                        elif isinstance(value, (int, float)):
                            ws.write_number(row_idx, col_idx, value, percentage if field in ("销量增长", "销量环比") else None)
                        elif row_idx and field in ("商品链接", "商品图片链接") and str(value).startswith(("http://", "https://")):
                            ws.write_url(row_idx, col_idx, str(value), link, string=str(value))
                        else:
                            ws.write_string(row_idx, col_idx, str(value), header if row_idx == 0 else None)
                if sheet.max_row > 1:
                    ws.autofilter(0, 0, sheet.max_row - 1, sheet.max_column - 1)
        os.replace(temp, output)
    except Exception:
        if temp.exists():
            temp.unlink()
        raise
    finally:
        raw.close()
    return output


def main():
    parser = argparse.ArgumentParser(description="生成不含图片的轻量报告，用于上传误筛反馈")
    parser.add_argument("input", nargs="?", type=Path, default=Path(__file__).resolve().parent.parent / "02_筛选后表格/选品报告.xlsx")
    args = parser.parse_args()
    try:
        output = save_light_report(args.input)
        print(f"轻量报告已生成：{output}（{output.stat().st_size:,} 字节）")
        return 0
    except Exception as exc:
        print(f"轻量报告生成失败：{exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
