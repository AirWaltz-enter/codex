"""Deterministic V2 selection rules; scores are decision aids, not sales forecasts."""
import hashlib
import math
import re
from collections import Counter
from target_selection import TARGET_HEADERS, evaluate_target


V2_HEADERS = [
    "商品潜力评分", "商品等级", "推荐动作", "图片吸引力评分", "图片得分",
    "商品年龄(天)", "商品生命周期", "关键词匹配", "排除词命中", "人工复查原因",
    "1688搜索关键词", "老板审核", "供应链状态", "销量得分", "增长得分", "年龄得分",
    "类目得分", "价格得分", "竞争得分", "自动评分", "竞争判断依据", "价格判断依据",
] + TARGET_HEADERS
MANUAL_FIELDS = ["图片吸引力评分", "老板审核", "供应链状态", "备注", "图片款式审核"]
MANUAL_STATE_FIELDS = MANUAL_FIELDS + ["图片审核指纹"]


def text(value):
    return "" if value is None else str(value).strip()


def hit(content, keyword):
    # Normalize separators so quarter-zip and quarter zip share a match.
    content = re.sub(r"[-_\s]+", " ", text(content).lower().replace("’", "'").replace("‘", "'"))
    keyword = re.sub(r"[-_\s]+", " ", keyword.lower())
    if re.fullmatch(r"[a-z0-9 ']+", keyword):
        return re.search(r"(?<![a-z0-9])" + re.escape(keyword) + r"(?![a-z0-9])", content) is not None
    return keyword in content


def keyword_result(record, config):
    # Shop names do not make an unrelated product an activewear match.
    content = " ".join(text(record.get(k)) for k in ("商品名称", "商品分类"))
    keep = [k for k in config["keep_keywords"] if hit(content, k)]
    exclude = [k for k in config["exclude_keywords"] if hit(content, k)]
    strong = [k for k in config["strong_keywords"] if hit(content, k)]
    return keep, exclude, strong


def record_key(record):
    for field in ("商品ID", "SPU", "FastMoss 商品详情页"):
        if text(record.get(field)):
            return field + ":" + text(record[field])
    # Fallback is independent of source row order, but not a claimed product ID.
    identity = "\x1f".join(text(record.get(k)) for k in ("商品名称", "店铺名", "商品分类"))
    return "内容:" + hashlib.sha256(identity.encode()).hexdigest()


def image_points(value):
    if value in (None, ""):
        return 0
    if isinstance(value, bool):
        raise ValueError("图片吸引力评分必须为空或 1-5 的整数")
    try:
        rating = float(value)
    except (TypeError, ValueError):
        raise ValueError("图片吸引力评分必须为空或 1-5 的整数") from None
    if not math.isfinite(rating) or not rating.is_integer() or not 1 <= rating <= 5:
        raise ValueError("图片吸引力评分必须为空或 1-5 的整数")
    return int(rating) * 3


def grade(score):
    if score >= 80:
        return "A类", "优先开发"
    if score >= 65:
        return "B类", "小批量测试"
    if score >= 50:
        return "C类", "观察"
    return "D类", "暂不上架"


def growth_points(growth):
    if growth is None or growth < 0:
        return 0
    if growth > 3:
        return 20
    if growth >= 1:
        return 15
    if growth >= .3:
        return 10
    return 5


def search_terms(record, config):
    content = " ".join(text(record.get(k)) for k in ("商品名称", "商品分类"))
    terms = []
    for rule in config.get("search_rules", []):
        if all(hit(content, k) for k in rule["all"]):
            terms.extend(rule["terms"])
    if not terms:
        if "套装" in content:
            terms = ["女士运动套装", "瑜伽健身两件套"]
        elif any(k in content for k in ("裤", "紧身")):
            terms = ["女士瑜伽裤", "高腰运动裤"]
        else:
            terms = ["女士运动服饰", "瑜伽健身服"]
    return "；".join(dict.fromkeys(terms))


def price_points(record, config):
    content = " ".join(text(record.get(k)) for k in ("商品名称", "商品分类"))
    kind = "运动外套" if record.get("_target_enabled") and record.get("_target_has_outerwear") else next((k for k, words in config["product_type_keywords"].items() if any(hit(content, word) for word in words)), None)
    if kind not in config["price_ranges"]:
        return 0, "品类暂无美元价格区间", True
    raw = text(record.get("商品售价"))
    if not raw or re.search(r"[€£¥￥]|EUR|GBP|CNY|RMB|CAD|AUD|元", raw, re.I):
        return 0, "价格缺失或币种非美元/无法确认", True
    if isinstance(record.get("商品售价"), (int, float)) and record["商品售价"] < 0:
        return 0, "价格无效", True
    if raw.startswith("-"):
        return 0, "价格无效", True
    amount = r"\d+(?:,\d{3})*(?:\.\d+)?"
    currency = r"(?:US\$|\$|USD\s*)?"
    if not re.fullmatch(rf"{currency}\s*{amount}(?:\s*[-–—~至]\s*{currency}\s*{amount})?\s*(?:USD)?", raw, re.I):
        return 0, "价格缺失或无法识别", True
    values = [float(v.replace(",", "")) for v in re.findall(r"\d+(?:,\d{3})*(?:\.\d+)?", raw)]
    if not values or len(values) > 2 or not all(math.isfinite(v) and v > 0 for v in values):
        return 0, "价格缺失或无法识别", True
    low, high = min(values), max(values)
    target_low, target_high = config["price_ranges"][kind]
    valid = target_low <= low <= high <= target_high
    return (10 if valid else 0), f"{kind} ${low:g}-{high:g}；参考 ${target_low:g}-{target_high:g}；{'符合' if valid else '不符合'}", False


def context_for(records, keyword_config):
    # Count distinct products, not repeated rows in an export.
    unique = {record_key(r): r for r in records}.values()
    categories = Counter()
    keywords = Counter()
    for record in unique:
        category = text(record.get("商品分类"))
        if category:
            categories[category] += 1
        keywords.update(set(keyword_result(record, keyword_config)[0]))
    return categories, keywords


def score_record(record, today, keywords, config, context, manual=None):
    manual = manual or {}
    hard, review = [], []
    target_data, target_hard, target_review = evaluate_target(record, config["target_selection"], manual, hit)
    record.update(target_data)
    hard.extend(target_hard)
    review.extend(target_review)
    keep, exclude, strong = keyword_result(record, keywords)
    age = (today - record["_listing_date"]).days if record.get("_listing_date") else None
    status = text(record.get("商品状态"))
    if any(k in status.lower() for k in ("下架", "停售", "off sale", "inactive", "discontinued")):
        hard.append("商品状态包含下架/停售")
    if age is None:
        review.append("上架时间为空或无法识别")
    elif age < 0:
        review.append("上架时间晚于评估日期，需核对")
    elif config["max_age_days"] is not None and age > config["max_age_days"]:
        hard.append(f"上架时间不在最近{config['max_age_days']}天内")
    growth = record.get("_growth")
    if growth is None:
        review.append("销量环比为空或无法识别")
    elif growth <= 0:
        hard.append("销量环比小于等于0%")
    if not keep and record.get("_target_enabled") and record.get("_target_has_outerwear"):
        keep = ["运动外套目标匹配"]
    if not keep:
        hard.append("命中排除关键词且未命中女士运动服饰保留关键词" if exclude else "未命中女士运动服饰保留关键词")
    elif exclude:
        review.append("人工复查：同时命中保留词和排除词")
    if record.get("_sales_missing"):
        review.append("近7天销量缺失或无效")
    for field in config["review_missing_fields"]:
        if not text(record.get(field)):
            review.append(f"{field}缺失")
    region = text(record.get("国家/地区"))
    if region and region.casefold() not in {r.casefold() for r in config["us_regions"]}:
        hard.append("国家/地区不是美国站")
    link = text(record.get("FastMoss 商品详情页"))
    if link and not re.match(r"^https?://", link, re.I):
        review.append("商品链接无效")
    sales = record.get("_sales") or 0
    sales_score = 0 if record.get("_sales_missing") else next(t["points"] for t in config["sales_tiers"] if sales >= t["minimum"])
    age_score = 0 if age is None or age < 0 else 10 if age <= 30 else 8 if age <= 90 else 3
    lifecycle = "待核对" if age is None or age < 0 else "新品" if age <= 30 else "成长款" if age <= 90 else "老款"
    category_score = 15 if (strong or (record.get("_target_enabled") and record.get("_target_has_outerwear"))) else 5 if keep else 0
    price_score, price_basis, price_unknown = price_points(record, config)
    if price_unknown:
        review.append(price_basis)
    categories, frequencies = context
    count = record.get("_competition_count")
    category = text(record.get("商品分类"))
    basis = "原表同类商品数量"
    if count is None:
        count = categories.get(category) if category else None
        basis = "本次导出同类去重商品数量（非全市场）"
    keyword_count = record.get("_keyword_competition_count")
    keyword_basis = "原表关键词竞争数量"
    if keyword_count is None:
        keyword_count = max((frequencies.get(k, 0) for k in keep), default=0)
        keyword_basis = "本次导出关键词最高命中数量（非全市场）"
    brand_text = " ".join(text(record.get(k)) for k in ("商品名称", "店铺名", "品牌"))
    brands = [k for k in keywords["brand_risk_keywords"] if hit(brand_text, k)]
    limits = config["competition"]
    if brands:
        competition_score = 3
        review.append("品牌风险待核实：" + "、".join(brands))
    elif count is None:
        competition_score = 0
        review.append("竞争数据不足：缺少商品分类及同类数量")
    elif count >= limits["high_count_min"] or keyword_count >= limits["high_keyword_count_min"]:
        competition_score = 3
    elif count <= limits["low_count_max"]:
        competition_score = 10
    else:
        competition_score = 5
    competition_basis = f"{basis}={count if count is not None else '未知'}；{keyword_basis}={keyword_count}；品牌词={'、'.join(brands) or '未命中配置词（非授权证明）'}"
    parts = {"销量得分": sales_score, "增长得分": growth_points(growth), "年龄得分": age_score,
             "类目得分": category_score, "价格得分": price_score, "竞争得分": competition_score}
    automatic = sum(parts.values())
    rating = manual.get("图片吸引力评分")
    try:
        picture = image_points(rating)
        rating = picture // 3 if picture else None
    except ValueError as exc:
        rating, picture = None, 0
        review.append(str(exc))
    total = automatic + picture
    level, action = grade(total)
    boss = manual.get("老板审核") or "待审核"
    supply = manual.get("供应链状态") or "未找货"
    if boss not in ("待审核", "推荐", "放弃"):
        review.append("老板审核值无效，已重置待审核")
        boss = "待审核"
    if supply not in ("未找货", "已找到1688", "已询价", "待测试"):
        review.append("供应链状态值无效，已重置未找货")
        supply = "未找货"
    notes = list(record.get("_notes") or [])
    if manual.get("备注"):
        notes.append(text(manual["备注"]))
    record.update(parts)
    record.update({"商品潜力评分": total, "商品等级": level, "推荐动作": action,
                   "图片吸引力评分": rating, "图片得分": picture, "自动评分": automatic,
                   "商品年龄(天)": age, "商品生命周期": lifecycle, "关键词匹配": "、".join(keep),
                   "排除词命中": "、".join(exclude), "人工复查原因": "；".join(dict.fromkeys(review)),
                   "1688搜索关键词": "女士运动外套；瑜伽拉链夹克女；女士防晒运动外套" if record.get("_target_enabled") and record.get("_target_has_outerwear") else search_terms(record, keywords), "老板审核": boss,
                   "供应链状态": supply, "备注": manual.get("备注", ""),
                   "竞争判断依据": competition_basis, "价格判断依据": price_basis,
                   "_notes": notes, "_record_key": record_key(record), "_delete_reasons": hard})
    if not config["missing_to_review"]:
        for reason in review:
            if reason.startswith(("上架时间", "销量环比", "近7天销量")):
                hard.append(reason)
    return "删除" if hard else "复查" if review else "推荐"
