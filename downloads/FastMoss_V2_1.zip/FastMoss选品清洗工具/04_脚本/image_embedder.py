import io
import re
import sys
from datetime import date, datetime
from pathlib import Path
from urllib.parse import urlparse

import requests
import xlsxwriter
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, range_boundaries
from PIL import Image as PILImage


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
RAW_DIR = ROOT_DIR / "01_FastMoss原始表"
OUTPUT_DIR = ROOT_DIR / "02_筛选后表格"
IMAGE_DIR = ROOT_DIR / "03_商品图片"
LOG_FILE = ROOT_DIR / "图片嵌入进度.log"

IMAGE_HEADER_ALIASES = {"商品图片", "商品图", "图片", "主图"}
IMAGE_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp")


def log(message):
    line = f"[{datetime.now().strftime('%H:%M:%S')}] {message}"
    print(line, flush=True)
    with LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(line + "\n")


def init_dirs():
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_FILE.write_text(
        "FastMoss 图片嵌入进度日志\n"
        f"开始时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n",
        encoding="utf-8-sig",
    )


def latest_excel():
    files = []
    for pattern in ("*.xlsx", "*.xlsm"):
        files.extend(RAW_DIR.glob(pattern))
    files = [p for p in files if p.is_file() and not p.name.startswith("~$")]
    if not files:
        return None
    return max(files, key=lambda p: p.stat().st_mtime)


def used_bounds(ws):
    cells = [cell for cell in ws._cells.values() if cell.value not in (None, "")]
    if not cells:
        return 1, 1
    return max(cell.row for cell in cells), max(cell.column for cell in cells)


def normalized_text(value):
    if value is None:
        return ""
    return re.sub(r"\s+", "", str(value).strip())


def find_image_column(ws, max_row, max_col):
    scan_rows = min(max_row, 30)
    for row in range(1, scan_rows + 1):
        for col in range(1, max_col + 1):
            if normalized_text(ws.cell(row, col).value) in IMAGE_HEADER_ALIASES:
                return row, col
    return None, None


def extract_url(cell):
    if cell.hyperlink and cell.hyperlink.target:
        return str(cell.hyperlink.target).strip()
    value = cell.value
    if not value:
        return ""
    text = str(value).strip()
    formula_match = re.search(r'HYPERLINK\(\s*"([^"]+)"', text, flags=re.I)
    if formula_match:
        return formula_match.group(1)
    match = re.search(r"https?://[^\s\"<>）)]+", text)
    if match:
        return match.group(0)
    return text if text.lower().startswith(("http://", "https://")) else ""


def looks_like_image_url(url):
    if not url or not re.match(r"^https?://", url, flags=re.I):
        return False
    path = urlparse(url).path.lower()
    return path.endswith(IMAGE_EXTENSIONS) or "image" in path or "s.500fd.com" in url.lower()


def safe_name(value, default="image", max_len=40):
    text = str(value or default)
    text = re.sub(r'[\\/:*?"<>|]+', "_", text)
    text = re.sub(r"\s+", "_", text).strip("._ ")
    return (text or default)[:max_len]


def download_as_png(url):
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36"
        )
    }
    response = requests.get(url, headers=headers, timeout=(5, 10))
    response.raise_for_status()
    raw = response.content
    with PILImage.open(io.BytesIO(raw)) as image:
        image.thumbnail((500, 500))
        out = io.BytesIO()
        image.convert("RGBA").save(out, format="PNG")
        return out.getvalue()


def save_png(bytes_data, image_dir, row_index, url):
    filename = f"IMG{row_index:04d}_{safe_name(Path(urlparse(url).path).stem)}.png"
    target = image_dir / filename
    suffix = 1
    while target.exists():
        target = image_dir / f"IMG{row_index:04d}_{safe_name(Path(urlparse(url).path).stem)}_{suffix}.png"
        suffix += 1
    target.write_bytes(bytes_data)
    return target


def color_to_hex(color):
    if not color:
        return None
    if color.type == "rgb" and color.rgb and isinstance(color.rgb, str):
        rgb = color.rgb[-6:]
        if rgb != "000000":
            return f"#{rgb}"
    return None


def border_weight(style):
    if not style:
        return None
    return {
        "hair": 1,
        "thin": 1,
        "medium": 2,
        "thick": 5,
        "double": 6,
        "dashed": 3,
        "dotted": 4,
    }.get(style, 1)


def make_format(workbook, cell, cache):
    key = cell.style_id
    if key in cache:
        return cache[key]

    props = {
        "font_name": cell.font.name or "宋体",
        "font_size": cell.font.sz or 11,
        "bold": bool(cell.font.bold),
        "italic": bool(cell.font.italic),
        "text_wrap": bool(cell.alignment.wrap_text),
        "align": cell.alignment.horizontal or "center",
        "valign": cell.alignment.vertical or "vcenter",
    }
    if cell.font.underline:
        props["underline"] = True
    font_color = color_to_hex(cell.font.color)
    if font_color:
        props["font_color"] = font_color
    fill_color = color_to_hex(cell.fill.fgColor)
    if cell.fill.fill_type == "solid" and fill_color:
        props["bg_color"] = fill_color
    if cell.number_format and cell.number_format != "General":
        props["num_format"] = cell.number_format

    sides = {
        "left": cell.border.left,
        "right": cell.border.right,
        "top": cell.border.top,
        "bottom": cell.border.bottom,
    }
    for name, side in sides.items():
        weight = border_weight(side.style)
        if weight:
            props[name] = weight
            side_color = color_to_hex(side.color)
            if side_color:
                props[f"{name}_color"] = side_color

    fmt = workbook.add_format(props)
    cache[key] = fmt
    return fmt


def write_cell(out_ws, row0, col0, cell, fmt):
    value = cell.value
    if value is None:
        out_ws.write_blank(row0, col0, None, fmt)
    elif isinstance(value, datetime):
        out_ws.write_datetime(row0, col0, value, fmt)
    elif isinstance(value, date):
        out_ws.write_datetime(row0, col0, datetime(value.year, value.month, value.day), fmt)
    elif isinstance(value, (int, float)):
        out_ws.write_number(row0, col0, value, fmt)
    elif isinstance(value, str) and value.startswith("="):
        out_ws.write_formula(row0, col0, value, fmt)
    elif cell.hyperlink and cell.hyperlink.target:
        out_ws.write_url(row0, col0, cell.hyperlink.target, fmt, string=str(value))
    else:
        out_ws.write(row0, col0, value, fmt)


def copy_sheet(workbook, source_ws, image_output_dir):
    max_row, max_col = used_bounds(source_ws)
    out_ws = workbook.add_worksheet(source_ws.title[:31])
    format_cache = {}
    image_header_row, image_col = find_image_column(source_ws, max_row, max_col)
    converted = 0
    failed = 0

    log(f"处理工作表：{source_ws.title}，范围：{max_row} 行 x {max_col} 列")
    if image_col:
        log(f"识别到商品图片列：{get_column_letter(image_col)}，表头行：{image_header_row}")
    else:
        log("未识别到商品图片列，本工作表只复制内容。")

    for col in range(1, max_col + 1):
        letter = get_column_letter(col)
        width = source_ws.column_dimensions[letter].width
        if width:
            out_ws.set_column(col - 1, col - 1, width)

    for row in range(1, max_row + 1):
        height = source_ws.row_dimensions[row].height
        if height:
            out_ws.set_row(row - 1, height)

    for merged in source_ws.merged_cells.ranges:
        min_col, min_row, max_col_m, max_row_m = range_boundaries(str(merged))
        if min_row <= max_row and min_col <= max_col:
            fmt = make_format(workbook, source_ws.cell(min_row, min_col), format_cache)
            out_ws.merge_range(min_row - 1, min_col - 1, max_row_m - 1, max_col_m - 1, source_ws.cell(min_row, min_col).value, fmt)

    for row in range(1, max_row + 1):
        if row % 20 == 0:
            log(f"{source_ws.title}：已处理 {row}/{max_row} 行")
        for col in range(1, max_col + 1):
            cell = source_ws.cell(row, col)
            if any(row >= r.min_row and row <= r.max_row and col >= r.min_col and col <= r.max_col and (row, col) != (r.min_row, r.min_col) for r in source_ws.merged_cells.ranges):
                continue
            fmt = make_format(workbook, cell, format_cache)
            if image_col and col == image_col and row > image_header_row:
                url = extract_url(cell)
                if looks_like_image_url(url):
                    try:
                        png = download_as_png(url)
                        image_path = save_png(png, image_output_dir, row, url)
                        result = out_ws.embed_image(row - 1, col - 1, str(image_path), {"cell_format": fmt})
                        if result == 0:
                            converted += 1
                            continue
                    except Exception as exc:
                        failed += 1
                        out_ws.write_comment(row - 1, col - 1, f"图片嵌入失败：{exc}")
                write_cell(out_ws, row - 1, col - 1, cell, fmt)
            else:
                write_cell(out_ws, row - 1, col - 1, cell, fmt)

    if source_ws.freeze_panes:
        try:
            pane_cell = source_ws.freeze_panes
            out_ws.freeze_panes(source_ws[pane_cell].row - 1, source_ws[pane_cell].column - 1)
        except Exception:
            pass

    if source_ws.auto_filter and source_ws.auto_filter.ref:
        try:
            min_col, min_row, max_col_f, max_row_f = range_boundaries(source_ws.auto_filter.ref)
            out_ws.autofilter(min_row - 1, min_col - 1, min(max_row_f, max_row) - 1, min(max_col_f, max_col) - 1)
        except Exception:
            pass

    for table_name in source_ws.tables.keys():
        try:
            table = source_ws.tables[table_name]
            min_col, min_row, max_col_t, max_row_t = range_boundaries(table.ref)
            max_row_t = min(max_row_t, max_row)
            max_col_t = min(max_col_t, max_col)
            headers = [source_ws.cell(min_row, col).value or f"Column{col}" for col in range(min_col, max_col_t + 1)]
            out_ws.add_table(
                min_row - 1,
                min_col - 1,
                max_row_t - 1,
                max_col_t - 1,
                {
                    "name": re.sub(r"[^A-Za-z0-9_]", "_", table_name)[:30] or "Table1",
                    "style": "Table Style Medium 3",
                    "columns": [{"header": str(header)} for header in headers],
                    "banded_rows": True,
                },
            )
        except Exception as exc:
            log(f"表格样式复制失败：{table_name}，原因：{exc}")

    log(f"{source_ws.title} 完成：嵌入图片 {converted} 张，失败 {failed} 张")
    return converted, failed


def embed_images_only():
    init_dirs()
    source_file = latest_excel()
    if not source_file:
        log(f"未找到 Excel，请把文件放入：{RAW_DIR}")
        return 1

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    image_output_dir = IMAGE_DIR / f"图片嵌入_{timestamp}"
    image_output_dir.mkdir(parents=True, exist_ok=True)
    output_file = OUTPUT_DIR / f"图片嵌入结果_{timestamp}.xlsx"

    log(f"读取文件：{source_file}")
    wb = load_workbook(source_file, data_only=False)
    workbook = xlsxwriter.Workbook(str(output_file), {"strings_to_urls": False})

    total_converted = 0
    total_failed = 0
    for ws in wb.worksheets:
        converted, failed = copy_sheet(workbook, ws, image_output_dir)
        total_converted += converted
        total_failed += failed

    workbook.close()
    wb.close()
    log("图片嵌入完成！")
    log(f"嵌入图片数量：{total_converted}")
    log(f"失败图片数量：{total_failed}")
    log(f"输出文件路径：{output_file}")
    log(f"图片保存目录：{image_output_dir}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(embed_images_only())
    except KeyboardInterrupt:
        log("用户取消运行。")
        sys.exit(130)
    except Exception as exc:
        log(f"运行失败：{exc}")
        sys.exit(1)
