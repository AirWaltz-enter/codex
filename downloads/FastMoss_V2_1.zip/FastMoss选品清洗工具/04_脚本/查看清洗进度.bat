@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo Watching FastMoss progress log.
echo This window waits until the log file appears.
echo Press Ctrl+C to stop watching.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "$root = Resolve-Path -LiteralPath '%~dp0..'; $name = ([string][char]0x6E05) + ([string][char]0x6D17) + ([string][char]0x8FDB) + ([string][char]0x5EA6) + '.log'; $log = Join-Path $root $name; while (-not (Test-Path -LiteralPath $log)) { Write-Host ('Waiting for progress log... ' + (Get-Date -Format 'HH:mm:ss')); Start-Sleep -Seconds 1 }; Get-Content -LiteralPath $log -Wait -Encoding UTF8"
