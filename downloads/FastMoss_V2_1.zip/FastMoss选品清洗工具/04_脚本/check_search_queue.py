import sys
from pathlib import Path

from openpyxl import load_workbook


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
STANDARD_FILE = ROOT_DIR / "cleaned" / "Fastmoss_待搜款清洗表.xlsx"
TASK_QUEUE_FILE = ROOT_DIR / "output" / "1688_待搜款任务队列.xlsx"

REQUIRED_HEADERS = [
    "商品ID",
    "SPU",
    "商品标题",
    "商品链接",
    "本地图片路径",
    "主体裁剪图路径",
    "是否进入搜款",
    "搜款状态",
    "备注",
]


def text_value(value):
    return "" if value is None else str(value).strip()


def normalize_header(value):
    return text_value(value).replace("\n", "").replace("\r", "")


def get_header_map(worksheet):
    header_map = {}
    for column in range(1, worksheet.max_column + 1):
        header = normalize_header(worksheet.cell(1, column).value)
        if header and header not in header_map:
            header_map[header] = column
    return header_map


def resolve_existing_file(raw_path):
    raw_text = text_value(raw_path)
    if not raw_text:
        return None
    path = Path(raw_text)
    candidates = [path]
    if not path.is_absolute():
        candidates.extend(
            [
                ROOT_DIR / path,
                STANDARD_FILE.parent / path,
                SCRIPT_DIR / path,
            ]
        )
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    return None


def row_has_data(worksheet, row_number):
    return any(
        text_value(worksheet.cell(row_number, column).value)
        for column in range(1, worksheet.max_column + 1)
    )


def inspect_standard_table(path=STANDARD_FILE):
    if not path.is_file():
        raise FileNotFoundError(f"找不到标准表：{path}")

    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        header_map = get_header_map(worksheet)
        missing_headers = [header for header in REQUIRED_HEADERS if header not in header_map]
        if missing_headers:
            raise ValueError(f"标准表缺少必要列：{', '.join(missing_headers)}")

        counts = {
            "total_rows": 0,
            "local_path_present": 0,
            "local_file_exists": 0,
            "should_search_yes": 0,
            "cropped_status": 0,
            "crop_path_present": 0,
            "crop_file_exists": 0,
            "export_ready": 0,
        }

        for row_number in range(2, worksheet.max_row + 1):
            if not row_has_data(worksheet, row_number):
                continue
            counts["total_rows"] += 1

            local_path = worksheet.cell(
                row_number, header_map["本地图片路径"]
            ).value
            crop_path = worksheet.cell(
                row_number, header_map["主体裁剪图路径"]
            ).value
            should_search = text_value(
                worksheet.cell(row_number, header_map["是否进入搜款"]).value
            )
            search_status = text_value(
                worksheet.cell(row_number, header_map["搜款状态"]).value
            )

            local_path_present = bool(text_value(local_path))
            local_file_exists = resolve_existing_file(local_path) is not None
            crop_path_present = bool(text_value(crop_path))
            crop_file_exists = resolve_existing_file(crop_path) is not None

            counts["local_path_present"] += int(local_path_present)
            counts["local_file_exists"] += int(local_file_exists)
            counts["should_search_yes"] += int(should_search == "是")
            counts["cropped_status"] += int(search_status == "已裁剪")
            counts["crop_path_present"] += int(crop_path_present)
            counts["crop_file_exists"] += int(crop_file_exists)
            counts["export_ready"] += int(
                should_search == "是"
                and search_status in {"已裁剪", "未搜"}
                and crop_path_present
                and crop_file_exists
            )
        return counts
    finally:
        workbook.close()


def count_queue_tasks(path=TASK_QUEUE_FILE):
    if not path.is_file():
        return None
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        return sum(
            1
            for row_number in range(2, worksheet.max_row + 1)
            if row_has_data(worksheet, row_number)
        )
    finally:
        workbook.close()


def print_report(counts, queue_count):
    print("=" * 62)
    print("Fastmoss 1688 搜款任务队列验收报告")
    print("=" * 62)
    print(f"标准表：{STANDARD_FILE}")
    print(f"标准表总商品行数：{counts['total_rows']}")
    print(f"本地图片路径不为空：{counts['local_path_present']}")
    print(f"本地图片文件真实存在：{counts['local_file_exists']}")
    print(f"是否进入搜款 = 是：{counts['should_search_yes']}")
    print(f"搜款状态 = 已裁剪：{counts['cropped_status']}")
    print(f"主体裁剪图路径不为空：{counts['crop_path_present']}")
    print(f"主体裁剪图文件真实存在：{counts['crop_file_exists']}")
    print(f"最终满足导出条件：{counts['export_ready']}")
    if queue_count is None:
        print(f"当前任务队列表：不存在（{TASK_QUEUE_FILE}）")
    else:
        print(f"当前任务队列表里的任务数量：{queue_count}")
    print("-" * 62)
    if counts["export_ready"] == 0:
        print(
            "当前没有可导出的搜款任务。请先打开 04_脚本/搜款前准备.bat，"
            "下载商品图，框选主体，保存裁剪图，再导出任务队列。"
        )
    else:
        print(
            "已有可导出的搜款任务，可以点击搜款前准备工具里的"
            "‘导出搜款任务队列’按钮。"
        )
    print("=" * 62)


def main():
    try:
        counts = inspect_standard_table()
        queue_count = count_queue_tasks()
        print_report(counts, queue_count)
        return 0
    except Exception as exc:
        print(f"检查失败：{exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
