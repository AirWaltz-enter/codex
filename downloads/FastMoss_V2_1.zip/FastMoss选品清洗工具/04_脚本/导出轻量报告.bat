@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY_CMD=python"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 set "PY_CMD=py -3"
%PY_CMD% -m pip install -r requirements.txt
if errorlevel 1 (
    pause
    exit /b 1
)
%PY_CMD% light_report.py %*
set "EXIT_CODE=%ERRORLEVEL%"
pause
exit /b %EXIT_CODE%
