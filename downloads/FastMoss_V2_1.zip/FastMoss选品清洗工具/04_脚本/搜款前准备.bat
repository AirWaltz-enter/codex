﻿@echo off
chcp 65001 >nul
cd /d "%~dp0.."

set "PY_CMD=python"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 set "PY_CMD=py -3"

%PY_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo Python 3 was not found. Please install Python 3 and add it to PATH.
    pause
    exit /b 1
)

echo Python detected:
%PY_CMD% --version

echo.
echo Installing/checking dependencies...
%PY_CMD% -m pip install -r "04_脚本\requirements.txt"
if errorlevel 1 (
    echo Dependency install failed. Please check Python, pip, or network access.
    pause
    exit /b 1
)

echo.
echo Starting Fastmoss search preparation tool...
%PY_CMD% "04_脚本\search_prep_tool.py"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
echo Done. Exit code: %EXIT_CODE%
pause
exit /b %EXIT_CODE%
