@echo off
chcp 65001 >nul
setlocal

cd /d "%~dp0\.."

echo ========================================
echo FastMoss 图片嵌入进度监视
echo ========================================
echo.
echo 日志文件：%cd%\图片嵌入进度.log
echo.

if not exist "图片嵌入进度.log" (
    echo 还没有找到图片嵌入进度.log
    echo 请先运行：04_脚本\仅图片嵌入.bat
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Content -LiteralPath '图片嵌入进度.log' -Encoding UTF8 -Wait -Tail 50"

pause
