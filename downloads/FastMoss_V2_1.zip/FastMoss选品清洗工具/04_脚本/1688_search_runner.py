import argparse
import subprocess
import sys
import tempfile
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import messagebox, ttk

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from PIL import Image, ImageTk


SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent
TASK_QUEUE_FILE = ROOT_DIR / "output" / "1688_待搜款任务队列.xlsx"
SEARCH_RESULTS_FILE = ROOT_DIR / "output" / "1688_搜款结果表.xlsx"
MANUAL_SUMMARY_FILE = ROOT_DIR / "output" / "1688_人工搜款汇总表.xlsx"
IMAGE_SEARCH_URL = "https://www.1688.com/"

TASK_HEADERS = [
    "任务ID",
    "源表行号",
    "商品ID",
    "SPU",
    "商品标题",
    "主体裁剪图路径",
    "商品链接",
    "近7天销量",
    "商品价格",
    "搜款状态",
    "任务状态",
    "备注",
]

RESULT_HEADERS = [
    "任务ID",
    "源表行号",
    "商品ID",
    "SPU",
    "Fastmoss商品标题",
    "Fastmoss商品链接",
    "主体裁剪图路径",
    "1688搜索状态",
    "1688结果排名",
    "1688商品标题",
    "1688商品链接",
    "1688主图路径",
    "1688主图链接",
    "1688价格",
    "起批量",
    "供应商名称",
    "相似度",
    "人工判断",
    "采集状态",
    "备注",
]

MANUAL_FIELDS = [
    "1688结果排名",
    "1688商品标题",
    "1688商品链接",
    "1688价格",
    "起批量",
    "供应商名称",
    "人工判断",
    "备注",
]

TASK_STATUSES = {"搜索中", "已搜索", "无结果", "失败"}

SUMMARY_HEADERS = [
    "任务ID",
    "源表行号",
    "商品ID",
    "SPU",
    "商品标题",
    "Fastmoss商品链接",
    "主体裁剪图路径",
    "任务状态",
    "1688结果排名",
    "1688商品标题",
    "1688商品链接",
    "1688价格",
    "起批量",
    "供应商名称",
    "人工判断",
    "采集状态",
    "备注",
]

SAVED_RESULT_FIELDS = [
    "1688结果排名",
    "1688商品标题",
    "1688商品链接",
    "1688价格",
    "起批量",
    "供应商名称",
    "人工判断",
    "备注",
]


def text_value(value):
    return "" if value is None else str(value).strip()


def normalize_header(value):
    return text_value(value).replace("\n", "").replace("\r", "")


def get_header_map(worksheet):
    header_map = {}
    for column in range(1, worksheet.max_column + 1):
        header = normalize_header(worksheet.cell(1, column).value)
        if header and header not in header_map:
            header_map[header] = column
    return header_map


def validate_headers(header_map, required_headers, file_label):
    missing = [header for header in required_headers if header not in header_map]
    if missing:
        raise ValueError(f"{file_label}缺少必要列：{', '.join(missing)}")


def row_has_data(worksheet, row_number):
    return any(
        text_value(worksheet.cell(row_number, column).value)
        for column in range(1, worksheet.max_column + 1)
    )


def load_tasks(path=TASK_QUEUE_FILE):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"找不到待搜款任务队列：{path}")
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        header_map = get_header_map(worksheet)
        validate_headers(header_map, TASK_HEADERS, "待搜款任务队列")
        tasks = []
        for row_number in range(2, worksheet.max_row + 1):
            if not row_has_data(worksheet, row_number):
                continue
            task = {
                header: worksheet.cell(row_number, header_map[header]).value
                for header in TASK_HEADERS
            }
            task["_excel_row"] = row_number
            tasks.append(task)
        return tasks
    finally:
        workbook.close()


def validate_result_file(path=SEARCH_RESULTS_FILE):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"找不到1688搜款结果表：{path}")
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        header_map = get_header_map(worksheet)
        validate_headers(header_map, RESULT_HEADERS, "1688搜款结果表")
    finally:
        workbook.close()


def load_saved_results(task_id=None, path=SEARCH_RESULTS_FILE):
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"找不到1688搜款结果表：{path}")
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        header_map = get_header_map(worksheet)
        validate_headers(header_map, RESULT_HEADERS, "1688搜款结果表")
        results = []
        for row_number in range(2, worksheet.max_row + 1):
            if not row_has_data(worksheet, row_number):
                continue
            row_task_id = text_value(
                worksheet.cell(row_number, header_map["任务ID"]).value
            )
            if task_id is not None and row_task_id != text_value(task_id):
                continue
            result = {
                header: worksheet.cell(row_number, header_map[header]).value
                for header in RESULT_HEADERS
            }
            result["_excel_row"] = row_number
            results.append(result)
        return results
    finally:
        workbook.close()


def has_duplicate_result_link(task_id, result_link, path=SEARCH_RESULTS_FILE):
    link = text_value(result_link)
    if not link:
        return False
    return any(
        text_value(result.get("1688商品链接")) == link
        for result in load_saved_results(task_id, path)
    )


def open_saved_result_link(result_link, opener=None):
    link = text_value(result_link)
    if not link:
        raise ValueError("选中的结果没有1688商品链接。")
    if not link.lower().startswith(("http://", "https://")):
        raise ValueError("1688商品链接格式无效。")
    open_function = opener or webbrowser.open
    return open_function(link, new=2)


def save_summary_workbook(rows, path=MANUAL_SUMMARY_FILE):
    path = Path(path)
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "人工搜款汇总"
    worksheet.append(SUMMARY_HEADERS)
    for row in rows:
        worksheet.append(row)

    header_fill = PatternFill("solid", fgColor="D9EAF7")
    for cell in worksheet[1]:
        cell.font = Font(bold=True)
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center")
    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = (
        f"A1:{get_column_letter(len(SUMMARY_HEADERS))}{max(worksheet.max_row, 1)}"
    )
    for column, header in enumerate(SUMMARY_HEADERS, 1):
        width = max(12, min(42, len(header) * 2 + 4))
        worksheet.column_dimensions[get_column_letter(column)].width = width

    path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(path)
    workbook.close()
    return path


def export_manual_summary_workbook(
    queue_path=TASK_QUEUE_FILE,
    result_path=SEARCH_RESULTS_FILE,
    output_path=MANUAL_SUMMARY_FILE,
):
    tasks = load_tasks(queue_path)
    results = load_saved_results(None, result_path)
    results_by_task = {}
    for result in results:
        results_by_task.setdefault(text_value(result.get("任务ID")), []).append(result)

    rows = []
    for task in tasks:
        task_results = results_by_task.get(text_value(task.get("任务ID"))) or [None]
        for result in task_results:
            rows.append(
                [
                    task.get("任务ID", ""),
                    task.get("源表行号", ""),
                    task.get("商品ID", ""),
                    task.get("SPU", ""),
                    task.get("商品标题", ""),
                    task.get("商品链接", ""),
                    task.get("主体裁剪图路径", ""),
                    task.get("任务状态", ""),
                    "" if result is None else result.get("1688结果排名", ""),
                    "" if result is None else result.get("1688商品标题", ""),
                    "" if result is None else result.get("1688商品链接", ""),
                    "" if result is None else result.get("1688价格", ""),
                    "" if result is None else result.get("起批量", ""),
                    "" if result is None else result.get("供应商名称", ""),
                    "" if result is None else result.get("人工判断", ""),
                    "" if result is None else result.get("采集状态", ""),
                    task.get("备注", "") if result is None else result.get("备注", ""),
                ]
            )
    save_summary_workbook(rows, output_path)
    return len(rows), Path(output_path)


def resolve_image_path(raw_path, root_dir=ROOT_DIR, queue_file=TASK_QUEUE_FILE):
    raw_text = text_value(raw_path)
    if not raw_text:
        return None
    path = Path(raw_text)
    candidates = [path]
    if not path.is_absolute():
        candidates.extend(
            [
                Path(root_dir) / path,
                Path(queue_file).parent / path,
                SCRIPT_DIR / path,
            ]
        )
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    return None


def find_task_row(worksheet, header_map, task_id):
    task_id_column = header_map["任务ID"]
    for row_number in range(2, worksheet.max_row + 1):
        if text_value(worksheet.cell(row_number, task_id_column).value) == text_value(task_id):
            return row_number
    raise ValueError(f"任务队列中找不到任务ID：{task_id}")


def update_task_status(task_id, status, path=TASK_QUEUE_FILE):
    if status not in TASK_STATUSES:
        raise ValueError(f"不支持的任务状态：{status}")
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"找不到待搜款任务队列：{path}")
    workbook = load_workbook(path)
    try:
        worksheet = workbook.active
        header_map = get_header_map(worksheet)
        validate_headers(header_map, TASK_HEADERS, "待搜款任务队列")
        row_number = find_task_row(worksheet, header_map, task_id)
        worksheet.cell(row_number, header_map["任务状态"]).value = status
        workbook.save(path)
        return row_number
    finally:
        workbook.close()


def append_manual_result(task, manual_values, search_status, path=SEARCH_RESULTS_FILE):
    if search_status not in TASK_STATUSES:
        raise ValueError(f"不支持的1688搜索状态：{search_status}")
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"找不到1688搜款结果表：{path}")
    workbook = load_workbook(path)
    try:
        worksheet = workbook.active
        header_map = get_header_map(worksheet)
        validate_headers(header_map, RESULT_HEADERS, "1688搜款结果表")
        result = {
            "任务ID": task.get("任务ID", ""),
            "源表行号": task.get("源表行号", ""),
            "商品ID": task.get("商品ID", ""),
            "SPU": task.get("SPU", ""),
            "Fastmoss商品标题": task.get("商品标题", ""),
            "Fastmoss商品链接": task.get("商品链接", ""),
            "主体裁剪图路径": task.get("主体裁剪图路径", ""),
            "1688搜索状态": search_status,
            "1688结果排名": manual_values.get("1688结果排名", ""),
            "1688商品标题": manual_values.get("1688商品标题", ""),
            "1688商品链接": manual_values.get("1688商品链接", ""),
            "1688主图路径": "",
            "1688主图链接": "",
            "1688价格": manual_values.get("1688价格", ""),
            "起批量": manual_values.get("起批量", ""),
            "供应商名称": manual_values.get("供应商名称", ""),
            "相似度": "",
            "人工判断": manual_values.get("人工判断", ""),
            "采集状态": "人工填写",
            "备注": manual_values.get("备注", ""),
        }
        row_number = worksheet.max_row + 1
        for header in RESULT_HEADERS:
            worksheet.cell(row_number, header_map[header]).value = result[header]
        workbook.save(path)
        return row_number
    finally:
        workbook.close()


def open_1688_search_page(opener=None):
    open_function = opener or webbrowser.open
    return open_function(IMAGE_SEARCH_URL, new=2)


def open_image_folder(image_path, popen=None):
    path = Path(image_path)
    if not path.is_file():
        raise FileNotFoundError("主体裁剪图不存在。")
    launch = popen or subprocess.Popen
    return launch(["explorer.exe", "/select,", str(path.resolve())])


class SearchRunnerApp:
    def __init__(
        self,
        root,
        queue_file=TASK_QUEUE_FILE,
        result_file=SEARCH_RESULTS_FILE,
        project_root=ROOT_DIR,
    ):
        self.root = root
        self.queue_file = Path(queue_file)
        self.result_file = Path(result_file)
        self.project_root = Path(project_root)
        self.tasks = []
        self.saved_results = []
        self.current_task = None
        self.current_image_path = None
        self.original_image = None
        self.tk_image = None
        self.info_vars = {
            header: tk.StringVar(value="")
            for header in [
                "商品标题",
                "商品ID",
                "SPU",
                "主体裁剪图路径",
                "商品链接",
                "近7天销量",
                "商品价格",
            ]
        }
        self.manual_vars = {field: tk.StringVar(value="") for field in MANUAL_FIELDS}
        self.status_var = tk.StringVar(value="")

        self.root.title("1688 搜款执行台")
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        window_width = min(1360, max(1200, screen_width - 80))
        window_height = min(900, max(760, screen_height - 100))
        self.root.geometry(f"{window_width}x{window_height}")
        self.root.minsize(980, 640)
        self.build_ui()
        self.load_queue(show_empty_dialog=True)

    def build_ui(self):
        main = ttk.PanedWindow(self.root, orient=tk.HORIZONTAL)
        main.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        left_frame = ttk.Frame(main, width=420)
        right_frame = ttk.Frame(main)
        main.add(left_frame, weight=1)
        main.add(right_frame, weight=3)

        self.tree = ttk.Treeview(
            left_frame,
            columns=("task_id", "title", "status"),
            show="headings",
            height=20,
        )
        self.tree.heading("task_id", text="任务ID")
        self.tree.heading("title", text="商品标题")
        self.tree.heading("status", text="任务状态")
        self.tree.column("task_id", width=120, anchor=tk.CENTER)
        self.tree.column("title", width=220, anchor=tk.W)
        self.tree.column("status", width=80, anchor=tk.CENTER)
        self.tree.pack(fill=tk.BOTH, expand=True)
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)

        refresh_bar = ttk.Frame(left_frame)
        refresh_bar.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(
            refresh_bar,
            text="刷新任务队列",
            command=self.refresh_queue,
        ).pack(fill=tk.X)

        summary_bar = ttk.Frame(left_frame)
        summary_bar.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(
            summary_bar,
            text="导出人工搜款汇总表",
            command=self.export_manual_summary,
        ).pack(fill=tk.X)

        browser_bar = ttk.Frame(left_frame)
        browser_bar.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(
            browser_bar,
            text="打开 1688 以图搜款页面",
            command=self.open_1688_page,
        ).pack(fill=tk.X)

        file_bar = ttk.Frame(left_frame)
        file_bar.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(
            file_bar,
            text="打开主体裁剪图所在文件夹",
            command=self.open_crop_folder,
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
        ttk.Button(
            file_bar,
            text="复制主体裁剪图路径",
            command=self.copy_crop_path,
        ).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(4, 0))

        status_bar = ttk.Frame(left_frame)
        status_bar.pack(fill=tk.X, pady=(8, 0))
        for index, status in enumerate(["搜索中", "已搜索", "无结果", "失败"]):
            ttk.Button(
                status_bar,
                text=f"标记为{status}",
                command=lambda value=status: self.mark_status(value),
            ).grid(row=index // 2, column=index % 2, sticky="ew", padx=3, pady=3)
        status_bar.columnconfigure(0, weight=1)
        status_bar.columnconfigure(1, weight=1)

        steps_frame = ttk.LabelFrame(right_frame, text="当前操作步骤")
        steps_frame.pack(fill=tk.X)
        steps_text = (
            "1. 确认左侧任务和裁剪图。  2. 点击“打开1688”，在浏览器中手动登录并上传裁剪图。\n"
            "3. 在1688中找到疑似同款。  4. 回到执行台，填写标题、链接、价格、起批量和供应商。\n"
            "5. 点击下方固定的“保存手动结果”。  6. 需要时导出人工搜款汇总表。"
        )
        ttk.Label(
            steps_frame,
            text=steps_text,
            justify=tk.LEFT,
            wraplength=820,
        ).pack(fill=tk.X, padx=8, pady=6)

        info_frame = ttk.LabelFrame(right_frame, text="当前任务")
        info_frame.pack(fill=tk.X, pady=(8, 0))
        info_layout = [
            ("商品标题", 0, 0, 1, 3, 780),
            ("商品ID", 1, 0, 1, 1, 300),
            ("SPU", 1, 2, 3, 1, 300),
            ("主体裁剪图路径", 2, 0, 1, 3, 780),
            ("商品链接", 3, 0, 1, 3, 780),
            ("近7天销量", 4, 0, 1, 1, 300),
            ("商品价格", 4, 2, 3, 1, 300),
        ]
        for header, row_index, label_column, value_column, columnspan, wraplength in info_layout:
            ttk.Label(info_frame, text=f"{header}：", width=15).grid(
                row=row_index,
                column=label_column,
                sticky=tk.NW,
                padx=(8, 4),
                pady=3,
            )
            ttk.Label(
                info_frame,
                textvariable=self.info_vars[header],
                wraplength=wraplength,
            ).grid(
                row=row_index,
                column=value_column,
                columnspan=columnspan,
                sticky=tk.W,
                padx=(0, 8),
                pady=3,
            )
        info_frame.columnconfigure(1, weight=1)
        info_frame.columnconfigure(3, weight=1)

        self.canvas = tk.Canvas(
            right_frame,
            height=220,
            bg="#f5f5f5",
            highlightthickness=1,
            highlightbackground="#cccccc",
        )
        self.canvas.pack(fill=tk.X, pady=(8, 0))
        self.canvas.bind("<Configure>", self.redraw_image)

        ttk.Label(right_frame, textvariable=self.status_var).pack(
            side=tk.BOTTOM,
            fill=tk.X,
            pady=(6, 0),
        )
        save_bar = ttk.Frame(right_frame)
        save_bar.pack(side=tk.BOTTOM, fill=tk.X, pady=(8, 0))
        ttk.Button(
            save_bar,
            text="保存手动结果",
            command=self.save_manual_result,
        ).pack(fill=tk.X)

        scroll_frame = ttk.LabelFrame(right_frame, text="已保存结果与人工填写（可滚动）")
        scroll_frame.pack(fill=tk.BOTH, expand=True, pady=(8, 0))
        self.results_scroll_canvas = tk.Canvas(scroll_frame, highlightthickness=0)
        results_scrollbar = ttk.Scrollbar(
            scroll_frame,
            orient=tk.VERTICAL,
            command=self.results_scroll_canvas.yview,
        )
        self.results_scroll_canvas.configure(yscrollcommand=results_scrollbar.set)
        results_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.results_scroll_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.results_scroll_content = ttk.Frame(self.results_scroll_canvas)
        self.results_scroll_window = self.results_scroll_canvas.create_window(
            (0, 0),
            window=self.results_scroll_content,
            anchor=tk.NW,
        )
        self.results_scroll_content.bind(
            "<Configure>",
            self._update_results_scroll_region,
        )
        self.results_scroll_canvas.bind(
            "<Configure>",
            self._resize_results_scroll_content,
        )

        saved_frame = ttk.LabelFrame(self.results_scroll_content, text="当前任务已保存结果")
        saved_frame.pack(fill=tk.X, padx=6, pady=(6, 0))
        self.saved_results_var = tk.StringVar(value="当前任务暂无已保存结果。")
        ttk.Label(saved_frame, textvariable=self.saved_results_var).pack(
            fill=tk.X,
            padx=8,
            pady=(5, 2),
        )
        saved_tree_frame = ttk.Frame(saved_frame)
        saved_tree_frame.pack(fill=tk.X, padx=8)
        saved_columns = (
            "rank",
            "title",
            "link",
            "price",
            "min_qty",
            "supplier",
            "judgment",
            "note",
        )
        self.saved_tree = ttk.Treeview(
            saved_tree_frame,
            columns=saved_columns,
            show="headings",
            height=3,
        )
        saved_headings = {
            "rank": "排名",
            "title": "1688商品标题",
            "link": "1688商品链接",
            "price": "价格",
            "min_qty": "起批量",
            "supplier": "供应商",
            "judgment": "人工判断",
            "note": "备注",
        }
        saved_widths = {
            "rank": 55,
            "title": 180,
            "link": 220,
            "price": 70,
            "min_qty": 70,
            "supplier": 120,
            "judgment": 100,
            "note": 140,
        }
        for column in saved_columns:
            self.saved_tree.heading(column, text=saved_headings[column])
            self.saved_tree.column(column, width=saved_widths[column], anchor=tk.W)
        saved_x_scroll = ttk.Scrollbar(
            saved_tree_frame,
            orient=tk.HORIZONTAL,
            command=self.saved_tree.xview,
        )
        self.saved_tree.configure(xscrollcommand=saved_x_scroll.set)
        self.saved_tree.pack(fill=tk.X)
        saved_x_scroll.pack(fill=tk.X)
        ttk.Button(
            saved_frame,
            text="打开选中1688链接",
            command=self.open_selected_result_link,
        ).pack(fill=tk.X, padx=8, pady=(5, 8))

        result_frame = ttk.LabelFrame(self.results_scroll_content, text="手动填写 1688 结果")
        result_frame.pack(fill=tk.X, padx=6, pady=(8, 6))
        for index, field in enumerate(MANUAL_FIELDS):
            row_index = index // 2
            column_index = (index % 2) * 2
            ttk.Label(result_frame, text=f"{field}：").grid(
                row=row_index,
                column=column_index,
                sticky=tk.W,
                padx=(8, 4),
                pady=4,
            )
            ttk.Entry(result_frame, textvariable=self.manual_vars[field]).grid(
                row=row_index,
                column=column_index + 1,
                sticky="ew",
                padx=(0, 8),
                pady=4,
            )
        result_frame.columnconfigure(1, weight=1)
        result_frame.columnconfigure(3, weight=1)

        ttk.Label(
            result_frame,
            text="填写完成后，请点击窗口底部固定显示的“保存手动结果”。",
        ).grid(row=4, column=0, columnspan=4, sticky=tk.W, padx=8, pady=(4, 8))
        self._bind_results_mousewheel(self.results_scroll_content)

    def _update_results_scroll_region(self, _event=None):
        self.results_scroll_canvas.configure(
            scrollregion=self.results_scroll_canvas.bbox("all")
        )

    def _resize_results_scroll_content(self, event):
        self.results_scroll_canvas.itemconfigure(
            self.results_scroll_window,
            width=event.width,
        )

    def _bind_results_mousewheel(self, widget):
        widget.bind("<MouseWheel>", self._scroll_results)
        for child in widget.winfo_children():
            self._bind_results_mousewheel(child)

    def _scroll_results(self, event):
        if event.delta:
            self.results_scroll_canvas.yview_scroll(int(-event.delta / 120), "units")
        return "break"

    def load_queue(self, show_empty_dialog=False):
        try:
            validate_result_file(self.result_file)
            tasks = load_tasks(self.queue_file)
        except Exception as exc:
            messagebox.showerror("打开失败", str(exc))
            self.status_var.set(str(exc))
            return
        self.tasks = tasks
        self.refresh_tree()
        if self.tasks:
            first_item = str(self.tasks[0]["_excel_row"])
            self.tree.selection_set(first_item)
            self.tree.focus(first_item)
            self.on_tree_select()
            self.status_var.set(f"已读取 {len(self.tasks)} 条待搜款任务。")
        else:
            self.clear_current_display()
            empty_message = (
                "当前任务队列为空。请先打开 04_脚本/搜款前准备.bat，下载商品图，"
                "框选主体，保存裁剪图，并导出搜款任务队列。"
            )
            self.status_var.set(empty_message)
            if show_empty_dialog:
                messagebox.showwarning("当前任务队列为空", empty_message)

    def refresh_queue(self):
        self.load_queue(show_empty_dialog=True)

    def clear_current_display(self):
        self.current_task = None
        self.current_image_path = None
        self.original_image = None
        self.tk_image = None
        for variable in self.info_vars.values():
            variable.set("")
        for variable in self.manual_vars.values():
            variable.set("")
        self.saved_results = []
        for item in self.saved_tree.get_children():
            self.saved_tree.delete(item)
        self.saved_results_var.set("当前任务暂无已保存结果。")
        self.show_image_message("当前任务队列为空")

    def refresh_tree(self):
        for item in self.tree.get_children():
            self.tree.delete(item)
        for task in self.tasks:
            row_number = str(task["_excel_row"])
            self.tree.insert(
                "",
                tk.END,
                iid=row_number,
                values=(
                    text_value(task.get("任务ID")),
                    text_value(task.get("商品标题")),
                    text_value(task.get("任务状态")),
                ),
            )

    def on_tree_select(self, _event=None):
        selection = self.tree.selection()
        if not selection:
            return
        row_number = int(selection[0])
        self.current_task = next(
            (task for task in self.tasks if task["_excel_row"] == row_number),
            None,
        )
        if self.current_task is None:
            return
        for header, variable in self.info_vars.items():
            variable.set(text_value(self.current_task.get(header)))
        self.load_task_image()
        self.refresh_saved_results()

    def refresh_saved_results(self):
        for item in self.saved_tree.get_children():
            self.saved_tree.delete(item)
        self.saved_results = []
        if self.current_task is None:
            self.saved_results_var.set("当前任务暂无已保存结果。")
            return
        try:
            self.saved_results = load_saved_results(
                self.current_task.get("任务ID"),
                self.result_file,
            )
        except Exception as exc:
            self.saved_results_var.set("已保存结果读取失败。")
            messagebox.showerror("读取失败", str(exc))
            return
        if not self.saved_results:
            self.saved_results_var.set("当前任务暂无已保存结果。")
            return
        self.saved_results_var.set(f"当前任务已保存 {len(self.saved_results)} 条结果。")
        for result in self.saved_results:
            self.saved_tree.insert(
                "",
                tk.END,
                iid=str(result["_excel_row"]),
                values=tuple(text_value(result.get(field)) for field in SAVED_RESULT_FIELDS),
            )

    def open_selected_result_link(self):
        selection = self.saved_tree.selection()
        if not selection:
            messagebox.showwarning("未选择结果", "请先选择一条已保存结果。")
            return
        excel_row = int(selection[0])
        result = next(
            (item for item in self.saved_results if item["_excel_row"] == excel_row),
            None,
        )
        if result is None:
            messagebox.showwarning("结果不存在", "选中的结果已经不存在，请重新选择任务。")
            return
        try:
            opened = open_saved_result_link(result.get("1688商品链接"))
            if not opened:
                raise RuntimeError("系统默认浏览器未能打开链接。")
            self.status_var.set("已打开选中的1688商品链接。")
        except Exception as exc:
            messagebox.showerror("打开失败", str(exc))

    def export_manual_summary(self):
        try:
            row_count, output_path = export_manual_summary_workbook(
                self.queue_file,
                self.result_file,
                MANUAL_SUMMARY_FILE,
            )
            message = f"人工搜款汇总表已导出：\n{output_path}\n\n导出行数：{row_count}"
            self.status_var.set(f"人工搜款汇总表已导出，共 {row_count} 行。")
            messagebox.showinfo("导出完成", message)
        except Exception as exc:
            messagebox.showerror("导出失败", str(exc))

    def load_task_image(self):
        self.current_image_path = resolve_image_path(
            self.current_task.get("主体裁剪图路径"),
            self.project_root,
            self.queue_file,
        )
        self.original_image = None
        self.tk_image = None
        if self.current_image_path is None:
            self.show_image_message("主体裁剪图不存在")
            self.status_var.set("主体裁剪图不存在。")
            return
        try:
            self.original_image = Image.open(self.current_image_path).convert("RGB")
        except Exception as exc:
            self.show_image_message(f"主体裁剪图打开失败：{exc}")
            self.status_var.set("主体裁剪图打开失败。")
            return
        self.redraw_image()
        self.status_var.set(f"已显示主体裁剪图：{self.current_image_path}")

    def show_image_message(self, message):
        self.canvas.delete("all")
        self.canvas.create_text(
            30,
            30,
            anchor=tk.NW,
            text=message,
            fill="#444444",
            font=("Microsoft YaHei UI", 15),
        )

    def redraw_image(self, _event=None):
        if self.original_image is None:
            return
        self.canvas.delete("all")
        canvas_width = max(self.canvas.winfo_width(), 1)
        canvas_height = max(self.canvas.winfo_height(), 1)
        scale = min(
            canvas_width / self.original_image.width,
            canvas_height / self.original_image.height,
            1,
        )
        display_size = (
            max(1, int(self.original_image.width * scale)),
            max(1, int(self.original_image.height * scale)),
        )
        display_image = self.original_image.resize(display_size, Image.LANCZOS)
        self.tk_image = ImageTk.PhotoImage(display_image)
        self.canvas.create_image(
            canvas_width // 2,
            canvas_height // 2,
            anchor=tk.CENTER,
            image=self.tk_image,
        )

    def require_task(self):
        if self.current_task is None:
            messagebox.showwarning("未选择任务", "请先选择一个搜款任务。")
            return False
        return True

    def open_1688_page(self):
        try:
            opened = open_1688_search_page()
            if not opened:
                raise RuntimeError("系统默认浏览器未能打开页面。")
            self.status_var.set("已打开 1688 页面，请手动登录、上传图片和查看结果。")
        except Exception as exc:
            messagebox.showerror("打开失败", str(exc))

    def open_crop_folder(self):
        if not self.require_task():
            return
        if self.current_image_path is None:
            messagebox.showwarning("主体裁剪图不存在", "主体裁剪图不存在。")
            return
        try:
            open_image_folder(self.current_image_path)
        except Exception as exc:
            messagebox.showerror("打开失败", str(exc))

    def copy_crop_path(self):
        if not self.require_task():
            return
        if self.current_image_path is None:
            messagebox.showwarning("主体裁剪图不存在", "主体裁剪图不存在。")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(str(self.current_image_path))
        self.root.update()
        self.status_var.set("主体裁剪图路径已复制。")

    def mark_status(self, status):
        if not self.require_task():
            return
        try:
            update_task_status(
                self.current_task.get("任务ID"),
                status,
                self.queue_file,
            )
            self.current_task["任务状态"] = status
            self.tree.set(str(self.current_task["_excel_row"]), "status", status)
            self.status_var.set(f"任务状态已更新为：{status}")
        except Exception as exc:
            messagebox.showerror("状态更新失败", str(exc))

    def save_manual_result(self):
        if not self.require_task():
            return
        manual_values = {
            field: text_value(variable.get())
            for field, variable in self.manual_vars.items()
        }
        current_status = text_value(self.current_task.get("任务状态"))
        search_status = current_status if current_status in {"无结果", "失败"} else "已搜索"
        try:
            result_link = manual_values.get("1688商品链接", "")
            if result_link and has_duplicate_result_link(
                self.current_task.get("任务ID"),
                result_link,
                self.result_file,
            ):
                continue_save = messagebox.askyesno(
                    "发现重复链接",
                    "该任务下已保存过这个1688链接，是否仍然继续保存？",
                    default=messagebox.NO,
                )
                if not continue_save:
                    self.status_var.set("已取消保存重复的1688链接。")
                    return
            append_manual_result(
                self.current_task,
                manual_values,
                search_status,
                self.result_file,
            )
            update_task_status(
                self.current_task.get("任务ID"),
                search_status,
                self.queue_file,
            )
            self.current_task["任务状态"] = search_status
            self.tree.set(
                str(self.current_task["_excel_row"]),
                "status",
                search_status,
            )
            for variable in self.manual_vars.values():
                variable.set("")
            self.refresh_saved_results()
            success_message = (
                "手动结果已保存，任务状态已更新为已搜索。"
                "可以继续处理下一条任务，或导出人工搜款汇总表。"
            )
            self.status_var.set(success_message)
            messagebox.showinfo("保存成功", success_message)
        except Exception as exc:
            messagebox.showerror("保存失败", str(exc))


def create_test_workbooks(base_dir):
    output_dir = base_dir / "output"
    image_dir = base_dir / "images" / "crop_subject"
    output_dir.mkdir(parents=True)
    image_dir.mkdir(parents=True)
    image_path = image_dir / "TEST001_crop.jpg"
    Image.new("RGB", (240, 320), "#4f7cac").save(image_path, "JPEG")

    queue_path = output_dir / "1688_queue_test.xlsx"
    queue_workbook = Workbook()
    queue_sheet = queue_workbook.active
    queue_sheet.append(TASK_HEADERS)
    queue_sheet.append(
        [
            "SEARCH_000001",
            2,
            "TEST001",
            "SPU001",
            "测试商品",
            "images/crop_subject/TEST001_crop.jpg",
            "https://example.com/product",
            100,
            19.9,
            "已裁剪",
            "待搜款",
            "测试任务",
        ]
    )
    queue_workbook.save(queue_path)
    queue_workbook.close()

    result_path = output_dir / "1688_results_test.xlsx"
    result_workbook = Workbook()
    result_sheet = result_workbook.active
    result_sheet.append(RESULT_HEADERS)
    result_workbook.save(result_path)
    result_workbook.close()
    return queue_path, result_path, image_path


def run_self_test():
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_root = Path(temp_dir)
        queue_path, result_path, image_path = create_test_workbooks(temp_root)
        tasks = load_tasks(queue_path)
        if len(tasks) != 1:
            raise AssertionError("未能读取临时任务队列。")
        task = tasks[0]
        resolved_image = resolve_image_path(
            task["主体裁剪图路径"],
            temp_root,
            queue_path,
        )
        if resolved_image != image_path:
            raise AssertionError("主体裁剪图路径解析失败。")

        original_values = [task.get(header) for header in TASK_HEADERS]
        for status in ["搜索中", "无结果", "失败", "已搜索"]:
            update_task_status(task["任务ID"], status, queue_path)
            updated_tasks = load_tasks(queue_path)
            if updated_tasks[0]["任务状态"] != status:
                raise AssertionError(f"任务状态未正确更新为：{status}")
        updated_values = [updated_tasks[0].get(header) for header in TASK_HEADERS]
        status_index = TASK_HEADERS.index("任务状态")
        for index, original_value in enumerate(original_values):
            if index != status_index and updated_values[index] != original_value:
                raise AssertionError("更新任务状态时修改了其他字段。")

        manual_values = {
            "1688结果排名": "1",
            "1688商品标题": "测试1688商品",
            "1688商品链接": "https://detail.1688.com/offer/test.html",
            "1688价格": "12.80",
            "起批量": "2",
            "供应商名称": "测试供应商",
            "人工判断": "疑似同款",
            "备注": "人工测试",
        }
        append_manual_result(task, manual_values, "已搜索", result_path)
        update_task_status(task["任务ID"], "已搜索", queue_path)

        result_workbook = load_workbook(result_path, read_only=True, data_only=True)
        result_sheet = result_workbook.active
        result_header_map = get_header_map(result_sheet)
        if result_sheet.max_row != 2:
            raise AssertionError("手动结果未追加到结果表。")
        if result_sheet.cell(2, result_header_map["采集状态"]).value != "人工填写":
            raise AssertionError("采集状态未正确写入。")
        if result_sheet.cell(2, result_header_map["1688主图路径"]).value not in (None, ""):
            raise AssertionError("1688主图路径应保持为空。")
        result_workbook.close()

        saved_results = load_saved_results(task["任务ID"], result_path)
        if len(saved_results) != 1:
            raise AssertionError("未能读取当前任务已保存结果。")
        if not has_duplicate_result_link(
            task["任务ID"],
            manual_values["1688商品链接"],
            result_path,
        ):
            raise AssertionError("未能识别相同任务下的重复1688链接。")
        if has_duplicate_result_link(task["任务ID"], "", result_path):
            raise AssertionError("空链接不应触发重复判断。")
        opened_result_links = []
        if not open_saved_result_link(
            manual_values["1688商品链接"],
            lambda url, new=0: opened_result_links.append((url, new)) or True,
        ):
            raise AssertionError("已保存结果链接打开调用失败。")
        if opened_result_links != [(manual_values["1688商品链接"], 2)]:
            raise AssertionError("已保存结果链接打开地址不正确。")

        opened_urls = []
        if not open_1688_search_page(lambda url, new=0: opened_urls.append((url, new)) or True):
            raise AssertionError("1688页面打开调用失败。")
        if opened_urls != [(IMAGE_SEARCH_URL, 2)]:
            raise AssertionError("1688页面地址不正确。")
        explorer_calls = []
        open_image_folder(image_path, lambda args: explorer_calls.append(args) or object())
        if not explorer_calls or explorer_calls[0][0] != "explorer.exe":
            raise AssertionError("打开裁剪图文件夹调用失败。")

        root = tk.Tk()
        root.withdraw()
        messages = []
        original_showerror = messagebox.showerror
        original_showinfo = messagebox.showinfo
        original_showwarning = messagebox.showwarning
        original_askyesno = messagebox.askyesno
        messagebox.showerror = lambda title, message: messages.append(("error", title, message))
        messagebox.showinfo = lambda title, message: messages.append(("info", title, message))
        messagebox.showwarning = lambda title, message: messages.append(("warning", title, message))
        try:
            app = SearchRunnerApp(root, queue_path, result_path, temp_root)
            root.update_idletasks()
            if len(app.tree.get_children()) != 1:
                raise AssertionError("界面未显示任务列表。")
            if app.original_image is None:
                raise AssertionError("界面未显示主体裁剪图。")
            if len(app.saved_results) != 1 or len(app.saved_tree.get_children()) != 1:
                raise AssertionError("界面未显示当前任务已保存结果。")
            app.copy_crop_path()
            if root.clipboard_get() != str(image_path):
                raise AssertionError("主体裁剪图路径复制失败。")

            button_texts = []

            def collect_button_texts(widget):
                for child in widget.winfo_children():
                    if child.winfo_class() == "TButton":
                        button_texts.append(child.cget("text"))
                    collect_button_texts(child)

            collect_button_texts(root)
            for required_button in [
                "刷新任务队列",
                "打开 1688 以图搜款页面",
                "打开主体裁剪图所在文件夹",
                "复制主体裁剪图路径",
                "标记为搜索中",
                "标记为已搜索",
                "标记为无结果",
                "标记为失败",
                "保存手动结果",
                "打开选中1688链接",
                "导出人工搜款汇总表",
            ]:
                if required_button not in button_texts:
                    raise AssertionError(f"界面缺少按钮：{required_button}")

            root.attributes("-alpha", 0.0)
            root.deiconify()
            root.geometry("1000x640")
            root.update()
            save_buttons = []

            def collect_save_buttons(widget):
                for child in widget.winfo_children():
                    if (
                        child.winfo_class() == "TButton"
                        and child.cget("text") == "保存手动结果"
                    ):
                        save_buttons.append(child)
                    collect_save_buttons(child)

            collect_save_buttons(root)
            if not save_buttons or not save_buttons[0].winfo_ismapped():
                raise AssertionError("缩小窗口后保存手动结果按钮不可见。")
            if (
                app.results_scroll_content.winfo_reqheight()
                <= app.results_scroll_canvas.winfo_height()
            ):
                raise AssertionError("缩小窗口后人工填写区未进入可滚动状态。")

            first_saved_item = app.saved_tree.get_children()[0]
            app.saved_tree.selection_set(first_saved_item)
            opened_from_ui = []
            original_open_saved_result_link = globals()["open_saved_result_link"]
            globals()["open_saved_result_link"] = (
                lambda link, opener=None: opened_from_ui.append(link) or True
            )
            try:
                app.open_selected_result_link()
            finally:
                globals()["open_saved_result_link"] = original_open_saved_result_link
            if opened_from_ui != [manual_values["1688商品链接"]]:
                raise AssertionError("界面未能打开选中的1688链接。")

            duplicate_prompts = []
            messagebox.askyesno = lambda title, message, **kwargs: (
                duplicate_prompts.append((title, message, kwargs)) or False
            )
            app.manual_vars["1688商品链接"].set(manual_values["1688商品链接"])
            app.manual_vars["1688商品标题"].set("重复链接取消测试")
            app.save_manual_result()
            if len(load_saved_results(task["任务ID"], result_path)) != 1:
                raise AssertionError("取消重复保存时结果表仍新增了数据。")
            duplicate_message = "该任务下已保存过这个1688链接，是否仍然继续保存？"
            if not duplicate_prompts or duplicate_prompts[-1][1] != duplicate_message:
                raise AssertionError("重复链接提示不正确。")
            if duplicate_prompts[-1][2].get("default") != messagebox.NO:
                raise AssertionError("重复链接确认框未默认建议取消。")

            messagebox.askyesno = lambda title, message, **kwargs: True
            app.save_manual_result()
            if len(load_saved_results(task["任务ID"], result_path)) != 2:
                raise AssertionError("确认后未能继续保存重复链接。")
            if len(app.saved_tree.get_children()) != 2:
                raise AssertionError("保存后已保存结果区域未自动刷新。")

            queue_workbook = load_workbook(queue_path)
            queue_sheet = queue_workbook.active
            queue_sheet.delete_rows(2, queue_sheet.max_row)
            queue_workbook.save(queue_path)
            queue_workbook.close()
            app.refresh_queue()
            if app.tasks or app.current_task is not None or app.original_image is not None:
                raise AssertionError("空队列刷新后未清空当前显示。")
            empty_message = (
                "当前任务队列为空。请先打开 04_脚本/搜款前准备.bat，下载商品图，"
                "框选主体，保存裁剪图，并导出搜款任务队列。"
            )
            if not any(item[0] == "warning" and item[2] == empty_message for item in messages):
                raise AssertionError("空队列提示不正确。")

            queue_workbook = load_workbook(queue_path)
            queue_sheet = queue_workbook.active
            queue_sheet.append(original_values)
            queue_workbook.save(queue_path)
            queue_workbook.close()
            app.refresh_queue()
            if len(app.tasks) != 1 or app.original_image is None:
                raise AssertionError("刷新后未能显示新任务和主体裁剪图。")

            app.manual_vars["1688商品标题"].set("界面验收结果")
            app.save_manual_result()
            success_message = (
                "手动结果已保存，任务状态已更新为已搜索。"
                "可以继续处理下一条任务，或导出人工搜款汇总表。"
            )
            if not any(item[0] == "info" and item[2] == success_message for item in messages):
                raise AssertionError("保存手动结果后的提示不正确。")
            if app.current_task["任务状态"] != "已搜索":
                raise AssertionError("保存手动结果后任务状态不正确。")
        finally:
            messagebox.showerror = original_showerror
            messagebox.showinfo = original_showinfo
            messagebox.showwarning = original_showwarning
            messagebox.askyesno = original_askyesno
            root.destroy()

        queue_workbook = load_workbook(queue_path)
        queue_sheet = queue_workbook.active
        second_task = list(original_values)
        second_task[TASK_HEADERS.index("任务ID")] = "SEARCH_000002"
        second_task[TASK_HEADERS.index("商品ID")] = "TEST002"
        second_task[TASK_HEADERS.index("商品标题")] = "无结果测试商品"
        queue_sheet.append(second_task)
        queue_workbook.save(queue_path)
        queue_workbook.close()

        summary_path = temp_root / "output" / "1688_summary_test.xlsx"
        summary_count, _ = export_manual_summary_workbook(
            queue_path,
            result_path,
            summary_path,
        )
        summary_workbook = load_workbook(summary_path, read_only=True, data_only=True)
        summary_sheet = summary_workbook.active
        summary_headers = [
            summary_sheet.cell(1, column).value
            for column in range(1, summary_sheet.max_column + 1)
        ]
        summary_task_ids = [
            summary_sheet.cell(row, 1).value
            for row in range(2, summary_sheet.max_row + 1)
        ]
        summary_workbook.close()
        if summary_headers != SUMMARY_HEADERS:
            raise AssertionError("人工搜款汇总表字段不正确。")
        if summary_count != 4 or summary_task_ids.count("SEARCH_000001") != 3:
            raise AssertionError("一个任务多个结果时未在汇总表中保留多行。")
        if summary_task_ids.count("SEARCH_000002") != 1:
            raise AssertionError("无结果任务未在汇总表中保留一行。")

        print("SELF_TEST_OK")
        print(f"tasks={len(tasks)}")
        print(f"image={resolved_image}")
        print("status_update=OK")
        print("manual_result=OK")
        print("browser_call=OK")
        print("folder_call=OK")
        print("clipboard=OK")
        print("refresh_queue=OK")
        print("empty_queue_prompt=OK")
        print("saved_results=OK")
        print("duplicate_cancel=OK")
        print("duplicate_confirm=OK")
        print("open_saved_link=OK")
        print(f"summary_rows={summary_count}")


def main():
    parser = argparse.ArgumentParser(description="1688 搜款执行台")
    parser.add_argument("--self-test", action="store_true", help="运行非联网自测")
    args = parser.parse_args()

    if args.self_test:
        run_self_test()
        return 0

    root = tk.Tk()
    SearchRunnerApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
