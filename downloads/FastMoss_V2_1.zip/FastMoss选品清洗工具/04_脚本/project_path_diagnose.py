import getpass
import hashlib
import os
import platform
import re
import sys
from datetime import datetime
from pathlib import Path

from openpyxl import load_workbook


SCRIPT_FILE = Path(__file__).resolve()
SCRIPT_DIR = SCRIPT_FILE.parent
PROJECT_ROOT = SCRIPT_DIR.parent
SEARCH_ROOT = PROJECT_ROOT.parent
REPORT_FILE = PROJECT_ROOT / "logs" / "path_diagnose_report.txt"

KEY_FILES = [
    PROJECT_ROOT / "cleaned" / "Fastmoss_待搜款清洗表.xlsx",
    PROJECT_ROOT / "output" / "1688_待搜款任务队列.xlsx",
    PROJECT_ROOT / "output" / "1688_搜款结果表.xlsx",
    PROJECT_ROOT / "output" / "1688_人工搜款汇总表.xlsx",
    SCRIPT_DIR / "search_prep_tool.py",
    SCRIPT_DIR / "1688_search_runner.py",
    SCRIPT_DIR / "搜款前准备.bat",
    SCRIPT_DIR / "1688搜款执行台.bat",
    SCRIPT_DIR / "检查搜款任务队列.bat",
]

EXCEL_FILES = KEY_FILES[:4]
BAT_FILES = KEY_FILES[6:9]

SEARCH_FILE_NAMES = {
    "Fastmoss_待搜款清洗表.xlsx",
    "1688_待搜款任务队列.xlsx",
    "1688_搜款结果表.xlsx",
    "1688_人工搜款汇总表.xlsx",
    "search_prep_tool.py",
    "1688_search_runner.py",
}


def text_value(value):
    return "" if value is None else str(value).strip()


def normalize_header(value):
    return text_value(value).replace("\n", "").replace("\r", "")


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as file_handle:
        for chunk in iter(lambda: file_handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def format_time(timestamp):
    return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")


def file_details(path):
    path = Path(path).resolve()
    details = {
        "path": path,
        "exists": path.is_file(),
        "size": None,
        "modified": None,
        "sha256": None,
    }
    if details["exists"]:
        stat = path.stat()
        details["size"] = stat.st_size
        details["modified"] = format_time(stat.st_mtime)
        details["sha256"] = sha256_file(path)
    return details


def inspect_excel(path):
    path = Path(path)
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        row_iterator = worksheet.iter_rows(values_only=True)
        first_row = next(row_iterator, ())
        headers = [normalize_header(value) for value in first_row]
        header_map = {
            header: index
            for index, header in enumerate(headers)
            if header and header not in headers[:index]
        }
        nonempty_rows = 0
        task_id_rows = 0
        result_link_rows = 0
        for row in row_iterator:
            if not any(text_value(value) for value in row):
                continue
            nonempty_rows += 1
            task_id_index = header_map.get("任务ID")
            result_link_index = header_map.get("1688商品链接")
            if task_id_index is not None and task_id_index < len(row):
                task_id_rows += int(bool(text_value(row[task_id_index])))
            if result_link_index is not None and result_link_index < len(row):
                result_link_rows += int(bool(text_value(row[result_link_index])))
        return {
            "sheet": worksheet.title,
            "headers": headers,
            "total_rows": worksheet.max_row,
            "nonempty_rows": nonempty_rows,
            "task_id_rows": task_id_rows,
            "result_link_rows": result_link_rows,
        }
    finally:
        workbook.close()


def find_named_files(search_root, names, max_depth=3):
    search_root = Path(search_root).resolve()
    matches = []
    for current_dir, dir_names, file_names in os.walk(search_root):
        current_path = Path(current_dir)
        try:
            depth = len(current_path.relative_to(search_root).parts)
        except ValueError:
            continue
        if depth >= max_depth:
            dir_names[:] = []
        for file_name in file_names:
            if file_name in names:
                matches.append((file_name, (current_path / file_name).resolve()))
    return sorted(matches, key=lambda item: (item[0].lower(), str(item[1]).lower()))


def bat_uses_project_root(path):
    content = Path(path).read_text(encoding="utf-8-sig", errors="replace")
    pattern = re.compile(r'cd\s+/d\s+"%~dp0\.\.[\\/]?"', re.IGNORECASE)
    return bool(pattern.search(content)), content


def build_report():
    lines = []

    def add(line=""):
        lines.append(str(line))

    add("=" * 78)
    add("Fastmoss 1688 项目路径诊断报告")
    add("=" * 78)
    add(f"生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    add()
    add("一、基础路径信息")
    add(f"当前脚本路径 (__file__)：{SCRIPT_FILE}")
    add(f"当前工作目录 (os.getcwd())：{Path(os.getcwd()).resolve()}")
    add(f"推断的项目根目录：{PROJECT_ROOT}")
    add(f"项目根目录上一级搜索目录：{SEARCH_ROOT}")
    add(f"Python解释器路径：{Path(sys.executable).resolve()}")
    add(f"当前用户名：{getpass.getuser()}")
    add(f"系统平台：{platform.platform()}")

    add()
    add("二、关键文件检查")
    current_details = {}
    for path in KEY_FILES:
        details = file_details(path)
        current_details[path.name] = details
        add(f"文件：{path.relative_to(PROJECT_ROOT)}")
        add(f"  绝对路径：{details['path']}")
        add(f"  是否存在：{'是' if details['exists'] else '否'}")
        if details["exists"]:
            add(f"  文件大小：{details['size']} 字节")
            add(f"  最近修改时间：{details['modified']}")
            add(f"  SHA-256：{details['sha256']}")
        else:
            add("  SHA-256：跳过（文件不存在）")

    add()
    add("三、Excel数据检查（只读模式）")
    excel_findings = []
    for path in EXCEL_FILES:
        add(f"Excel：{path}")
        if not path.is_file():
            add("  状态：文件不存在，跳过")
            continue
        try:
            result = inspect_excel(path)
            add(f"  工作表：{result['sheet']}")
            add(f"  表头：{result['headers']}")
            add(f"  工作表总行数（含表头）：{result['total_rows']}")
            add(f"  非空数据行数：{result['nonempty_rows']}")
            if path.name == "Fastmoss_待搜款清洗表.xlsx":
                if "主体裁剪图路径" not in result["headers"]:
                    excel_findings.append(
                        "标准表缺少“主体裁剪图路径”列，尚未形成可导出的裁剪任务数据。"
                    )
            if path.name == "1688_待搜款任务队列.xlsx":
                add(f"  任务ID非空行数：{result['task_id_rows']}")
            if path.name == "1688_搜款结果表.xlsx":
                add(f"  1688商品链接非空行数：{result['result_link_rows']}")
        except Exception as exc:
            add(f"  读取失败：{exc}")
    standard_path = EXCEL_FILES[0]
    queue_path = EXCEL_FILES[1]
    if standard_path.is_file() and queue_path.is_file():
        if standard_path.stat().st_mtime > queue_path.stat().st_mtime:
            excel_findings.append(
                "标准表的修改时间晚于任务队列，任务队列可能尚未按最新标准表重新导出。"
            )
    if excel_findings:
        add("  Excel结构与时间线提示：")
        for finding in excel_findings:
            add(f"  - {finding}")

    add()
    add("四、重复项目或重复文件检查")
    add(f"搜索起点：{SEARCH_ROOT}")
    add("最大搜索深度：3层")
    matches = find_named_files(SEARCH_ROOT, SEARCH_FILE_NAMES, max_depth=3)
    duplicate_count = 0
    if not matches:
        add("未找到任何目标文件。")
    for file_name, found_path in matches:
        details = file_details(found_path)
        current = current_details.get(file_name)
        same_as_current = bool(
            current
            and current["exists"]
            and details["sha256"] == current["sha256"]
        )
        is_current_file = bool(current and found_path == current["path"])
        if not is_current_file:
            duplicate_count += 1
        add(f"文件名：{file_name}")
        add(f"  绝对路径：{found_path}")
        add(f"  文件大小：{details['size']} 字节")
        add(f"  修改时间：{details['modified']}")
        add(f"  SHA-256：{details['sha256']}")
        add(f"  是否为当前项目文件：{'是' if is_current_file else '否'}")
        add(f"  是否与当前项目对应文件相同：{'是' if same_as_current else '否'}")
    add(f"当前项目之外的同名文件数量：{duplicate_count}")

    add()
    add("五、BAT路径稳定性检查")
    unstable_bats = []
    for path in BAT_FILES:
        add(f"BAT：{path}")
        if not path.is_file():
            add("  状态：文件不存在")
            continue
        stable, content = bat_uses_project_root(path)
        cd_lines = [line.strip() for line in content.splitlines() if line.strip().lower().startswith("cd ")]
        add(f"  cd命令：{cd_lines or ['未找到']}")
        add(f"  是否包含 cd /d \"%~dp0..\"：{'是' if stable else '否'}")
        if not stable:
            unstable_bats.append(path)
            add("  风险提示：该bat可能没有固定到项目根目录，双击时可能导致相对路径不一致。")
    add(f"存在路径风险的BAT数量：{len(unstable_bats)}")

    add()
    add("六、诊断结论")
    if duplicate_count:
        add(f"发现 {duplicate_count} 个当前项目之外的同名文件，请核对实际启动位置。")
    else:
        add("在指定搜索范围内未发现当前项目之外的同名文件。")
    if unstable_bats:
        add(f"发现 {len(unstable_bats)} 个BAT未按要求固定到项目根目录。")
    else:
        add("被检查的BAT均已固定到项目根目录。")
    for finding in excel_findings:
        add(f"Excel诊断：{finding}")
    add(f"诊断报告保存位置：{REPORT_FILE}")
    add("=" * 78)
    return lines


def main():
    try:
        report_lines = build_report()
        report_text = "\n".join(report_lines) + "\n"
        print(report_text, end="")
        REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
        REPORT_FILE.write_text(report_text, encoding="utf-8")
        return 0
    except Exception as exc:
        print(f"项目路径诊断失败：{exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
