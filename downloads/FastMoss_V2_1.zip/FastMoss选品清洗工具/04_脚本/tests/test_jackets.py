import copy
import hashlib
import json
from pathlib import Path
import sys
import unittest
import zipfile
from datetime import timedelta

from openpyxl import load_workbook

SCRIPT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPT))
import fastmoss_cleaner as cleaner
import test_v2 as legacy
from potential_scoring import context_for, score_record
from target_selection import audit_fingerprint
from v2_config import load_config

TODAY = legacy.TODAY


class JacketRulesTest(unittest.TestCase):
    def setUp(self):
        self.keywords, self.config = load_config(SCRIPT.parent)

    def record(self, **values):
        record = {"商品名称": "Women's yoga full zip jacket", "商品分类": "女士运动外套",
                  "商品ID": "J1", "店铺名": "Independent", "商品售价": "$35", "国家/地区": "US",
                  "商品状态": "在售", "销量": 1500, "销量环比": "400%",
                  "预估商品上架时间": TODAY - timedelta(days=10),
                  "FastMoss 商品详情页": "https://example.com/J1", "_image_url": "https://example.com/J1.png"}
        record.update(values)
        return cleaner.prepare_record(record, None)

    def score(self, record, audit=None, old_fingerprint=None):
        manual = {} if audit is None else {"图片款式审核": audit, "图片审核指纹": old_fingerprint or audit_fingerprint(record)}
        outcome = score_record(record, TODAY, self.keywords, self.config, context_for([record], self.keywords), manual)
        return outcome, record

    def test_female_jacket_waits_for_picture_review(self):
        outcome, record = self.score(self.record())
        self.assertEqual(outcome, "复查")
        self.assertEqual(record["服装类型判定"], "外套")
        self.assertEqual(record["适用人群判定"], "女款明示")
        self.assertIn("图片款式未确认", record["人工复查原因"])

    def test_confirmed_female_jacket_recommended(self):
        outcome, record = self.score(self.record(), "确认女士运动外套")
        self.assertEqual(outcome, "推荐")
        self.assertEqual(record["类目得分"], 15)
        self.assertEqual(record["价格得分"], 10)
        self.assertIn("女士运动外套", record["1688搜索关键词"])

    def test_clear_male_clothing_hard_rejected(self):
        for title in ("Men's yoga jacket", "MEN’S full zip workout jacket", "Mens running jackets", "男款瑜伽夹克", "男运动外套", "运动夹克男"):
            with self.subTest(title=title):
                outcome, r = self.score(self.record(**{"商品名称": title, "商品分类": "运动外套"}), "确认女士运动外套")
                self.assertEqual(outcome, "删除")
                self.assertTrue(any("男款" in reason for reason in r["_delete_reasons"]))

    def test_hoodie_sweatshirt_rejected_even_with_jacket_label(self):
        for title in ("Women's yoga hoodie jacket", "Women’s full zip sweatshirt", "Ladies hoodies workout", "女款运动卫衣外套", "女士套头衫"):
            with self.subTest(title=title):
                outcome, r = self.score(self.record(**{"商品名称": title}), "确认女士运动外套")
                self.assertEqual(outcome, "删除")
                self.assertEqual(r["服装类型判定"], "卫衣/套头衫")

    def test_hooded_jacket_is_not_hoodie(self):
        outcome, r = self.score(self.record(**{"商品名称": "Women's hooded running jacket"}), "确认女士运动外套")
        self.assertEqual(outcome, "推荐")
        self.assertEqual(r["服装类型判定"], "外套")

    def test_non_jackets_hard_rejected(self):
        for title, category in [("Women's yoga leggings", "运动长裤"), ("Women's sports bra", "运动文胸"),
                                ("Ladies crop top", "运动上衣"), ("Women's workout shorts", "运动短裤"),
                                ("Women's sports dress", "运动裙"), ("女士瑜伽背心", "运动服饰")]:
            with self.subTest(title=title):
                outcome, r = self.score(self.record(**{"商品名称": title, "商品分类": category}), "确认女士运动外套")
                self.assertEqual(outcome, "删除")
                self.assertEqual(r["服装类型判定"], "非外套")

    def test_unknown_audience_needs_review(self):
        r = self.record(**{"商品名称": "Yoga training jacket", "商品分类": "运动外套"})
        outcome, r = self.score(r)
        self.assertEqual(outcome, "复查")
        self.assertIn("缺少女款标注", r["人工复查原因"])
        self.assertEqual(self.score(self.record(**{"商品名称": "Yoga training jacket", "商品分类": "运动外套"}), "确认女士运动外套")[0], "推荐")

    def test_unisex_children_and_fashion_coats_rejected(self):
        for title in ("Unisex workout jacket women men", "男女同款防晒运动外套", "Girls yoga jacket", "Women's faux leather jacket", "女士牛仔夹克运动外套"):
            with self.subTest(title=title):
                self.assertEqual(self.score(self.record(**{"商品名称": title}), "确认女士运动外套")[0], "删除")

    def test_title_category_conflict_and_manual_confirmation(self):
        r = self.record(**{"商品分类": "运动长裤"})
        outcome, r = self.score(r)
        self.assertEqual(outcome, "复查")
        self.assertIn("品类冲突", r["服装类型判定"])
        self.assertEqual(self.score(self.record(**{"商品分类": "运动长裤"}), "确认女士运动外套")[0], "推荐")

    def test_manual_photo_rejection_overrides_female_title(self):
        for audit in ("男款", "卫衣", "非运动外套"):
            outcome, r = self.score(self.record(), audit)
            self.assertEqual(outcome, "删除")
            self.assertIn("图片款式人工排除", "；".join(r["_delete_reasons"]))
        self.assertEqual(self.score(self.record(), "无法确认")[0], "复查")

    def test_picture_change_invalidates_audit(self):
        original = self.record()
        fingerprint = audit_fingerprint(original)
        for changes in ({"_image_url": "https://example.com/new.png"}, {"商品名称": "Women's red yoga jacket"},
                        {"商品分类": "运动上装"}, {"_image_signature": "new-embedded-image-hash"}):
            with self.subTest(changes=changes):
                outcome, r = self.score(self.record(**changes), "确认女士运动外套", fingerprint)
                self.assertEqual(outcome, "复查")
                self.assertEqual(r["图片款式审核"], "待审核")
                self.assertIn("重新审核", r["人工复查原因"])

    def test_invalid_or_legacy_audit_cannot_approve(self):
        self.assertEqual(self.score(self.record(), "随便填")[0], "复查")
        r = self.record()
        outcome = score_record(r, TODAY, self.keywords, self.config, context_for([r], self.keywords), {"图片款式审核": "确认女士运动外套"})
        self.assertEqual(outcome, "复查")
        self.assertEqual(r["图片款式审核"], "待审核")

    def test_missing_picture_and_sport_purpose(self):
        self.assertEqual(self.score(self.record(**{"_image_url": ""}), "确认女士运动外套")[0], "复查")
        outcome, r = self.score(self.record(**{"商品名称": "Women's casual jacket", "商品分类": "女士外套"}))
        self.assertIn("运动用途", r["人工复查原因"])
        self.assertEqual(outcome, "复查")

    def test_windbreaker_sun_protection_and_boyfriend_fit(self):
        for title in ("Women's training windbreaker", "女士防晒衣", "男友风女士运动夹克", "Women's boyfriend fit running jacket"):
            with self.subTest(title=title):
                self.assertEqual(self.score(self.record(**{"商品名称": title}), "确认女士运动外套")[0], "推荐")

    def test_weak_words_cannot_override_strict_target(self):
        r = self.record(**{"商品名称": "Women's sports yoga pants", "商品分类": "运动长裤"})
        outcome, r = self.score(r)
        self.assertEqual(outcome, "删除")
        self.assertGreater(r["商品潜力评分"], 50)
        self.config["target_selection"]["enabled"] = False
        self.assertEqual(self.score(self.record(**{"商品名称": "Women's yoga leggings", "商品分类": "瑜伽裤", "商品售价": "$25"}))[0], "推荐")


class JacketIntegrationTest(unittest.TestCase):
    def setUp(self):
        self.fixture = legacy.IntegrationTest()
        self.fixture.setUp()
        self.root = self.fixture.root
        cfg = json.loads((SCRIPT.parent / "target_config.json").read_text())
        (self.root / "target_config.json").write_text(json.dumps(cfg))
        w = load_workbook(self.fixture.file)
        sheet = w["商品数据"]
        for row in range(4, sheet.max_row + 1):
            sheet.cell(row, 1, "Women's yoga full zip jacket")
            sheet.cell(row, 7, "运动外套")
        sheet.cell(5, 1, "Women’s workout full zip jacket")
        sheet.cell(6, 1, "Women's yoga hoodie jacket")
        sheet.cell(7, 1, "Men's yoga jacket")
        sheet.cell(9, 1, "Yoga windbreaker")
        sheet.cell(13, 1, "Women's yoga leggings")
        sheet.cell(13, 7, "运动长裤")
        w.save(self.fixture.file)
        w.close()

    def tearDown(self):
        self.fixture.tearDown()

    def test_strict_pipeline_and_photo_review_roundtrip(self):
        f = self.fixture
        initial_hash = hashlib.sha256(f.file.read_bytes()).hexdigest()
        f.run_cleaner()
        w = f.report()
        self.assertEqual(len(f.records(w["推荐商品"])), 0)
        self.assertEqual(len(f.records(w["待人工复查"])), 5)
        self.assertEqual(len(f.records(w["删除记录"])), 7)
        self.assertEqual(len(w["待人工复查"]._images), 4)
        w.close()
        w = f.report(data_only=False)
        review = w["待人工复查"]
        headers = [c.value for c in review[1]]
        for row in range(2, review.max_row + 1):
            product_id = review.cell(row, headers.index("商品ID") + 1).value
            if product_id in ("P1", "P2"):
                review.cell(row, headers.index("图片款式审核") + 1, "男款" if product_id == "P1" else "确认女士运动外套")
        w.save(self.root / "02_筛选后表格/选品报告.xlsx")
        w.close()
        standard = self.root / "cleaned/Fastmoss_待搜款清洗表.xlsx"
        w = load_workbook(standard)
        headers = [c.value for c in w.active[1]]
        for row in range(2, w.active.max_row + 1):
            if w.active.cell(row, headers.index("商品ID") + 1).value == "R2":
                w.active.cell(row, headers.index("是否进入搜款") + 1, "是")
                w.active.cell(row, headers.index("搜款状态") + 1, "已裁剪")
        w.save(standard)
        w.close()
        f.run_cleaner()
        w = f.report()
        recommended = f.records(w["推荐商品"])
        self.assertEqual([r["商品ID"] for r in recommended], ["P2"])
        self.assertEqual(recommended[0]["图片款式审核"], "确认女士运动外套")
        p1 = next(r for r in f.records(w["删除记录"]) if r["商品ID"] == "P1")
        self.assertIn("图片款式人工排除", p1["删除原因"])
        w.close()
        self.assertEqual(hashlib.sha256(f.file.read_bytes()).hexdigest(), initial_hash)
        w = load_workbook(standard)
        male = next(r for r in f.records(w.active) if r["商品ID"] == "R2")
        self.assertEqual(male["是否进入搜款"], "否")
        self.assertEqual(male["搜款状态"], "已裁剪")
        w.close()
        latest = sorted((self.root / "02_筛选后表格").glob("FastMoss清洗结果_*.xlsx"))[-1]
        w = load_workbook(latest)
        data = list(w["FastMoss筛选表"].values)
        self.assertEqual(len(data), 3)  # title, header, one confirmed item
        self.assertEqual(data[2][12], "Women’s workout full zip jacket")
        w.close()
        light = self.root / "02_筛选后表格/选品报告_轻量.xlsx"
        with zipfile.ZipFile(light) as zipped:
            self.assertFalse(any(n.startswith("xl/media/") for n in zipped.namelist()))
        w = load_workbook(light)
        self.assertEqual(len(f.records(w["推荐商品"])), 1)
        self.assertIn("轻量表说明", w.sheetnames)
        w.close()
        # A new image address with the same product ID invalidates prior approval.
        w = load_workbook(f.file)
        w["商品数据"]["C5"] = f.base_url + "/changed.png"
        w.save(f.file)
        w.close()
        f.run_cleaner("--no-download-images")
        w = f.report()
        self.assertEqual(len(f.records(w["推荐商品"])), 0)
        p2 = next(r for r in f.records(w["待人工复查"]) if r["商品ID"] == "P2")
        self.assertEqual(p2["图片款式审核"], "待审核")
        self.assertIn("重新审核", p2["人工复查原因"])
        w.close()

    def test_missing_target_config_fails_without_broadening(self):
        (self.root / "target_config.json").unlink()
        result = self.fixture.run_cleaner(expected=1)
        self.assertIn("target_config.json", result.stdout)


if __name__ == "__main__":
    unittest.main()
