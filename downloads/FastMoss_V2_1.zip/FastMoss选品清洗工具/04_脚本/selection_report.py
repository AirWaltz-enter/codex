"""Excel report, manual state persistence and audit trail for the existing cleaner."""
import hashlib
import json
import os
import shutil
from datetime import date, datetime
from pathlib import Path

import xlsxwriter
from openpyxl import load_workbook
from xlsxwriter.utility import xl_col_to_name

from potential_scoring import MANUAL_FIELDS, MANUAL_STATE_FIELDS, V2_HEADERS, record_key, text
from target_selection import IMAGE_AUDIT_OPTIONS, TARGET_HEADERS


REPORT_HEADERS = [
    "商品图片", "商品名称", "商品链接", "销量", "销量增长", "上架时间", "关键词匹配",
    "商品潜力评分", "商品等级", "推荐动作", "图片吸引力评分", "图片得分", "自动评分",
    "商品生命周期", "商品年龄(天)", "1688搜索关键词", "老板审核", "供应链状态", "备注",
    "人工复查原因", "商品售价", "国家/地区", "商品分类", "店铺名", "商品状态",
    "商品ID", "SPU", "记录键", "原始文件", "原始工作表", "原始行号",
    "销量得分", "增长得分", "年龄得分", "类目得分", "价格得分", "竞争得分",
    "竞争判断依据", "价格判断依据", "排除词命中", "商品图片链接", "本地图片路径",
    "处理说明",
] + TARGET_HEADERS


def load_manual_states(report_file):
    """The fixed report is the manual-review source of truth, including deleted rows."""
    path = Path(report_file)
    if not path.exists():
        return {}
    states = {}
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        for name in ("推荐商品", "待人工复查", "删除记录"):
            if name not in workbook.sheetnames:
                continue
            rows = iter(workbook[name].values)
            headers = list(next(rows, ()))
            if "记录键" not in headers:
                raise ValueError(f"旧报告 {name} 缺少记录键，无法安全保留人工审核；请先备份并移走该报告")
            for row in rows:
                data = dict(zip(headers, row))
                key = data.get("记录键")
                if not key:
                    continue
                state = {field: data.get(field) for field in MANUAL_STATE_FIELDS}
                if key in states and states[key] != state:
                    raise ValueError(f"同一商品的人工审核冲突：{key}；请统一报告中重复商品的审核值")
                states[key] = state
    finally:
        workbook.close()
    return states


def backup_file(path, backup_dir):
    path, backup_dir = Path(path), Path(backup_dir)
    if path.exists():
        backup_dir.mkdir(parents=True, exist_ok=True)
        target = backup_dir / f"{path.stem}_{datetime.now():%Y%m%d_%H%M%S_%f}{path.suffix}"
        shutil.copy2(path, target)
        return target


class ReportWriter:
    def __init__(self, workbook):
        self.workbook = workbook
        base = {"valign": "vcenter", "text_wrap": True, "border": 1, "border_color": "#D9E1F2"}
        self.body = workbook.add_format(base)
        self.header = workbook.add_format({**base, "bold": True, "bg_color": "#0F766E", "font_color": "white"})
        self.percent = workbook.add_format({**base, "num_format": "0.##%"})
        self.date = workbook.add_format({**base, "num_format": "yyyy-mm-dd"})
        self.number = workbook.add_format({**base, "num_format": "0"})
        self.link = workbook.add_format({**base, "font_color": "blue", "underline": 1})
        self.manual = workbook.add_format({**base, "bg_color": "#EAF2F8"})
        self.fills = {name: workbook.add_format({"bg_color": color}) for name, color in {
            "新品": "#C6EFCE", "成长款": "#FFEB9C", "老款": "#D9D9D9", "待核对": "#FCE4D6",
            "A类": "#C6EFCE", "B类": "#DDEBF7", "C类": "#FFEB9C", "D类": "#D9D9D9"}.items()}

    def setup(self, sheet, headers, rows):
        sheet.freeze_panes(1, 0)
        sheet.set_row(0, 32)
        sheet.write_row(0, 0, headers, self.header)
        sheet.autofilter(0, 0, max(len(rows), 1), len(headers) - 1)
        for col, header in enumerate(headers):
            if header == "商品图片":
                width = 16
            else:
                samples = [text(r.get(header)) for r in rows]
                def display_len(value):
                    return sum(2 if ord(c) > 255 else 1 for c in value)
                width = min(52, max(12, display_len(header) + 2, *(min(50, display_len(v)) + 2 for v in samples)))
            sheet.set_column(col, col, width)
        return {h: i for i, h in enumerate(headers)}

    def formulas(self, sheet, row, data, columns):
        def ref(name):
            return f"{xl_col_to_name(columns[name])}{row + 1}"
        rating, image, auto, score = (ref(h) for h in ("图片吸引力评分", "图片得分", "自动评分", "商品潜力评分"))
        # Guard paste values as well as interactive data validation.
        image_formula = f'=IFERROR(IF(AND(ISNUMBER({rating}),{rating}>=1,{rating}<=5,MOD({rating},1)=0),{rating}*3,0),0)'
        sheet.write_formula(row, columns["图片得分"], image_formula, self.number, data["图片得分"])
        sheet.write_formula(row, columns["商品潜力评分"], f"=MIN(100,{auto}+{image})", self.number, data["商品潜力评分"])
        sheet.write_formula(row, columns["商品等级"], f'=IF({score}>=80,"A类",IF({score}>=65,"B类",IF({score}>=50,"C类","D类")))', self.body, data["商品等级"])
        sheet.write_formula(row, columns["推荐动作"], f'=IF({score}>=80,"优先开发",IF({score}>=65,"小批量测试",IF({score}>=50,"观察","暂不上架")))', self.body, data["推荐动作"])

    def write_products(self, sheet, records, source_file, source_ws, reasons=None):
        headers = REPORT_HEADERS + (["删除原因"] if reasons is not None else [])
        rows = []
        for record in records:
            data = {h: record.get(h) for h in REPORT_HEADERS}
            data.update({"商品图片": record.get("_local_image_path"), "商品链接": record.get("FastMoss 商品详情页"),
                         "销量": None if record.get("_sales_missing") else record.get("_sales"),
                         "销量增长": record.get("_growth"), "上架时间": record.get("_listing_date"),
                         "记录键": record_key(record), "原始文件": source_file.name,
                         "原始工作表": source_ws.title, "原始行号": record["_source_row"],
                         "商品图片链接": record.get("_image_url"), "本地图片路径": record.get("_local_image_path"),
                         "处理说明": "；".join(dict.fromkeys(record.get("_notes", [])))})
            if reasons is not None:
                data["删除原因"] = "；".join(record.get("_delete_reasons", []))
            rows.append(data)
        columns = self.setup(sheet, headers, rows)
        for row, (data, record) in enumerate(zip(rows, records), 1):
            sheet.set_row(row, 80)
            for col, header in enumerate(headers):
                value = data.get(header)
                fmt = self.manual if header in MANUAL_FIELDS else self.body
                if header == "商品图片":
                    if value and Path(value).is_file():
                        from PIL import Image
                        with Image.open(value) as img:
                            width, height = img.size
                        scale = min(95 / width, 95 / height)
                        # Floating images are visible in older Excel and WPS as well as modern Excel.
                        sheet.insert_image(row, col, str(value), {"x_scale": scale, "y_scale": scale, "x_offset": 4, "y_offset": 4, "object_position": 1})
                    else:
                        sheet.write_string(row, col, "图片未获取", self.body)
                        sheet.write_comment(row, col, record.get("_image_error", "没有可用图片；可用原有仅图片嵌入入口重试"))
                elif value is None:
                    sheet.write_blank(row, col, None, fmt)
                elif header == "商品链接" and text(value).startswith(("https://", "http://")):
                    sheet.write_url(row, col, value, self.link, string=value)
                elif isinstance(value, (date, datetime)):
                    dt = value if isinstance(value, datetime) else datetime.combine(value, datetime.min.time())
                    sheet.write_datetime(row, col, dt, self.date)
                elif isinstance(value, (int, float)):
                    sheet.write_number(row, col, value, self.percent if header == "销量增长" else fmt)
                else:
                    sheet.write_string(row, col, text(value), fmt)
            self.formulas(sheet, row, data, columns)
        last = max(len(rows), 1)
        rating = columns["图片吸引力评分"]
        sheet.data_validation(1, rating, last, rating, {"validate": "integer", "criteria": "between", "minimum": 1, "maximum": 5,
            "ignore_blank": True, "error_type": "stop", "error_title": "图片评分无效", "error_message": "请填 1-5 的整数，或留空。"})
        for name, values in (("老板审核", ["待审核", "推荐", "放弃"]), ("供应链状态", ["未找货", "已找到1688", "已询价", "待测试"]), ("图片款式审核", IMAGE_AUDIT_OPTIONS)):
            col = columns[name]
            sheet.data_validation(1, col, last, col, {"validate": "list", "source": values, "error_type": "stop"})
        for name, values in (("商品生命周期", ["新品", "成长款", "老款", "待核对"]), ("商品等级", ["A类", "B类", "C类", "D类"])):
            col = columns[name]
            for value in values:
                sheet.conditional_format(1, col, last, col, {"type": "cell", "criteria": "equal to", "value": f'"{value}"', "format": self.fills[value]})

    def write_raw(self, source_wb):
        for index, source in enumerate(source_wb):
            sheet = self.workbook.add_worksheet("原始数据" if index == 0 else f"原始数据_{index + 1}")
            sheet.freeze_panes(1, 0)
            for row in source:
                for cell in row:
                    value = cell.value
                    if value is None:
                        continue
                    if isinstance(value, (date, datetime)):
                        dt = value if isinstance(value, datetime) else datetime.combine(value, datetime.min.time())
                        sheet.write_datetime(cell.row - 1, cell.column - 1, dt, self.date)
                    elif isinstance(value, (int, float)):
                        fmt = self.percent if "%" in cell.number_format else self.body
                        sheet.write_number(cell.row - 1, cell.column - 1, value, fmt)
                    else:
                        # Raw formulas are retained as text, never executed as imported instructions.
                        sheet.write_string(cell.row - 1, cell.column - 1, str(value), self.body)
            for col in range(1, source.max_column + 1):
                width = min(52, max(12, *(min(50, sum(2 if ord(c) > 255 else 1 for c in str(source.cell(row, col).value or ""))) + 2 for row in range(1, source.max_row + 1))))
                sheet.set_column(col - 1, col - 1, width)
            sheet.autofilter(0, 0, source.max_row - 1, source.max_column - 1)


def save_report(output_file, kept, review, deleted, source_file, source_wb, source_ws, today, keywords, config, backup_dir, logger):
    path = Path(output_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.stem}_{datetime.now():%Y%m%d_%H%M%S_%f}.tmp.xlsx")
    backup_file(path, backup_dir)
    try:
        with xlsxwriter.Workbook(str(temp), {"strings_to_urls": False, "strings_to_formulas": False}) as workbook:
            writer = ReportWriter(workbook)
            logger.write("正在生成选品报告：推荐商品、待人工复查、删除记录、原始数据、运行说明...")
            sort = lambda r: (r["商品潜力评分"], r.get("_sales") or 0)
            writer.write_products(workbook.add_worksheet("推荐商品"), sorted(kept, key=sort, reverse=True), Path(source_file), source_ws)
            writer.write_products(workbook.add_worksheet("待人工复查"), sorted(review, key=sort, reverse=True), Path(source_file), source_ws)
            writer.write_products(workbook.add_worksheet("删除记录"), [item["record"] for item in deleted], Path(source_file), source_ws, reasons=True)
            writer.write_raw(source_wb)
            meta = workbook.add_worksheet("运行说明")
            meta.freeze_panes(1, 0)
            meta.write_row(0, 0, ["项目", "内容"], writer.header)
            values = [
                ("版本", "FastMoss女士运动服饰选品系统 V2.1"), ("评估日期", today.isoformat()),
                ("选品目标", config["target_selection"]["target_name"] if config["target_selection"]["enabled"] else "宽泛女士运动服饰模式"),
                ("图片款式", "没有自动图像识别模型。默认须在图片款式审核确认女士运动外套后重跑；不推断模特个人性别。标题/类目/图片来源变化会使审核失效。同一URL背后图片替换无法仅凭来源指纹发现。"),
                ("输入文件", str(source_file)), ("输入 SHA256", hashlib.sha256(Path(source_file).read_bytes()).hexdigest()),
                ("数量", f"推荐 {len(kept)}；复查 {len(review)}；删除 {len(deleted)}"),
                ("图片评分", "留空=未评分，计0分；1-5整数乘3；自动评分最高85，总分最高100"),
                ("人工审核", "请仅在本选品报告修改蓝色列；保存关闭Excel后重新运行清洗，按新评分排序并保留审核"),
                ("复查规则", "严格目标模式：明确男款、卫衣、非外套硬删除；人群/款式不明及图片未审核进入复查。原下架/国家/增长/日期规则仍执行。"),
                ("竞争限制", "样本数量仅是导出内竞争代理指标，不代表全市场竞争；品牌命中需人工核实"),
                ("原始数据", "所有工作表的单元格数据副本，公式按文本保留；完整格式和嵌入图片仍以未修改的输入文件为准"),
                ("关键词配置", json.dumps(keywords, ensure_ascii=False)), ("评分配置", json.dumps(config, ensure_ascii=False)),
            ]
            for row, pair in enumerate(values, 1):
                meta.write_row(row, 0, pair, writer.body)
                meta.set_row(row, 48 if row < 11 else 160)
            meta.set_column(0, 0, 20)
            meta.set_column(1, 1, 110)
        os.replace(temp, path)
    except Exception:
        if temp.exists():
            temp.unlink()
        raise
    logger.write(f"选品报告已生成：{path}")
