import copy
import hashlib
import http.server
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import unittest
from datetime import date, timedelta
from unittest.mock import patch

from openpyxl import Workbook, load_workbook
from openpyxl.drawing.image import Image as XLImage
from PIL import Image
import xlsxwriter

SCRIPT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPT))
import fastmoss_cleaner as cleaner
from potential_scoring import context_for, grade, growth_points, hit, image_points, price_points, score_record, search_terms
from v2_config import load_config
from selection_report import load_manual_states

TODAY = date(2026, 7, 11)


class RulesTest(unittest.TestCase):
    def setUp(self):
        self.keywords, self.config = load_config(SCRIPT.parent)

    def record(self, **values):
        r = {"商品名称": "Women's seamless flare leggings", "商品分类": "瑜伽裤", "销量": 1500,
             "销量环比": "400%", "预估商品上架时间": TODAY - timedelta(days=10), "商品售价": "$25",
             "国家/地区": "US", "商品状态": "在售", "商品ID": "1", "店铺名": "Independent",
             "FastMoss 商品详情页": "https://example.com/product"}
        r.update(values)
        return cleaner.prepare_record(r, None)

    def score(self, record, manual=None):
        outcome = score_record(record, TODAY, self.keywords, self.config, context_for([record], self.keywords), manual)
        return outcome, record

    def test_max_score_and_blank_rating(self):
        status, r = self.score(self.record())
        self.assertEqual(status, "推荐")
        self.assertEqual(r["商品潜力评分"], 85)
        self.assertIsNone(r["图片吸引力评分"])
        self.assertEqual(r["图片得分"], 0)
        _, r = self.score(self.record(), {"图片吸引力评分": 5})
        self.assertEqual(r["商品潜力评分"], 100)
        _, r = self.score(self.record(), {"图片吸引力评分": "5"})
        self.assertEqual(r["图片吸引力评分"], 5)
        self.assertIsInstance(r["图片吸引力评分"], int)

    def test_growth_boundaries(self):
        for value, expected in [(-.01, 0), (0, 5), (.2999, 5), (.3, 10), (.999, 10), (1, 15), (3, 15), (3.001, 20), (None, 0)]:
            with self.subTest(value=value):
                self.assertEqual(growth_points(value), expected)

    def test_grade_boundaries(self):
        for points, level in [(0, "D类"), (49, "D类"), (50, "C类"), (64, "C类"), (65, "B类"), (79, "B类"), (80, "A类"), (100, "A类")]:
            with self.subTest(points=points):
                self.assertEqual(grade(points)[0], level)

    def test_age_boundaries_and_old_filter(self):
        for age, life, points in [(0, "新品", 10), (30, "新品", 10), (31, "成长款", 8), (90, "成长款", 8), (91, "老款", 3)]:
            status, r = self.score(self.record(**{"预估商品上架时间": TODAY - timedelta(days=age)}))
            self.assertEqual((r["商品生命周期"], r["年龄得分"]), (life, points))
            self.assertEqual(status, "删除" if age > 90 else "推荐")
        self.config["max_age_days"] = None
        self.assertEqual(self.score(self.record(**{"预估商品上架时间": TODAY - timedelta(days=100)}))[0], "推荐")

    def test_sales_tiers(self):
        for value, expected in [(0, 2), (29, 2), (30, 5), (99, 5), (100, 10), (299, 10), (300, 15), (999, 15), (1000, 20), (None, 0)]:
            with self.subTest(value=value):
                self.assertEqual(self.score(self.record(**{"销量": value}))[1]["销量得分"], expected)

    def test_keywords_and_conflict(self):
        self.assertFalse(hit("women's leggings", "men"))
        self.assertTrue(hit("quarter-zip workout top", "quarter zip"))
        status, r = self.score(self.record(**{"商品名称": "yoga dress"}))
        self.assertEqual(status, "复查")
        self.assertIn("人工复查", r["人工复查原因"])
        self.assertEqual(self.score(self.record(**{"商品名称": "phone case", "商品分类": "配件"}))[0], "删除")
        self.assertEqual(self.score(self.record(**{"商品名称": "casual dress", "商品分类": "服装", "店铺名": "Yoga Gym"}))[0], "删除")
        self.assertEqual(self.score(self.record(**{"商品名称": "jacket", "商品分类": "外套", "商品售价": "$30"}))[1]["类目得分"], 5)

    def test_missing_review_and_hard_exclusions(self):
        for field in ("销量", "销量环比", "预估商品上架时间", "商品状态", "国家/地区", "FastMoss 商品详情页"):
            with self.subTest(field=field):
                self.assertEqual(self.score(self.record(**{field: None}))[0], "复查")
        for values in ({"销量环比": "0%"}, {"销量环比": "-5%"}, {"商品状态": "下架"}, {"国家/地区": "UK"}):
            self.assertEqual(self.score(self.record(**values))[0], "删除")
        self.assertEqual(self.score(self.record(**{"预估商品上架时间": TODAY + timedelta(days=1)}))[0], "复查")
        self.config["missing_to_review"] = False
        self.assertEqual(self.score(self.record(**{"销量环比": None}))[0], "删除")

    def test_price_ranges_and_currency(self):
        for title, raw, points in [("leggings", "$20-35", 10), ("leggings", "$19.99", 0), ("leggings", "$25-45", 0),
                                    ("workout two-piece set", "$30-50", 10), ("yoga jacket", "$25-45", 10),
                                    ("sports bra", "$25", 0), ("leggings", "€25", 0), ("leggings", None, 0), ("leggings", "-25", 0)]:
            with self.subTest(title=title, raw=raw):
                r = self.record(**{"商品名称": title, "商品分类": "服装", "商品售价": raw})
                self.assertEqual(price_points(r, self.config)[0], points)

    def test_competition_and_brands(self):
        r = self.record()
        r["_competition_count"] = 50
        self.assertEqual(self.score(r)[1]["竞争得分"], 3)
        r = self.record()
        r["_competition_count"] = 20
        self.assertEqual(self.score(r)[1]["竞争得分"], 5)
        status, r = self.score(self.record(**{"店铺名": "Halara US"}))
        self.assertEqual(status, "复查")
        self.assertEqual(r["竞争得分"], 3)
        status, r = self.score(self.record(**{"商品分类": None}))
        self.assertEqual(status, "复查")
        self.assertEqual(r["竞争得分"], 0)
        records = [self.record() for _ in range(60)]
        self.assertEqual(context_for(records, self.keywords)[0]["瑜伽裤"], 1)

    def test_search_terms_examples(self):
        self.assertTrue(search_terms(self.record(), self.keywords).startswith("无缝喇叭瑜伽裤；高腰提臀喇叭裤；普拉提瑜伽裤"))
        result = search_terms(self.record(**{"商品名称": "quarter zip workout top", "商品分类": "上衣"}), self.keywords)
        self.assertEqual(result, "半拉链运动上衣女；瑜伽长袖上衣")

    def test_numeric_parsing(self):
        self.assertEqual(cleaner.parse_number("1.2k"), 1200)
        self.assertEqual(cleaner.parse_number("1.2万"), 12000)
        self.assertEqual(cleaner.parse_percent(5), .05)
        self.assertEqual(cleaner.parse_percent(.5, "0%"), .5)
        self.assertEqual(cleaner.parse_percent("300%"), 3)
        self.assertEqual(cleaner.parse_percent("(5%)"), -.05)
        self.assertIsNone(cleaner.parse_percent("unknown 5"))
        self.assertIsNone(cleaner.parse_number(float("nan")))
        with patch.object(cleaner, "NUMERIC_GROWTH_MODE", "fraction"):
            self.assertEqual(cleaner.parse_percent(.5), .5)

    def test_manual_validation(self):
        for invalid in (0, 6, 1.5, "abc", float("nan"), True):
            with self.subTest(value=invalid), self.assertRaises(ValueError):
                image_points(invalid)
        status, r = self.score(self.record(), {"图片吸引力评分": 7})
        self.assertEqual(status, "复查")
        self.assertEqual(r["图片得分"], 0)

    def test_invalid_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            shutil.copy(SCRIPT.parent / "keywords_config.json", root)
            config = copy.deepcopy(self.config)
            config["sales_tiers"][0]["points"] = 25
            (root / "scoring_config.json").write_text(json.dumps(config))
            with self.assertRaisesRegex(ValueError, "sales_tiers"):
                load_config(root)


class IntegrationTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        for name in ("keywords_config.json", "scoring_config.json"):
            shutil.copy(SCRIPT.parent / name, self.root)
        self.raw = self.root / "01_FastMoss原始表"
        self.raw.mkdir()
        image = io.BytesIO()
        Image.new("RGB", (200, 300), "#008080").save(image, "PNG")
        content = image.getvalue()
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == "/good.png":
                    self.send_response(200)
                    self.send_header("Content-Type", "image/png")
                    self.end_headers()
                    self.wfile.write(content)
                else:
                    self.send_error(404)
            def log_message(self, *args):
                pass
        self.server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.base_url = f"http://127.0.0.1:{self.server.server_port}"
        self.file = self.raw / "fixture.xlsx"
        w = Workbook()
        w.active.title = "封面"
        w.active.append(["报表说明"])
        s = w.create_sheet("商品数据")
        s.append(["FastMoss测试导出"])
        s.append([])
        self.headers = ["商品名称", "商品ID", "商品图片", "店铺名", "商品售价", "国家/地区", "商品分类", "近7天销量", "销量环比", "总销量", "上架时间", "商品链接", "商品状态", "自定义原始列"]
        s.append(self.headers)
        base = ["Women's seamless flare leggings", "P1", self.base_url + "/good.png", "Independent", "$25", "US", "瑜伽裤", 1500, "400%", 2000, TODAY - timedelta(days=10), "https://example.com/P1", "在售", "保留原值"]
        cases = [({}, "P1"), ({7: 100, 8: "50%", 10: TODAY - timedelta(days=45)}, "P2"),
                 ({0: "yoga dress"}, "R1"), ({8: None}, "R2"), ({10: None}, "R3"), ({7: None}, "R4"),
                 ({12: "下架"}, "D1"), ({8: "0%"}, "D2"), ({10: TODAY - timedelta(days=100)}, "D3"),
                 ({0: "phone case", 6: "手机配件"}, "D4"), ({5: "UK"}, "D5"),
                 ({2: self.base_url + "/broken.png"}, "P3")]
        for changes, product_id in cases:
            row = list(base)
            row[1], row[11] = product_id, "https://example.com/" + product_id
            for column, value in changes.items():
                row[column] = value
            s.append(row)
        # P1 uses an embedded image while other products exercise real HTTP downloads.
        s["C4"] = None
        self.embedded = self.root / "embedded.png"
        self.embedded.write_bytes(content)
        s.add_image(XLImage(str(self.embedded)), "C4")
        s["I5"] = .5
        s["I5"].number_format = "0%"
        w.save(self.file)
        w.close()
        self.original_hash = hashlib.sha256(self.file.read_bytes()).hexdigest()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.temp.cleanup()

    def run_cleaner(self, *extra, expected=0):
        env = os.environ.copy()
        env["NO_PROXY"] = "127.0.0.1,localhost"
        result = subprocess.run([sys.executable, str(SCRIPT / "fastmoss_cleaner.py"), "--root", str(self.root), "--as-of", TODAY.isoformat(), *extra], env=env, capture_output=True, text=True, timeout=90)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        return result

    def report(self, data_only=True):
        return load_workbook(self.root / "02_筛选后表格" / "选品报告.xlsx", data_only=data_only)

    @staticmethod
    def records(sheet):
        rows = iter(sheet.values)
        headers = next(rows)
        return [dict(zip(headers, row)) for row in rows if any(v is not None for v in row)]

    def test_end_to_end_and_manual_repeat(self):
        self.run_cleaner()
        w = self.report()
        self.assertEqual(w.sheetnames[:3], ["推荐商品", "待人工复查", "删除记录"])
        kept = self.records(w["推荐商品"])
        review = self.records(w["待人工复查"])
        deleted = self.records(w["删除记录"])
        self.assertEqual([len(kept), len(review), len(deleted)], [3, 4, 5])
        self.assertEqual([r["商品潜力评分"] for r in kept], sorted([r["商品潜力评分"] for r in kept], reverse=True))
        self.assertEqual({r["商品ID"] for r in kept}, {"P1", "P2", "P3"})
        self.assertTrue(all(r["删除原因"] for r in deleted))
        self.assertEqual(w["原始数据_2"]["N4"].value, "保留原值")
        self.assertEqual(len(w["推荐商品"]._images), 2)
        for name in w.sheetnames[:3]:
            self.assertEqual(w[name].freeze_panes, "A2")
            self.assertTrue(w[name].auto_filter.ref)
            self.assertTrue(w[name].data_validations.count >= 3)
            self.assertTrue(len(w[name].conditional_formatting) >= 2)
        link_col = list(w["推荐商品"].values)[0].index("商品链接") + 1
        self.assertTrue(w["推荐商品"].cell(2, link_col).hyperlink.target.startswith("https://"))
        self.assertTrue(any(r["商品图片"] == "图片未获取" for r in kept))
        w.close()
        self.assertEqual(hashlib.sha256(self.file.read_bytes()).hexdigest(), self.original_hash)
        standard = self.root / "cleaned" / "Fastmoss_待搜款清洗表.xlsx"
        w = load_workbook(standard)
        rows = self.records(w.active)
        self.assertEqual(len(rows), 12)
        self.assertTrue(all(r["是否进入搜款"] == "否" for r in rows if r["商品ID"].startswith(("R", "D"))))
        self.assertIn("1688搜索关键词", rows[0])
        headers = [c.value for c in w.active[1]]
        w.active.cell(2, headers.index("搜款状态") + 1, "已裁剪")
        w.active.cell(2, headers.index("主体裁剪图路径") + 1, "images/crop_subject/test.jpg")
        w.save(standard)
        w.close()
        w = self.report(data_only=False)
        s = w["推荐商品"]
        headers = [c.value for c in s[1]]
        self.assertTrue(s.cell(2, headers.index("商品潜力评分") + 1).value.startswith("=MIN"))
        self.assertTrue(s.cell(2, headers.index("图片得分") + 1).value.startswith("=IFERROR"))
        for row in range(2, s.max_row + 1):
            if s.cell(row, headers.index("商品ID") + 1).value == "P2":
                for field, value in (("图片吸引力评分", 5), ("老板审核", "推荐"), ("供应链状态", "已询价"), ("备注", "老板已确认")):
                    s.cell(row, headers.index(field) + 1, value)
        w.save(self.root / "02_筛选后表格" / "选品报告.xlsx")
        w.close()
        self.run_cleaner()
        w = self.report()
        p2 = next(r for r in self.records(w["推荐商品"]) if r["商品ID"] == "P2")
        self.assertEqual([p2[k] for k in ("图片吸引力评分", "图片得分", "老板审核", "供应链状态", "备注")], [5, 15, "推荐", "已询价", "老板已确认"])
        self.assertEqual(p2["商品潜力评分"], p2["自动评分"] + 15)
        w.close()
        w = load_workbook(standard)
        self.assertEqual(self.records(w.active)[0]["搜款状态"], "已裁剪")
        w.close()
        self.assertTrue(list((self.root / "backup").glob("选品报告_*.xlsx")))
        legacy = sorted((self.root / "02_筛选后表格").glob("FastMoss清洗结果_*.xlsx"))[-1]
        w = load_workbook(legacy)
        self.assertEqual(w.sheetnames, ["FastMoss筛选表", "删除记录", "1688同款数据"])
        self.assertEqual(w["1688同款数据"].max_row, 101)
        w.close()

    def test_corrupt_config_preserves_report(self):
        self.run_cleaner("--no-download-images")
        report = self.root / "02_筛选后表格" / "选品报告.xlsx"
        digest = hashlib.sha256(report.read_bytes()).hexdigest()
        (self.root / "keywords_config.json").write_text("not json")
        self.run_cleaner(expected=1)
        self.assertEqual(hashlib.sha256(report.read_bytes()).hexdigest(), digest)

    def test_all_deleted_no_fake_product(self):
        w = load_workbook(self.file)
        for row in range(4, w["商品数据"].max_row + 1):
            w["商品数据"].cell(row, 13, "下架")
        w.save(self.file)
        w.close()
        self.run_cleaner("--no-download-images")
        w = self.report()
        self.assertEqual(self.records(w["推荐商品"]), [])
        self.assertEqual(self.records(w["待人工复查"]), [])
        self.assertEqual(len(self.records(w["删除记录"])), 12)
        w.close()

    def test_no_input_fails_clearly(self):
        self.file.unlink()
        result = self.run_cleaner(expected=1)
        self.assertIn("未找到原始 Excel", result.stdout)

    def test_existing_image_only_entry(self):
        import image_embedder
        out = self.root / "image_only.xlsx"
        w = Workbook()
        s = w.active
        s.append(["商品图片", "商品名称", "额外数据"])
        s.append([self.base_url + "/good.png", "原样保留商品", "  保留空格  "])
        with xlsxwriter.Workbook(str(out)) as target, patch.dict(os.environ, {"NO_PROXY": "127.0.0.1,localhost"}), patch.object(image_embedder, "LOG_FILE", self.root / "image_test.log"):
            converted, failed = image_embedder.copy_sheet(target, s, self.root)
        self.assertEqual((converted, failed), (1, 0))
        with __import__('zipfile').ZipFile(out) as zipped:
            self.assertTrue(any(n.startswith("xl/media/") for n in zipped.namelist()))
        result = load_workbook(out)
        self.assertEqual(result.active["B2"].value, "原样保留商品")
        self.assertEqual(result.active["C2"].value, "  保留空格  ")
        result.close()
        w.close()


class LegacySourcingTest(unittest.TestCase):
    def test_existing_queue_and_manual_result_roundtrip(self):
        # Exercise the original functions without the Windows GUI or any external request.
        spec = importlib.util.spec_from_file_location("runner", SCRIPT / "1688_search_runner.py")
        runner = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(runner)
        import search_prep_tool as prep
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            queue, result, image = runner.create_test_workbooks(root)
            task = runner.load_tasks(queue)[0]
            self.assertEqual(runner.resolve_image_path(task["主体裁剪图路径"], root, queue), image)
            runner.update_task_status(task["任务ID"], "已搜索", queue)
            self.assertEqual(runner.load_tasks(queue)[0]["任务状态"], "已搜索")
            runner.append_manual_result(task, {"1688商品链接": "https://detail.1688.com/offer/123.html", "1688商品标题": "测试瑜伽裤"}, "已搜索", result)
            self.assertTrue(runner.has_duplicate_result_link(task["任务ID"], "https://detail.1688.com/offer/123.html", result))
            self.assertEqual(len(runner.load_saved_results(task["任务ID"], result)), 1)
            self.assertEqual(prep.normalize_header("商品\n标题"), "商品标题")


if __name__ == "__main__":
    unittest.main()
