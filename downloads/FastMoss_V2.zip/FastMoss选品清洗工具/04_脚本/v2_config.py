"""Load independent configuration. Reject invalid settings before touching outputs."""
import json
import math
from pathlib import Path


def load_config(root):
    root = Path(root)
    configs = []
    for name in ("keywords_config.json", "scoring_config.json"):
        try:
            with (root / name).open(encoding="utf-8-sig") as handle:
                configs.append(json.load(handle))
        except (OSError, ValueError) as exc:
            raise ValueError(f"配置文件 {name} 读取失败：{exc}") from exc
    keywords, scoring = configs
    if not isinstance(keywords, dict) or not isinstance(scoring, dict):
        raise ValueError("配置文件的最外层必须是JSON对象")
    for key in ("keep_keywords", "exclude_keywords", "strong_keywords", "brand_risk_keywords"):
        items = keywords.get(key)
        if not isinstance(items, list) or not all(isinstance(x, str) and x.strip() for x in items):
            raise ValueError(f"关键词配置 {key} 必须是非空字符串数组")
    if not keywords["keep_keywords"]:
        raise ValueError("keep_keywords 不能为空")
    for rule in keywords.get("search_rules", []):
        for key in ("all", "terms"):
            if not rule.get(key) or not all(isinstance(x, str) and x.strip() for x in rule[key]):
                raise ValueError("search_rules 的 all/terms 必须是非空字符串数组")
    age = scoring.get("max_age_days")
    if age is not None and (type(age) is not int or age < 0):
        raise ValueError("max_age_days 必须为非负整数或 null")
    if type(scoring.get("missing_to_review")) is not bool:
        raise ValueError("missing_to_review 必须为布尔值")
    if scoring.get("growth_numeric_mode") not in ("percent_points", "fraction"):
        raise ValueError("growth_numeric_mode 必须为 percent_points 或 fraction")
    tiers = scoring.get("sales_tiers", [])
    if not tiers or any(type(t.get("minimum")) is not int or t["minimum"] < 0 or
                        type(t.get("points")) is not int or not 0 <= t["points"] <= 20 for t in tiers):
        raise ValueError("sales_tiers 销量下限必须为非负整数，分数须在 0-20")
    if [t["minimum"] for t in tiers] != sorted({t["minimum"] for t in tiers}, reverse=True) or tiers[-1]["minimum"] != 0:
        raise ValueError("sales_tiers 必须按销量下限严格降序且覆盖 0")
    competition = scoring.get("competition", {})
    for key in ("low_count_max", "high_count_min", "high_keyword_count_min"):
        if type(competition.get(key)) is not int or competition[key] < 0:
            raise ValueError(f"competition.{key} 必须为非负整数")
    if competition["low_count_max"] >= competition["high_count_min"]:
        raise ValueError("竞争低/高阈值必须递增")
    for key, bounds in scoring.get("price_ranges", {}).items():
        if not isinstance(bounds, list) or len(bounds) != 2 or not all(type(x) in (int, float) and math.isfinite(x) for x in bounds) or not 0 <= bounds[0] <= bounds[1]:
            raise ValueError(f"价格区间 {key} 无效")
    if not scoring.get("price_ranges"):
        raise ValueError("price_ranges 不能为空")
    for key in ("review_missing_fields", "us_regions"):
        if not isinstance(scoring.get(key), list) or not all(isinstance(x, str) for x in scoring[key]):
            raise ValueError(f"{key} 必须为字符串数组")
    types = scoring.get("product_type_keywords")
    if not isinstance(types, dict) or not types or any(not isinstance(v, list) or not v or not all(isinstance(x, str) and x for x in v) for v in types.values()):
        raise ValueError("product_type_keywords 必须包含商品类型关键词数组")
    return keywords, scoring
