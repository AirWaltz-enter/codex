@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "PY_CMD=python"
%PY_CMD% --version >nul 2>&1
if errorlevel 1 set "PY_CMD=py -3"

%PY_CMD% --version >nul 2>&1
if errorlevel 1 (
    echo Python 3 was not found. Please install Python 3 and add it to PATH.
    pause
    exit /b 1
)

echo Python detected:
%PY_CMD% --version
%PY_CMD% -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 (
    echo Python 3.10 or newer is required.
    pause
    exit /b 1
)

echo.
echo Checking dependencies...
%PY_CMD% -c "from importlib.metadata import version; from pathlib import Path; pairs=[line.strip().split('==') for line in Path('requirements.txt').read_text().splitlines() if '==' in line]; assert all(version(name)==required for name,required in pairs)" >nul 2>&1
if errorlevel 1 %PY_CMD% -m pip install -r requirements.txt
if errorlevel 1 (
    echo Dependency install failed. Please check Python, pip, or network access.
    pause
    exit /b 1
)

echo.
echo Running FastMoss V3...
%PY_CMD% -u fastmoss_cleaner.py --mode v3 %*
set "EXIT_CODE=%ERRORLEVEL%"

echo.
echo Done. Exit code: %EXIT_CODE%
echo Reports: ..\02_筛选后表格\FastMoss_V3推荐商品.xlsx
echo Review: ..\02_筛选后表格\人工复查.xlsx
if not "%EXIT_CODE%"=="0" echo Error details: error.log in the project root.
pause
exit /b %EXIT_CODE%
