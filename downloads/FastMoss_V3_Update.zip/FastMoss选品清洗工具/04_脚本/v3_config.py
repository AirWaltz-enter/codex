"""V3-only configuration, while preserving the existing data filters and V2 files."""
import json
import math
import re
from pathlib import Path
from urllib.parse import urlparse

from v2_config import load_config

CLASSES = ["A 女士运动外套", "B 女士运动长袖", "C 女士运动套装", "D 女士运动裤"]


def load_v3_config(root):
    legacy_keywords, base = load_config(root)
    values = []
    for filename in ("keywords_v3.json", "scoring_v3.json"):
        try:
            value = json.loads((Path(root) / filename).read_text(encoding="utf-8-sig"))
        except (OSError, ValueError) as exc:
            raise ValueError(f"V3配置 {filename} 读取失败：{exc}") from exc
        if not isinstance(value, dict):
            raise ValueError(f"{filename} 最外层必须是JSON对象")
        values.append(value)
    keywords, settings = values
    def word_list(value, name):
        if not isinstance(value, list) or not value or not all(isinstance(x, str) and x.strip() for x in value):
            raise ValueError(f"{name} 必须是非空字符串数组")
    for key in ("keep_keywords", "exclude_keywords", "female_keywords", "male_keywords", "children_keywords", "unisex_keywords", "hard_exclude_keywords", "sport_keywords"):
        word_list(keywords.get(key), key)
    for key in ("class_keywords", "search_terms"):
        mapping = keywords.get(key)
        if not isinstance(mapping, dict) or set(mapping) != set(CLASSES):
            raise ValueError(f"{key} 必须配置四个目标分类")
        for kind, words in mapping.items():
            word_list(words, f"{key}.{kind}")
    if type(settings.get("require_image_review")) is not bool:
        raise ValueError("require_image_review 必须为布尔值")
    if type(settings.get("min_sales_for_recommend")) is not int or settings["min_sales_for_recommend"] < 0:
        raise ValueError("min_sales_for_recommend 必须为非负整数")
    for name, cap, integers in (("sales_tiers", 30, True), ("creator_tiers", 15, True), ("keyword_trend_tiers", 10, False)):
        tiers = settings.get(name)
        if not isinstance(tiers, list) or not tiers:
            raise ValueError(f"{name} 不能为空")
        for tier in tiers:
            if not isinstance(tier, dict):
                raise ValueError(f"{name} 每一档必须是对象")
            minimum, points = tier.get("minimum"), tier.get("points")
            if type(minimum) not in (int, float) or not math.isfinite(minimum) or minimum < 0 or (integers and type(minimum) is not int):
                raise ValueError(f"{name} 下限无效")
            if type(points) is not int or not 0 <= points <= cap:
                raise ValueError(f"{name} 分数须在0-{cap}")
        minima = [t["minimum"] for t in tiers]
        if minima != sorted(set(minima), reverse=True) or minima[-1] != 0:
            raise ValueError(f"{name} 下限须严格降序且覆盖0")
    prices = settings.get("price_ranges")
    if not isinstance(prices, dict) or set(prices) != {"运动外套", "运动长袖", "运动套装", "运动裤"}:
        raise ValueError("price_ranges 必须配置四类商品")
    for kind, bounds in prices.items():
        if not isinstance(bounds, list) or len(bounds) != 2 or not all(type(x) in (int, float) and math.isfinite(x) for x in bounds) or not 0 < bounds[0] <= bounds[1]:
            raise ValueError(f"价格区间 {kind} 无效")
    vision = settings.get("vision")
    if not isinstance(vision, dict) or type(vision.get("enabled")) is not bool:
        raise ValueError("vision.enabled 必须为布尔值")
    for key, maximum in (("confidence_threshold", 1), ("timeout_seconds", 120), ("max_image_bytes", 10000000)):
        value = vision.get(key)
        if type(value) not in (int, float) or not math.isfinite(value) or not 0 < value <= maximum:
            raise ValueError(f"vision.{key} 无效")
    if type(vision["max_image_bytes"]) is not int:
        raise ValueError("vision.max_image_bytes 必须为整数")
    if vision["enabled"]:
        endpoint = urlparse(str(vision.get("endpoint", "")))
        if endpoint.scheme != "https" or not endpoint.hostname or endpoint.username or endpoint.password:
            raise ValueError("vision.endpoint 必须是无内嵌凭据的HTTPS地址")
        if not isinstance(vision.get("model"), str) or not vision["model"].strip():
            raise ValueError("启用图片AI前须配置vision.model")
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", str(vision.get("api_key_env", ""))):
            raise ValueError("vision.api_key_env 必须是环境变量名称")
    base["price_ranges"] = prices
    base["v3"] = settings
    base["v3_brand_keywords"] = legacy_keywords["brand_risk_keywords"]
    return keywords, base
