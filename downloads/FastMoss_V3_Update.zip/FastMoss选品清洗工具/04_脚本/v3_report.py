"""V3 views reuse the existing Excel renderer, audit keys and atomic backups."""
import hashlib
import json
import os
from collections import Counter
from datetime import datetime
from pathlib import Path

import xlsxwriter

from selection_report import REPORT_HEADERS, ReportWriter, backup_file, load_manual_states
from v3_selection import IMAGE_CLASSES, IMAGE_STATES, V3_EXTRA_HEADERS, V3_MANUAL_FIELDS, V3_STATE_FIELDS

V3_PRIMARY_HEADERS = ["商品图片", "商品名称", "商品链接", "类目", "7天销量", "7天销售额", "增长率", "达人数量", "评分", "等级", "生命周期", "1688搜索词", "审核状态", "供应链状态", "备注"]
V3_HEADERS = V3_PRIMARY_HEADERS + [h for h in ["自动分类", "潜力评分", "图片判断", "图片判断置信度", "图片审核状态", "推荐动作"] + V3_EXTRA_HEADERS + REPORT_HEADERS if h not in V3_PRIMARY_HEADERS and h != "老板审核"]
V3_HEADERS = list(dict.fromkeys(V3_HEADERS))
OUTPUT_NAMES = [("FastMoss_V3推荐商品.xlsx", "推荐商品"), ("人工复查.xlsx", "待人工复查"), ("删除记录.xlsx", "删除记录")]


def load_v3_manual_states(output_dir):
    output_dir = Path(output_dir)
    reports = [output_dir / name for name, _ in OUTPUT_NAMES]
    existing = [p for p in reports if p.exists()]
    if not existing:
        # One-time migration from the V2.1 master report; leave the original intact.
        return load_manual_states(output_dir / "选品报告.xlsx", fields=V3_STATE_FIELDS)
    if len(existing) != len(reports):
        raise ValueError("V3三份审核报告不完整，请恢复缺失文件或将三份一起备份移走，避免丢失旧审核")
    states = {}
    for report in existing:
        for key, state in load_manual_states(report, fields=V3_STATE_FIELDS, aliases={"老板审核": "审核状态"}).items():
            if key in states and states[key] != state:
                raise ValueError(f"V3报告存在重复商品审核冲突：{key}，请统一审核后重跑")
            states[key] = state
    return states


class V3Writer(ReportWriter):
    def __init__(self, workbook):
        super().__init__(workbook)
        self.manual_fields = V3_MANUAL_FIELDS + ["审核状态"]

    def additional_data(self, record):
        return {"类目": record.get("商品分类"), "7天销量": None if record.get("_sales_missing") or not record.get("_sales_period_confirmed") else record.get("_sales"),
                "增长率": record.get("_growth"), "评分": record["潜力评分"], "等级": record["商品等级"],
                "生命周期": record["商品生命周期"], "1688搜索词": record["1688搜索关键词"], "审核状态": record["老板审核"]}

    def formulas(self, sheet, row, data, columns):
        # V3's six components already total 100; V2 image attractiveness adds no points.
        # Keep the field for the old workflow, but never reuse V2's 85+15 formula.
        return

    def validation_rules(self):
        return [("审核状态", ["待审核", "推荐", "放弃"]), ("供应链状态", ["未找货", "已找到1688", "已询价", "待测试"]),
                ("图片审核状态", IMAGE_STATES), ("图片判断", IMAGE_CLASSES)]


def save_v3_reports(output_dir, kept, review, deleted, source_file, source_wb, source_ws, today, keywords, config, backup_dir, logger):
    """Stage all views before replacement, with rollback if any replacement fails."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    paths = [output_dir / name for name, _ in OUTPUT_NAMES]
    temporary = [p.with_name(f".{p.stem}_{stamp}.tmp.xlsx") for p in paths]
    originals = {p: backup_file(p, backup_dir) for p in paths}
    replaced = []
    summary = f"推荐 {len(kept)}；待人工复查 {len(review)}；删除 {len(deleted)}；总计 {len(kept)+len(review)+len(deleted)}"
    groups = [sorted(kept, key=lambda r: (r["潜力评分"], r.get("_sales", 0)), reverse=True),
              sorted(review, key=lambda r: (r["潜力评分"], r.get("_sales", 0)), reverse=True), [x["record"] for x in deleted]]
    try:
        for index, (temp, (_, sheet_name), rows) in enumerate(zip(temporary, OUTPUT_NAMES, groups), 1):
            logger.progress("生成报告", index-1, 3, sheet_name)
            with xlsxwriter.Workbook(str(temp), {"strings_to_urls": False, "strings_to_formulas": False}) as workbook:
                writer = V3Writer(workbook)
                writer.write_products(workbook.add_worksheet(sheet_name), rows, Path(source_file), source_ws,
                                      reasons=True if sheet_name == "删除记录" else None, headers=V3_HEADERS)
                notes = workbook.add_worksheet("运行说明")
                notes.freeze_panes(1, 0)
                notes.write_row(0, 0, ["项目", "内容"], writer.header)
                reasons = Counter(reason for item in deleted for reason in item["record"]["_delete_reasons"])
                values = [("版本", "FastMoss女士运动服饰选品系统 V3 快速选品版"), ("数量", summary),
                    ("评估日期", today.isoformat()), ("原始文件", str(source_file)),
                    ("输入SHA256", hashlib.sha256(Path(source_file).read_bytes()).hexdigest()),
                    ("查看路径", "推荐候选见FastMoss_V3推荐商品.xlsx；待审核/数据不足见人工复查.xlsx；被排除原因见删除记录.xlsx"),
                    ("审核入口", "仅编辑这三份V3报告的蓝色列；审核状态=老板审核，图片审核状态为独立字段；保存并关闭三份Excel后重跑"),
                    ("图片门槛", f"require_image_review={config['v3']['require_image_review']}；图片AI只辅助，不自动完成人工确认，不能绕过文字硬排除"),
                    ("AI启用", str(config["v3"]["vision"]["enabled"]) + "；未启用/失败时不虚构判断和置信度；置信度是模型自报值，不是实际准确率"),
                    ("分数", "销量30+增长20+达人15+类目15+价格10+关键词趋势10；图片吸引力不参与V3分数"),
                    ("趋势依据", "仅使用原表数值关键词增长率；不以标题热词、样本词频或商品销量增长代替搜索趋势"),
                    ("销量周期", "仅明确7天销量可自动推荐；周期不明进入复查；7天销售额缺失留空"),
                    ("原始数据", "原文件不修改；推荐报告附所有工作表单元格副本，原格式与嵌入图以输入文件为准"),
                    ("删除原因计数", json.dumps(reasons, ensure_ascii=False)),
                    ("关键词配置", json.dumps(keywords, ensure_ascii=False)), ("评分配置", json.dumps(config, ensure_ascii=False))]
                for row, pair in enumerate(values, 1):
                    notes.write_row(row, 0, pair, writer.body)
                    notes.set_row(row, 55)
                notes.set_column(0, 0, 22)
                notes.set_column(1, 1, 110)
                notes.autofilter(0, 0, len(values), 1)
                if index == 1:
                    writer.write_raw(source_wb)
            logger.progress("生成报告", index, 3, sheet_name)
        for temp, path in zip(temporary, paths):
            os.replace(temp, path)
            replaced.append(path)
    except Exception:
        import shutil
        for path in reversed(replaced):
            if originals[path]:
                shutil.copy2(originals[path], path)
            else:
                path.unlink(missing_ok=True)
        raise
    finally:
        for temp in temporary:
            temp.unlink(missing_ok=True)
    # Human-readable summary is always useful, especially when recommendations are empty.
    (output_dir / "V3运行汇总.txt").write_text(summary + "\n推荐表为空不等于读取失败。先看人工复查.xlsx，再看删除记录.xlsx。\n", encoding="utf-8")
    logger.write("V3报告已生成：" + summary)
    return paths
