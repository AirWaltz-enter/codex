"""Four-class selection and 100-point scoring. Never infer trends from buzzwords."""
import hashlib
import re

from potential_scoring import data_filter_reasons, grade, growth_points, hit, image_points, price_points, record_key, text
from target_selection import audit_fingerprint
from v3_config import CLASSES

IMAGE_CLASSES = ["女士运动外套", "女士运动长袖", "女士运动裤", "女士运动套装", "普通服饰", "无法确认"]
IMAGE_STATES = ["待审核", "确认运动服饰", "非目标", "无法确认"]
V3_MANUAL_FIELDS = ["图片吸引力评分", "老板审核", "供应链状态", "备注", "图片判断", "图片审核状态"]
V3_STATE_FIELDS = V3_MANUAL_FIELDS + ["图片审核指纹", "图片款式审核", "图片判断来源"]
V3_EXTRA_HEADERS = ["自动分类", "潜力评分", "达人数量", "7天销售额", "销量周期依据", "关键词趋势", "关键词趋势依据", "达人得分", "关键词趋势得分", "图片判断", "图片判断置信度", "图片审核状态", "图片判断来源", "图片辅助说明"]
PRICE_KIND = dict(zip(CLASSES, ["运动外套", "运动长袖", "运动套装", "运动裤"]))


def fingerprint(record):
    # Keep existing V2.1 approvals when source is identical; new tags invalidate them.
    legacy = audit_fingerprint(record)
    tags = text(record.get("商品标签"))
    return hashlib.sha256((legacy + "\x1f" + tags).encode()).hexdigest() if tags else legacy


def classify(record, keywords):
    """Titles identify the garment; categories/tags corroborate rather than hide conflicts."""
    title = text(record.get("商品名称"))
    other = " ".join(text(record.get(k)) for k in ("商品分类", "商品标签"))
    def types(content):
        found = [kind for kind, words in keywords["class_keywords"].items() if any(hit(content, word) for word in words)]
        # A jacket can have long sleeves; coordinated sets naturally mention pants.
        if CLASSES[2] in found:
            return [CLASSES[2]]
        if CLASSES[0] in found and CLASSES[1] in found:
            found.remove(CLASSES[1])
        return found
    title_types, other_types = types(title), types(other)
    chosen = title_types or other_types
    kind = chosen[0] if len(chosen) == 1 else "E 其他"
    conflicts = len(chosen) > 1 or bool(title_types and other_types and set(title_types) != set(other_types))
    if kind == CLASSES[2] and (not other_types or all(x in (CLASSES[0], CLASSES[1], CLASSES[2], CLASSES[3]) for x in other_types)):
        # A two-piece workout set may legitimately be catalogued under its pants/top.
        conflicts = len(title_types) > 1
    return kind, conflicts, title_types, other_types


def search_terms_v3(record, kind, keywords):
    title = text(record.get("商品名称"))
    if kind == CLASSES[0] and hit(title, "quarter zip"):
        return "女款半拉链运动外套；跑步防风外套；瑜伽训练外套"
    if kind == CLASSES[3] and hit(title, "flare"):
        return "无缝喇叭瑜伽裤；高腰提臀喇叭裤"
    terms = list(keywords["search_terms"].get(kind, ["女士运动服饰（款式待确认）"]))
    if kind == CLASSES[1] and hit(title, "quarter zip"):
        terms.insert(0, "半拉链运动长袖女")
    return "；".join(dict.fromkeys(terms))


def image_state(record, manual):
    current = fingerprint(record)
    state = manual.get("图片审核状态")
    judgment = manual.get("图片判断")
    notes = []
    if state is None:
        old = manual.get("图片款式审核")
        state = {"确认女士运动外套": "确认运动服饰", "男款": "非目标", "卫衣": "非目标", "无法确认": "无法确认"}.get(old, "待审核")
        if old == "确认女士运动外套":
            judgment = "女士运动外套"
        elif old == "非运动外套":
            notes.append("旧非运动外套审核不等于V3非目标，需按四类重新核验")
    if state not in IMAGE_STATES:
        state = "待审核"
        notes.append("图片审核状态无效，已重置待审核")
    if judgment not in IMAGE_CLASSES:
        judgment = "无法确认"
    if state == "待审核" and text(manual.get("图片判断来源")).startswith("AI辅助"):
        judgment = "无法确认"  # Re-evaluate cached AI advice after the current text/image pass.
    if (state != "待审核" or judgment != "无法确认") and manual.get("图片审核指纹") != current:
        state, judgment = "待审核", "无法确认"
        notes.append("标题、类目、标签或图片来源变化，旧图片审核失效")
    return state, judgment, current, notes


def score_record_v3(record, today, keywords, config, manual=None):
    manual = manual or {}
    hard, review, age = data_filter_reasons(record, today, config)
    settings = config["v3"]
    content = " ".join(text(record.get(k)) for k in ("商品名称", "商品分类", "商品标签"))
    found = lambda name: [word for word in keywords[name] if hit(content, word)]
    female, male = found("female_keywords"), found("male_keywords")
    if re.search(r"(?:^|[\s/＞>\-（(])女(?:$|[\s/＞>\-）)])", content):
        female.append("女类目标注")
    if re.search(r"(?:^|[\s/＞>\-（(])男(?:$|[\s/＞>\-）)])", content):
        male.append("男类目标注")
    for label, words in (("明确男款", male), ("儿童款", found("children_keywords")), ("男女同款/中性款", found("unisex_keywords")), ("非目标款式", found("hard_exclude_keywords"))):
        if words:
            hard.append(f"文字硬排除：{label}（{'、'.join(words)}）")
    kind, conflict, title_types, other_types = classify(record, keywords)
    sport = found("sport_keywords")
    keep, exclude = found("keep_keywords"), found("exclude_keywords")
    state, judgment, signature, image_notes = image_state(record, manual)
    review.extend(image_notes)
    confirmed = state == "确认运动服饰"
    if state == "非目标":
        hard.append("图片人工审核：非目标")
    if not sport:
        # Seamless, quarter zip and outerwear alone do not prove athletic use.
        hard.append("缺少运动用途证据，不能把普通女装当作运动服饰")
    if kind == "E 其他":
        if sport:
            review.append("运动方向但无法归入四个目标分类")
        else:
            hard.append("不属于四个目标分类")
    if conflict:
        review.append("标题、类目或标签存在品类冲突，需核对真实商品")
    if not female:
        review.append("缺少明确女款标注")
    if not keep:
        hard.append("未命中V3保留关键词")
    elif exclude:
        review.append("保留词与排除词同时命中；明确文字硬排除仍优先")
    if not record.get("_sales_period_confirmed", False):
        review.append("销量列周期未明确为近7天，请核对原表；不以总销量替代")
    if not record.get("_sales_missing") and record.get("_sales", 0) < settings["min_sales_for_recommend"]:
        review.append(f"近7天销量低于推荐需求门槛{settings['min_sales_for_recommend']}，需观察验证")
    creators = record.get("_creator_count")
    if creators is None:
        review.append("达人数量缺失或无效，达人项计0")
    trend = record.get("_keyword_trend")
    if trend is None:
        review.append("缺少数值关键词增长率；不把热词命中或商品销量增长冒充关键词趋势")
    if record.get("_sales_amount") is None:
        record.setdefault("_notes", []).append("7天销售额缺失/周期不明/无效，留空；不以价格乘销量推算")
    if confirmed and kind in CLASSES and judgment not in ("无法确认", kind.split(" ", 1)[1]):
        review.append("人工图片判断与文字分类不同，需解决图文冲突")
    if confirmed and judgment == "普通服饰":
        review.append("图片判断为普通服饰，不能同时确认运动服饰")
    if confirmed and judgment == "无法确认":
        review.append("已确认运动服饰但图片分类仍无法确认，请填写具体图片判断")
    if judgment == "普通服饰" and not confirmed:
        review.append("图片判断为普通服饰，需核验是否非目标")
    if state == "无法确认":
        review.append("图片款式无法确认")
    if settings["require_image_review"] and not confirmed:
        review.append("图片未确认运动服饰，请在人工复查表审核后重跑")
    if not record.get("_image_url") and not record.get("_image_signature"):
        review.append("缺少图片来源，无法核验商品款式")
    def tier_points(value, tiers):
        return 0 if value is None or value < 0 else next(t["points"] for t in tiers if value >= t["minimum"])
    record["_price_kind"] = PRICE_KIND.get(kind)
    price, price_basis, price_unknown = price_points(record, config)
    if price_unknown:
        review.append(price_basis)
    brands = [word for word in config["v3_brand_keywords"] if hit(content + " " + text(record.get("品牌")) + " " + text(record.get("店铺名")), word)]
    if brands:
        review.append("品牌风险待核实：" + "、".join(brands))
    parts = {
        "销量得分": 0 if record.get("_sales_missing") else tier_points(record.get("_sales"), settings["sales_tiers"]),
        "增长得分": growth_points(record.get("_growth")),
        "达人得分": tier_points(creators, settings["creator_tiers"]),
        "类目得分": 15 if kind in CLASSES and sport and not conflict else 5 if kind in CLASSES and sport else 0,
        "价格得分": price,
        "关键词趋势得分": tier_points(trend, settings["keyword_trend_tiers"]),
    }
    total = sum(parts.values())
    level, action = grade(total)
    if level == "B类":
        action = "测试"
    boss, supply = manual.get("老板审核") or "待审核", manual.get("供应链状态") or "未找货"
    if boss not in ("待审核", "推荐", "放弃"):
        boss = "待审核"
        review.append("老板审核无效，重置待审核")
    if supply not in ("未找货", "已找到1688", "已询价", "待测试"):
        supply = "未找货"
        review.append("供应链状态无效，重置未找货")
    rating = manual.get("图片吸引力评分")
    try:
        picture = image_points(rating)
        rating = picture // 3 if picture else None
    except ValueError as exc:
        rating, picture = None, 0
        review.append(str(exc))
    if not config["missing_to_review"]:
        hard.extend(r for r in review if r.startswith(("上架时间", "销量环比", "近7天销量缺失")))
    record.update(parts)
    record.update({
        "自动分类": kind, "目标分类": kind, "服装类型判定": kind,
        "适用人群判定": "女款明示" if female else "未明确女款",
        "目标匹配依据": f"标题分类={'、'.join(title_types) or '无'}；类目/标签分类={'、'.join(other_types) or '无'}；运动词={'、'.join(sport) or '无'}",
        "潜力评分": total, "商品潜力评分": total, "自动评分": total,
        "商品等级": level, "推荐动作": action,
        "商品年龄(天)": age,
        "商品生命周期": "待核对" if age is None or age < 0 else "新品" if age <= 30 else "成长款" if age <= 90 else "老款",
        "达人数量": creators, "7天销售额": record.get("_sales_amount"),
        "销量周期依据": record.get("_sales_period_basis", "未明确"),
        "关键词趋势": trend, "关键词趋势依据": "原表关键词增长率（单位按百分比列/配置解析）" if trend is not None else "原表缺失或无效；未获取外部搜索趋势",
        "关键词匹配": "、".join(keep), "排除词命中": "、".join(exclude),
        "1688搜索关键词": search_terms_v3(record, kind, keywords),
        "图片判断": judgment, "图片判断置信度": None,
        "图片判断来源": "人工审核" if state != "待审核" else "未分析",
        "图片审核状态": state, "图片审核指纹": signature,
        "图片辅助说明": "图片AI未启用或尚未分析；人工判断不伪造AI置信度",
        "图片吸引力评分": rating, "图片得分": picture,
        "老板审核": boss, "供应链状态": supply, "备注": manual.get("备注", ""),
        "价格判断依据": price_basis, "人工复查原因": "；".join(dict.fromkeys(review)),
        "_delete_reasons": list(dict.fromkeys(hard)), "_target_enabled": True,
        "_target_has_outerwear": kind == CLASSES[0], "_record_key": record_key(record),
    })
    if manual.get("备注"):
        record.setdefault("_notes", []).append(text(manual["备注"]))
    return "删除" if hard else "复查" if review else "推荐"
