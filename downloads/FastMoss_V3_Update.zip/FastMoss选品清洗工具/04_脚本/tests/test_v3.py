import copy
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from datetime import timedelta
from unittest.mock import Mock, patch
import zipfile

from openpyxl import Workbook, load_workbook
from openpyxl.drawing.image import Image as XLImage
from PIL import Image

SCRIPT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPT))
import fastmoss_cleaner as cleaner
import test_v2 as legacy
from image_assistance import VisionAssistant, apply_image_assistance, validate_result
from v3_config import CLASSES, load_v3_config
from v3_report import load_v3_manual_states, save_v3_reports
from v3_selection import fingerprint, score_record_v3

TODAY = legacy.TODAY


class V3RulesTest(unittest.TestCase):
    def setUp(self):
        self.keywords, self.config = load_v3_config(SCRIPT.parent)

    def record(self, **values):
        record = {"商品名称": "Women's running hooded jacket", "商品分类": "女士运动外套", "商品标签": "training",
                  "商品ID": "V1", "店铺名": "Independent", "商品售价": "$35", "国家/地区": "US", "商品状态": "在售",
                  "销量": 1500, "销量环比": "400%", "预估商品上架时间": TODAY - timedelta(days=10),
                  "FastMoss 商品详情页": "https://example.com/V1", "_image_url": "https://example.com/V1.png"}
        record.update(values)
        cleaner.prepare_record(record, None)
        record.update({"_sales_period_confirmed": True, "_sales_period_basis": "近7天销量", "_creator_count": 50,
                       "_keyword_trend": .4, "_sales_amount": 52500})
        return record

    def score(self, record, state="确认运动服饰", judgment=None, old_signature=None):
        from v3_selection import classify
        kind = classify(record, self.keywords)[0]
        manual = {"图片审核状态": state, "图片判断": judgment or (kind.split(' ', 1)[1] if kind in CLASSES else "无法确认"),
                  "图片审核指纹": old_signature or fingerprint(record)}
        outcome = score_record_v3(record, TODAY, self.keywords, self.config, manual)
        return outcome, record

    def test_four_target_classes(self):
        for title, category, price, expected in [
            ("Women's hooded sports jacket", "女士运动外套", "$35", CLASSES[0]),
            ("Women's quarter zip workout long sleeve top", "女士运动长袖", "$25", CLASSES[1]),
            ("Women's yoga two piece long sleeve leggings set", "女士运动套装", "$40", CLASSES[2]),
            ("Women's seamless flare yoga leggings", "女士运动裤", "$25", CLASSES[3])]:
            with self.subTest(title=title):
                outcome, record = self.score(self.record(**{"商品名称": title, "商品分类": category, "商品售价": price}))
                self.assertEqual(outcome, "推荐", record["人工复查原因"])
                self.assertEqual(record["自动分类"], expected)
                self.assertEqual(record["潜力评分"], 100)

    def test_hard_exclusions_override_high_score_and_manual(self):
        titles = ["Men's workout jacket", "MALE yoga jacket", "Man running jacket", "Boy sports jacket", "Kids yoga jacket",
                  "Child running jacket", "Baby sports jacket", "Women's sports hoodie jacket", "Women's workout sweatshirt",
                  "Women's yoga dress", "Women's gym swimsuit", "Women's sports bikini", "Women's fitness lingerie",
                  "Women's yoga bra", "Women's workout sleepwear", "Women's sports blazer", "Women's workout fashion coat"]
        for title in titles:
            with self.subTest(title=title):
                outcome, record = self.score(self.record(**{"商品名称": title}), judgment="女士运动外套")
                self.assertEqual(outcome, "删除")
                self.assertTrue(any("硬排除" in reason for reason in record["_delete_reasons"]))

    def test_english_boundaries_and_hooded_exception(self):
        self.assertEqual(self.score(self.record(**{"商品名称": "Women’s hooded sports jacket"}))[0], "推荐")
        self.assertEqual(self.score(self.record(**{"商品名称": "Women's running jacket for mankind"}))[0], "推荐")

    def test_regular_coat_keyword_conflict_goes_to_review(self):
        status, record = self.score(self.record(**{"商品名称": "Women's yoga training coat"}))
        self.assertEqual(status, "复查")
        self.assertFalse(record["_delete_reasons"])
        self.assertIn("同时命中", record["人工复查原因"])

    def test_no_ordinary_fashion_even_with_generic_keep(self):
        for title in ("Women's seamless long sleeve top", "Women's quarter zip jacket", "Women's outerwear jacket"):
            with self.subTest(title=title):
                status, record = self.score(self.record(**{"商品名称": title, "商品分类": "女装", "商品标签": None}))
                self.assertEqual(status, "删除")
                self.assertIn("运动用途", "；".join(record["_delete_reasons"]))

    def test_tags_supply_evidence_and_are_audited(self):
        record = self.record(**{"商品名称": "Women's long sleeve top", "商品分类": "女装", "商品标签": "yoga workout"})
        self.assertEqual(self.score(record)[0], "推荐")
        original = fingerprint(record)
        record["商品标签"] = "running"
        status, record = self.score(record, old_signature=original)
        self.assertEqual(status, "复查")
        self.assertEqual(record["图片审核状态"], "待审核")

    def test_unknown_audience_and_conflicting_types(self):
        for values in ({"商品名称": "Running jacket", "商品分类": "运动外套"}, {"商品分类": "女士运动裤"}):
            status, _ = self.score(self.record(**values), judgment="女士运动外套")
            self.assertEqual(status, "复查")

    def test_seven_day_period_not_inferred(self):
        record = self.record()
        record["_sales_period_confirmed"] = False
        status, record = self.score(record)
        self.assertEqual(status, "复查")
        self.assertIn("周期", record["人工复查原因"])

    def test_missing_creators_or_trend(self):
        for field in ("_creator_count", "_keyword_trend"):
            record = self.record()
            record[field] = None
            status, record = self.score(record)
            self.assertEqual(status, "复查")
            self.assertEqual(record["达人得分" if field == "_creator_count" else "关键词趋势得分"], 0)

    def test_sales_and_creator_tiers(self):
        for sales, points in [(0, 0), (1, 3), (29, 3), (30, 8), (99, 8), (100, 15), (300, 22), (1000, 30)]:
            record = self.record(**{"销量": sales})
            status, record = self.score(record)
            self.assertEqual(record["销量得分"], points)
            if sales < 30:
                self.assertEqual(status, "复查")
        for count, points in [(0, 0), (4, 0), (5, 5), (19, 5), (20, 10), (49, 10), (50, 15)]:
            record = self.record()
            record["_creator_count"] = count
            self.assertEqual(self.score(record)[1]["达人得分"], points)

    def test_keyword_trend_points_are_not_sales_growth(self):
        for trend, points in [(-.01, 0), (0, 2), (.099, 2), (.1, 5), (.299, 5), (.3, 10)]:
            record = self.record()
            record["_keyword_trend"] = trend
            self.assertEqual(self.score(record)[1]["关键词趋势得分"], points)

    def test_lifecycle_and_original_hard_filters(self):
        for days, lifecycle in [(0, "新品"), (30, "新品"), (31, "成长款"), (90, "成长款"), (91, "老款")]:
            status, record = self.score(self.record(**{"预估商品上架时间": TODAY-timedelta(days=days)}))
            self.assertEqual(record["商品生命周期"], lifecycle)
            self.assertEqual(status, "删除" if days > 90 else "推荐")
        for values in ({"销量环比": "0%"}, {"销量环比": "-5%"}, {"商品状态": "下架"}, {"国家/地区": "UK"}):
            self.assertEqual(self.score(self.record(**values))[0], "删除")

    def test_chinese_search_examples(self):
        result = self.score(self.record(**{"商品名称": "Women's Quarter Zip Running Jacket"}))[1]
        self.assertEqual(result["1688搜索关键词"], "女款半拉链运动外套；跑步防风外套；瑜伽训练外套")
        result = self.score(self.record(**{"商品名称": "Women's Flare Yoga Leggings", "商品分类": "女士运动裤", "商品售价": "$25"}))[1]
        self.assertEqual(result["1688搜索关键词"], "无缝喇叭瑜伽裤；高腰提臀喇叭裤")

    def test_image_manual_rejection_and_invalidated_confirmation(self):
        self.assertEqual(self.score(self.record(), state="非目标")[0], "删除")
        self.assertEqual(self.score(self.record(), state="待审核")[0], "复查")
        self.assertEqual(self.score(self.record(), judgment="女士运动裤")[0], "复查")
        self.assertEqual(self.score(self.record(), judgment="无法确认")[0], "复查")
        self.assertEqual(self.score(self.record(), old_signature="stale")[0], "复查")

    def test_legacy_confirmation_migration_and_non_outerwear_scope(self):
        record = self.record(**{"商品标签": None})
        outcome = score_record_v3(record, TODAY, self.keywords, self.config, {"图片款式审核": "确认女士运动外套", "图片审核指纹": fingerprint(record)})
        self.assertEqual(outcome, "推荐")
        record = self.record(**{"商品名称": "Women's yoga pants", "商品分类": "女士运动裤", "商品售价": "$25"})
        outcome = score_record_v3(record, TODAY, self.keywords, self.config, {"图片款式审核": "非运动外套", "图片审核指纹": fingerprint(record)})
        self.assertEqual(outcome, "复查")
        self.assertFalse(record["_delete_reasons"])

    def test_no_image_bonus_in_v3_score(self):
        record = self.record()
        manual = {"图片吸引力评分": 5, "图片审核状态": "确认运动服饰", "图片判断": "女士运动外套", "图片审核指纹": fingerprint(record)}
        score_record_v3(record, TODAY, self.keywords, self.config, manual)
        self.assertEqual(record["潜力评分"], 100)
        self.assertEqual(record["图片得分"], 15)

    def test_invalid_v3_config_fails_closed(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for name in ("keywords_config.json", "scoring_config.json", "target_config.json", "keywords_v3.json", "scoring_v3.json"):
                shutil.copy(SCRIPT.parent/name, root)
            settings = json.loads((root/'scoring_v3.json').read_text())
            settings['sales_tiers'][0]['points'] = 31
            (root/'scoring_v3.json').write_text(json.dumps(settings))
            with self.assertRaisesRegex(ValueError, 'sales_tiers'):
                load_v3_config(root)

    def test_explicit_seven_day_column_preferred_and_invalid_counts_rejected(self):
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(['商品名称', '销量', '近7日销量', '上架时间', '达人数量', '关键词增长率'])
        sheet.append(["Women's running jacket", 999999, 1200, TODAY, True, True])
        header, columns = cleaner.find_header_row(sheet)
        self.assertEqual(columns['销量'], 3)
        record = cleaner.prepare_record(cleaner.build_record(sheet, 2, columns), None)
        cleaner.prepare_v3_fields(record, sheet, header, columns)
        self.assertEqual(record['_sales'], 1200)
        self.assertTrue(record['_sales_period_confirmed'])
        self.assertIsNone(record['_creator_count'])
        self.assertIsNone(record['_keyword_trend'])
        workbook.close()

    def test_stale_unconfirmed_ai_advice_does_not_become_text_rule(self):
        record = self.record()
        manual = {'图片审核状态': '待审核', '图片判断': '普通服饰', '图片判断来源': 'AI辅助（未人工确认）', '图片审核指纹': fingerprint(record)}
        score_record_v3(record, TODAY, self.keywords, self.config, manual)
        self.assertEqual(record['图片判断'], '无法确认')
        self.assertNotIn('图片判断为普通服饰', record['人工复查原因'])


class VisionInterfaceTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.image = self.root/'photo.png'
        Image.new('RGB', (180, 300), 'teal').save(self.image)
        _, config = load_v3_config(SCRIPT.parent)
        self.config = copy.deepcopy(config['v3']['vision'])
        self.config.update({'enabled': True, 'model': 'test-vision'})

    def tearDown(self):
        self.temp.cleanup()

    def test_disabled_never_calls_api_or_fakes_result(self):
        self.config['enabled'] = False
        with patch('image_assistance.requests.post') as call:
            self.assertIsNone(VisionAssistant(self.config, self.root/'cache').analyze(self.image))
            call.assert_not_called()

    def test_api_contract_cache_and_kept_manual_state(self):
        response = Mock()
        response.json.return_value = {'choices': [{'message': {'content': json.dumps({'category': '女士运动外套', 'confidence': .93})}}]}
        with patch.dict(os.environ, {'FASTMOSS_VISION_API_KEY': 'test-placeholder'}), patch('image_assistance.requests.post', return_value=response) as call:
            assistant = VisionAssistant(self.config, self.root/'cache')
            self.assertEqual(assistant.analyze(self.image)['confidence'], .93)
            self.assertEqual(assistant.analyze(self.image)['category'], '女士运动外套')
            self.assertEqual(call.call_count, 1)
            arguments = call.call_args.kwargs
            self.assertNotIn('verify', arguments)
            self.assertTrue(arguments['json']['messages'][0]['content'][1]['image_url']['url'].startswith('data:image/jpeg;base64,'))
            record = {'_local_image_path': str(self.image), '图片审核状态': '待审核', '自动分类': CLASSES[0], '_outcome': '复查', '人工复查原因': '图片待审核'}
            apply_image_assistance(record, assistant, Mock())
            self.assertEqual(record['图片审核状态'], '待审核')
            self.assertEqual(record['_outcome'], '复查')

    def test_invalid_ai_outputs(self):
        for value in ({'category': 'man', 'confidence': .9}, {'category': '普通服饰', 'confidence': 101},
                      {'category': '无法确认', 'confidence': True}, {'category': '无法确认', 'confidence': float('nan')}):
            with self.assertRaises(ValueError):
                validate_result(value)

    def test_missing_credentials_is_explicit(self):
        with patch.dict(os.environ, {}, clear=True), self.assertRaisesRegex(ValueError, '未设置'):
            VisionAssistant(self.config, self.root/'cache')

    def test_low_confidence_or_failure_requests_review(self):
        for result in ({'category': '女士运动外套', 'confidence': .2}, {'category': '普通服饰', 'confidence': .99}, ValueError('bad response')):
            assistant = Mock()
            assistant.config = self.config
            if isinstance(result, Exception):
                assistant.analyze.side_effect = result
            else:
                assistant.analyze.return_value = result
            record = {'_local_image_path': str(self.image), '图片审核状态': '待审核', '图片判断': '无法确认', '自动分类': CLASSES[0], '_outcome': '推荐', '人工复查原因': ''}
            apply_image_assistance(record, assistant, Mock())
            self.assertEqual(record['_outcome'], '复查')
            self.assertEqual(record['图片审核状态'], '待审核')

    def test_valid_human_review_resolves_ai_disagreement(self):
        assistant = Mock()
        assistant.config = self.config
        assistant.analyze.return_value = {'category': '普通服饰', 'confidence': .9}
        record = {'_local_image_path': str(self.image), '图片审核状态': '确认运动服饰', '图片判断': '女士运动外套', '自动分类': CLASSES[0], '_outcome': '推荐', '人工复查原因': ''}
        apply_image_assistance(record, assistant, Mock())
        self.assertEqual(record['_outcome'], '推荐')
        self.assertEqual(record['图片判断'], '女士运动外套')
        self.assertIn('采用有效人工', record['图片辅助说明'])


class V3IntegrationTest(unittest.TestCase):
    def setUp(self):
        # Reuse the existing local HTTP fixture instead of another duplicate server.
        self.fixture = legacy.IntegrationTest(methodName='test_end_to_end_and_manual_repeat')
        self.fixture.setUp()
        self.root, self.raw, self.file = self.fixture.root, self.fixture.raw, self.fixture.file
        for name in ('keywords_v3.json', 'scoring_v3.json'):
            shutil.copy(SCRIPT.parent/name, self.root)
        workbook = Workbook()
        workbook.active.title = '封面'
        workbook.active.append(['说明'])
        sheet = workbook.create_sheet('商品数据')
        sheet.append(['FastMoss V3测试'])
        self.headers = ['商品名称', '商品ID', '商品图片', '店铺名', '商品售价', '国家/地区', '商品分类', '近7天销量', '销量环比', '总销量', '上架时间', '商品链接', '商品状态', '商品标签', '达人数量', '关键词增长率', '近7天销售额', '原始自定义字段']
        sheet.append(self.headers)
        base = ["Women's running hooded jacket", 'P1', self.fixture.base_url+'/good.png', 'Independent', '$35', 'US', '女士运动外套', 1500, '400%', 2000, TODAY-timedelta(days=10), 'https://example.com/P1', '在售', 'training', 50, '40%', '$52,500', '=literal-original']
        cases = [
            ('P1', {}), ('P2', {0: "Women's workout long sleeve top", 6: '女士运动长袖', 4: '$25'}),
            ('P3', {0: "Women's yoga two piece leggings set", 6: '女士运动套装', 4: '$40'}),
            ('P4', {0: "Women's seamless flare yoga leggings", 6: '女士运动裤', 4: '$25'}),
            ('R1', {0: 'Running jacket', 6: '运动外套'}), ('R2', {0: "Women's yoga training coat"}),
            ('R3', {14: None}), ('R4', {15: None}), ('R5', {6: '女士运动裤'}),
            ('D1', {0: "Men's workout jacket"}), ('D2', {0: 'Baby running jacket'}),
            ('D3', {0: "Women's workout hoodie jacket"}), ('D4', {0: "Women's yoga bra"}),
            ('D5', {0: "Women's fashion coat workout"}),
            ('D6', {0: "Women's quarter zip jacket", 6: '女装', 13: None}),
            ('D7', {8: '0%'}), ('D8', {10: TODAY-timedelta(days=91)}),
            ('D9', {12: '下架'}), ('D10', {5: 'UK'}), ('R6', {2: self.fixture.base_url+'/broken.png'})]
        for product_id, changes in cases:
            row = list(base)
            row[1], row[11] = product_id, 'https://example.com/'+product_id
            for index, value in changes.items(): row[index] = value
            sheet.append(row)
        sheet['C3'] = None
        sheet.add_image(XLImage(str(self.fixture.embedded)), 'C3')
        workbook.save(self.file)
        workbook.close()
        self.original_hash = hashlib.sha256(self.file.read_bytes()).hexdigest()

    def tearDown(self):
        self.fixture.tearDown()

    def run_cleaner(self, *extra, expected=0):
        env = os.environ.copy()
        env['NO_PROXY'] = '127.0.0.1,localhost'
        result = subprocess.run([sys.executable, str(SCRIPT/'fastmoss_cleaner.py'), '--root', str(self.root), '--mode', 'v3', '--as-of', TODAY.isoformat(), *extra], env=env, capture_output=True, text=True, timeout=90)
        self.assertEqual(result.returncode, expected, result.stdout+result.stderr)
        return result

    def open_report(self, name):
        return load_workbook(self.root/'02_筛选后表格'/name, data_only=True)

    def confirm(self, sheet, ids):
        headers = [cell.value for cell in sheet[1]]
        for row in range(2, sheet.max_row+1):
            if sheet.cell(row, headers.index('商品ID')+1).value in ids:
                kind = sheet.cell(row, headers.index('自动分类')+1).value
                sheet.cell(row, headers.index('图片判断')+1, kind.split(' ', 1)[1])
                sheet.cell(row, headers.index('图片审核状态')+1, '确认运动服饰')
                sheet.cell(row, headers.index('备注')+1, '已核验')
                sheet.cell(row, headers.index('供应链状态')+1, '已询价')

    def test_end_to_end_four_classes_and_audit_persistence(self):
        result = self.run_cleaner()
        self.assertIn('推荐 0；待人工复查 10；删除 10；总计 20', result.stdout)
        self.assertIn('推荐表为空', result.stdout)
        directory = self.root/'02_筛选后表格'
        workbook = self.open_report('人工复查.xlsx')
        records = legacy.IntegrationTest.records(workbook['待人工复查'])
        self.assertEqual(len(records), 10)
        self.assertEqual(workbook['待人工复查'].freeze_panes, 'A2')
        self.assertTrue(workbook['待人工复查'].auto_filter.ref)
        self.assertTrue(workbook['待人工复查'].conditional_formatting)
        self.assertTrue(workbook['待人工复查']['C2'].hyperlink)
        self.assertEqual(workbook['待人工复查'].max_column, len(set(c.value for c in workbook['待人工复查'][1])))
        self.confirm(workbook['待人工复查'], {'P1', 'P2', 'P3', 'P4'})
        workbook.save(directory/'人工复查.xlsx')
        workbook.close()
        with zipfile.ZipFile(directory/'人工复查.xlsx') as archive:
            self.assertTrue(any(name.startswith('xl/media/') for name in archive.namelist()))
        result = self.run_cleaner()
        self.assertIn('推荐 4；待人工复查 6；删除 10；总计 20', result.stdout)
        workbook = self.open_report('FastMoss_V3推荐商品.xlsx')
        rows = legacy.IntegrationTest.records(workbook['推荐商品'])
        self.assertEqual({r['自动分类'] for r in rows}, set(CLASSES))
        self.assertTrue(all(r['评分']==100 and r['供应链状态']=='已询价' and r['备注']=='已核验' for r in rows))
        self.assertEqual(rows[0]['7天销售额'], 52500)
        self.assertEqual(workbook['原始数据_2']['R3'].value, '=literal-original')
        workbook.close()
        self.assertTrue((directory/'FastMoss清洗结果.xlsx').exists())
        old = self.open_report('FastMoss清洗结果.xlsx')
        self.assertEqual(old.sheetnames, ['FastMoss筛选表', '删除记录', '1688同款数据'])
        old.close()
        with zipfile.ZipFile(directory/'FastMoss_V3推荐商品_轻量.xlsx') as archive:
            self.assertFalse(any(n.startswith('xl/media/') for n in archive.namelist()))
        self.assertEqual(hashlib.sha256(self.file.read_bytes()).hexdigest(), self.original_hash)
        self.assertIn('图片下载/复制失败', (self.root/'error.log').read_text())
        self.assertTrue(list((self.root/'backup').glob('人工复查_*.xlsx')))

    def test_unqualified_data_and_configuration_errors(self):
        self.run_cleaner()
        prior = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (self.root/'02_筛选后表格').glob('*.xlsx')}
        (self.root/'keywords_v3.json').unlink()
        result = self.run_cleaner(expected=1)
        self.assertIn('配置', result.stdout)
        self.assertIn('keywords_v3', (self.root/'error.log').read_text())
        self.assertTrue(all(hashlib.sha256((self.root/'02_筛选后表格'/name).read_bytes()).hexdigest()==digest for name,digest in prior.items()))

    def test_latest_excel_skip_temp_and_unconfirmed_period(self):
        workbook = load_workbook(self.file)
        sheet = workbook['商品数据']
        sheet['H2'] = '销量'
        changed = self.raw/'newest.xlsx'
        workbook.save(changed)
        workbook.close()
        os.utime(changed, (self.file.stat().st_mtime+20, self.file.stat().st_mtime+20))
        (self.raw/'~$temporary.xlsx').write_bytes(b'not an excel')
        result = self.run_cleaner()
        self.assertIn('newest.xlsx', result.stdout)
        workbook = self.open_report('人工复查.xlsx')
        rows = legacy.IntegrationTest.records(workbook['待人工复查'])
        self.assertTrue(all(r['7天销量'] is None and '周期' in r['人工复查原因'] for r in rows))
        workbook.close()

    def test_hard_rejected_product_never_reenters_sourcing(self):
        self.run_cleaner()
        standard = self.root/'cleaned/Fastmoss_待搜款清洗表.xlsx'
        workbook = load_workbook(standard)
        sheet = workbook.active
        headers = [c.value for c in sheet[1]]
        for row in range(2,sheet.max_row+1):
            if sheet.cell(row,1).value=='D1':
                sheet.cell(row,headers.index('是否进入搜款')+1,'是')
                sheet.cell(row,headers.index('搜款状态')+1,'已裁剪')
        workbook.save(standard)
        workbook.close()
        self.run_cleaner()
        workbook = load_workbook(standard,data_only=True)
        row = next(r for r in legacy.IntegrationTest.records(workbook.active) if r['商品ID']=='D1')
        self.assertEqual(row['是否进入搜款'],'否')
        self.assertEqual(row['搜款状态'],'已裁剪')
        workbook.close()

    def test_multi_file_output_rollback(self):
        self.run_cleaner()
        directory=self.root/'02_筛选后表格'
        names=('FastMoss_V3推荐商品.xlsx','人工复查.xlsx','删除记录.xlsx')
        hashes={name:hashlib.sha256((directory/name).read_bytes()).hexdigest() for name in names}
        keywords,config=load_v3_config(self.root)
        source=load_workbook(self.file)
        real_replace=os.replace
        count=0
        def fail_second(src,dst):
            nonlocal count
            count+=1
            if count==2:raise PermissionError('simulated Excel file lock')
            return real_replace(src,dst)
        try:
            with patch('v3_report.os.replace',side_effect=fail_second), self.assertRaises(PermissionError):
                save_v3_reports(directory,[],[],[],self.file,source,source['商品数据'],TODAY,keywords,config,self.root/'backup',Mock())
        finally:
            source.close()
        self.assertTrue(all(hashlib.sha256((directory/name).read_bytes()).hexdigest()==digest for name,digest in hashes.items()))
        self.assertFalse(list(directory.glob('.*.tmp.xlsx')))


if __name__=='__main__':
    unittest.main()
