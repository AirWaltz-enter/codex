@echo off
chcp 65001 >nul
call "%~dp004_脚本\测试V2.bat" %*
exit /b %ERRORLEVEL%
